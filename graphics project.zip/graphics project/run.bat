@echo off
REM  CakeLab - build if needed, then run.
if not exist CakeLab.exe (
  call build.bat nopause
  if errorlevel 1 exit /b 1
)
start "" CakeLab.exe
