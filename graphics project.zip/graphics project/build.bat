@echo off
REM ==========================================================================
REM  CakeLab - one click build
REM  CSC 3224 Computer Graphics, Group E
REM
REM  Double click this file, or run it from a command prompt. It finds the
REM  g++ that ships with Code::Blocks, compiles every source file and links
REM  a standalone CakeLab.exe that needs no DLLs beside it.
REM
REM    build.bat            normal build
REM    build.bat console    build with the console window kept open
REM ==========================================================================
setlocal enabledelayedexpansion

set "GXX="
for %%P in (
  "C:\Program Files\CodeBlocks\MinGW\bin\g++.exe"
  "C:\Program Files (x86)\CodeBlocks\MinGW\bin\g++.exe"
  "C:\msys64\mingw64\bin\g++.exe"
  "C:\MinGW\bin\g++.exe"
  "C:\mingw64\bin\g++.exe"
  "C:\TDM-GCC-64\bin\g++.exe"
) do (
  if exist %%P set "GXX=%%~P"
)
if "%GXX%"=="" (
  where g++ >nul 2>nul && set "GXX=g++"
)
if "%GXX%"=="" (
  echo.
  echo   Could not find g++.
  echo   Install Code::Blocks with MinGW, or put g++ on your PATH.
  echo.
  pause
  exit /b 1
)

echo Using compiler: %GXX%

set "SUBSYSTEM=-mwindows"
if /I "%~1"=="console" set "SUBSYSTEM="

if not exist build mkdir build

set "CXXFLAGS=-std=c++11 -O2 -Wall -Wextra -DFREEGLUT_STATIC"
set "LDFLAGS=-static -static-libgcc -static-libstdc++ %SUBSYSTEM%"
set "LDLIBS=-lfreeglut_static -lopengl32 -lglu32 -lwinmm -lgdi32"

set "UNITS=gfx ui cake toppings wrapping screenshot stage_shape stage_flavor stage_toppings stage_wrap app main"
set "OBJS="

for %%U in (%UNITS%) do (
  echo   compiling %%U.cpp
  "%GXX%" %CXXFLAGS% -c src\%%U.cpp -o build\%%U.o
  if errorlevel 1 (
    echo.
    echo   BUILD FAILED while compiling %%U.cpp
    pause
    exit /b 1
  )
  set "OBJS=!OBJS! build\%%U.o"
)

echo   linking CakeLab.exe
"%GXX%" !OBJS! -o CakeLab.exe %LDFLAGS% %LDLIBS%
if errorlevel 1 (
  echo.
  echo   BUILD FAILED at the link step
  pause
  exit /b 1
)

echo.
echo   Done.  Run CakeLab.exe
echo.
if /I not "%~1"=="nopause" pause
endlocal
