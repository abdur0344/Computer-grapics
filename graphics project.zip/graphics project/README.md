# CakeLab

**An Interactive 2D Cake Customization Game Built with Computer Graphics Primitives**

Course: CSC 3224, Computer Graphics · Group E · American International University Bangladesh
Supervisor: Dr. Mohammad Nazmul Alam

CakeLab is a desktop application written in C++ with OpenGL and freeGLUT. A cake is
designed through four guided stages, and the result is drawn live from graphics
primitives only — points, lines, polygons and the parametric point loop. There are no
image files, no textures and no third-party libraries beyond GLUT itself.

![The finish screen](docs/screenshots/shot_6_finish.png)

---

## Build and run

### The quickest way

Double click **`build.bat`**, then run **`CakeLab.exe`**.

The script finds the `g++` that ships with Code::Blocks (or any MinGW on `PATH`),
compiles the twelve source files and links a standalone executable. No DLL has to sit
beside it — freeglut and the runtime are linked statically.

### Code::Blocks  (the normal way to open this project)

1. Open **`CakeLab.cbp`** — double click it, or File, Open, and pick it.
2. Press **F9** (Build and run).

That is all. The project ships two targets, chosen from the toolbar dropdown:

| Target | What it gives you |
|--------|-------------------|
| **Release** | The one to demonstrate. Optimised, no console window, standalone `CakeLab.exe` in the project folder. |
| **Debug** | Same program with debug symbols and a console window attached, so `printf` output and `--selftest` results are visible. Produces `CakeLab_debug.exe`. |

Objects go to `build/release/` and `build/debug/`, so the two targets never
overwrite each other.

**If you ever rebuild the project file from scratch**, every `.cpp` unit must be
marked `compilerVar="CPP"`. Marking them `CC` still compiles every file without
complaint, but Code::Blocks then links with `gcc` instead of `g++`, and the build
dies at the link step with several hundred `undefined reference to 'operator delete'`
and `undefined reference to 'std::...'` errors. The compile succeeding makes it look
like a library problem when it is not.

### Command line

```bash
mingw32-make
```

or, spelled out:

```bash
g++ -std=c++11 -O2 -DFREEGLUT_STATIC -c src/*.cpp
g++ *.o -o CakeLab.exe -static -static-libgcc -static-libstdc++ -lfreeglut_static -lopengl32 -lglu32 -lwinmm -lgdi32
```

`-DFREEGLUT_STATIC` is needed at **compile** time as well as at link time; it changes
how the freeglut entry points are declared. Leaving it out gives a long list of
`undefined reference to __imp_glut...` errors.

### One single file

If the project has to be handed in as one file, run:

```bash
python tools/amalgamate.py
```

This writes `CakeLab_single.cpp`, which builds on its own:

```bash
g++ -std=c++11 -O2 -DFREEGLUT_STATIC CakeLab_single.cpp -o CakeLab.exe -static -static-libgcc -static-libstdc++ -lfreeglut_static -lopengl32 -lglu32 -lwinmm -lgdi32
```

The files in `src/` are the real project; the single file is generated from them and
should not be edited by hand.

---

## The four stages

| Stage | What the user does | What it demonstrates |
|-------|--------------------|----------------------|
| 1. Shape | Picks circle, square, triangle, rectangle or a 5 to 8 sided polygon, and one to three tiers | Scan conversion, the parametric point loop, regular polygon generation |
| 2. Flavour | Picks one of eight flavours | The RGB colour model; the panel prints the exact R, G, B of the frosting |
| 3. Toppings | Clicks the cake to place berries, biscuits, peanuts, cherries, fruit, chocolate, gems and candles | Composite objects, translation, rotation, scaling |
| 4. Wrapping | Picks a rope tie, a gift box, a wrapping sheet or a ribbon and tag, in six colours | Reuse of the shape and colour routines from stages 1 and 2 |

![Stage 1](docs/screenshots/shot_2_shape.png)

---

## Controls

Everything is reachable with the mouse. The keyboard is a shortcut, not a requirement.

| Key | Action |
|-----|--------|
| `Enter` / `N` / `Right` | Next stage |
| `Backspace` / `B` / `Left` | Previous stage |
| `1` – `8` | Choose an option in the current stage |
| Left click | Place the selected ingredient on the cake |
| Left drag | Place a trail of ingredients |
| Right click | Remove the ingredient under the cursor |
| `U` | Undo the last ingredient |
| `C` | Clear every ingredient |
| `X` | Scatter eight of the selected ingredient |
| `A` | Toggle the scan conversion view |
| `P` / `F2` | Save the window as `cakelab_001.bmp` |
| `R` | Reset the design |
| `Z` | Generate a random cake |
| `H` / `F1` | Show the control list |
| `Esc` | Quit |

---

## The scan conversion view

Pressing **`A`** redraws the cake outline using the rasterising algorithms from the
course instead of the OpenGL primitives, one pixel at a time:

- the top face of a round cake with the **midpoint ellipse** algorithm,
- the top face of every other shape with a **Bresenham** line loop,
- the base outline with the **DDA**,
- the vertical extrusion edges with Bresenham again.

![The scan conversion view](docs/screenshots/shot_7_algorithm.png)

---

## Layout of the source

```
src/
  gfx.h  gfx.cpp            drawing toolkit: DDA, Bresenham, midpoint circle and
                            ellipse, parametric point loops, filled shapes,
                            gradients, RGB and HSV colour, GLUT text, transforms
  ui.h   ui.cpp             theme, buttons and hit testing, panels, the stage
                            stepper, toasts, wrapped text
  cake.h cake.cpp           the Design data, the geometry that places it on
                            screen, and the cake renderer
  toppings.cpp              the eight ingredients, each a composite object
  wrapping.cpp              the four packaging styles
  stage_shape.cpp           stage 1   (member 1)
  stage_flavor.cpp          stage 2   (member 2)
  stage_toppings.cpp        stage 3   (member 3)
  stage_wrap.cpp            stage 4   (member 4)
  app.h  app.cpp            window layout, the stage machine, welcome and finish
                            screens, animation, input routing
  screenshot.h .cpp         glReadPixels to a hand written 24 bit BMP
  main.cpp                  GLUT set-up and callbacks only
tools/amalgamate.py         builds CakeLab_single.cpp from src/
tools/report.js             builds the .docx report (needs: npm install docx)
docs/CakeLab_Project_Report.docx   the report to hand in
docs/CakeLab_Project_Report.pdf    the same report as a PDF
docs/REPORT.md              the same content in Markdown
docs/screenshots/           figures, regenerated by CakeLab.exe --capture
```

A stage is described by a `StageDef`: a title and a handful of callbacks. The shell in
`app.cpp` knows nothing about cherries or ribbons, and a stage knows nothing about the
window layout, so the four members were able to work on one stage each.

## Two development switches

```bash
CakeLab.exe --capture
```

steps through every screen, writes a BMP of each one and exits. It exists only to put
figures in the report; the interactive program never uses it.

```bash
CakeLab.exe --selftest
```

drives the program with synthetic input — every option of every stage, placing and
removing ingredients on all five base shapes, every wrapping over every shape and tier
count, the keyboard shortcuts, three window sizes and the finish screen — then prints
a pass or fail count and exits with a non-zero status if anything failed. Run it
before handing the project in:

```
CakeLab self test
24 checks, 0 failures
SELFTEST PASS
```

## Requirements

- Windows, and a MinGW g++ (the one bundled with Code::Blocks is what this was built
  and tested with: `g++ 8.1.0 x86_64-posix-seh`).
- freeglut and the OpenGL import libraries, both of which come with that MinGW.
- Python is needed only for `tools/amalgamate.py`, not for building or running.
