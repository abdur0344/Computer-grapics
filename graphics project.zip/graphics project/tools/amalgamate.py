#!/usr/bin/env python
# ---------------------------------------------------------------------------
#  CakeLab  -  tools/amalgamate.py
#
#  Joins every header and source file into one CakeLab_single.cpp, for the
#  case where the project has to be opened as a single file: create an empty
#  Code::Blocks GLUT project, paste the file in, press F9.
#
#  The multi file build in src/ is the real project; this is only a
#  convenience copy, and it is regenerated rather than edited by hand.
#
#      python tools/amalgamate.py
#      mingw32-make single
# ---------------------------------------------------------------------------
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, 'src')
OUT = os.path.join(ROOT, 'CakeLab_single.cpp')

HEADERS = ['gfx.h', 'ui.h', 'cake.h', 'screenshot.h', 'app.h']
SOURCES = ['gfx.cpp', 'ui.cpp', 'cake.cpp', 'toppings.cpp', 'wrapping.cpp',
           'screenshot.cpp', 'stage_shape.cpp', 'stage_flavor.cpp',
           'stage_toppings.cpp', 'stage_wrap.cpp', 'app.cpp', 'main.cpp']

LOCAL_INCLUDE = re.compile(r'^\s*#\s*include\s+"[^"]+"\s*$')
SYSTEM_INCLUDE = re.compile(r'^\s*#\s*include\s+<([^>]+)>\s*$')

BANNER = '''/* ===========================================================================
 *  CakeLab  -  single file build
 *  An Interactive 2D Cake Customisation Game Built with Computer Graphics
 *  Primitives.
 *
 *  Course     : CSC 3224, Computer Graphics
 *  Group      : E
 *  Members    : Md. Minhaj Rowfun Rabbi Anik, Adiba Howlader,
 *               Md. Tanvir Hasan, Abdur Rahman
 *  Supervisor : Dr. Mohammad Nazmul Alam
 *  Department of Computer Science, Faculty of Science and Technology,
 *  American International University Bangladesh.
 *
 *  GENERATED FILE. It is the contents of src/ joined together by
 *  tools/amalgamate.py. Edit the files in src/ and regenerate; do not edit
 *  this copy.
 *
 *  Build with Code::Blocks: File, New, Project, GLUT project, then replace
 *  main.cpp with this file and press F9.
 *
 *  Build from a command prompt:
 *      g++ -std=c++11 -O2 -DFREEGLUT_STATIC CakeLab_single.cpp -o CakeLab.exe ^
 *          -static -static-libgcc -static-libstdc++ ^
 *          -lfreeglut_static -lopengl32 -lglu32 -lwinmm -lgdi32
 * ======================================================================== */
'''


def read(path):
    with io.open(path, encoding='utf-8') as fp:
        return fp.read()


def collect(files, folder):
    """Strip local includes, hoist system includes, keep everything else."""
    system = []
    chunks = []
    for name in files:
        body = []
        for line in read(os.path.join(folder, name)).splitlines():
            if LOCAL_INCLUDE.match(line):
                continue
            m = SYSTEM_INCLUDE.match(line)
            if m:
                if m.group(1) not in system:
                    system.append(m.group(1))
                continue
            body.append(line)
        chunks.append((name, '\n'.join(body).rstrip() + '\n'))
    return system, chunks


def main():
    if not os.path.isdir(SRC):
        sys.stderr.write('cannot find %s\n' % SRC)
        return 1

    sys_h, header_chunks = collect(HEADERS, SRC)
    sys_c, source_chunks = collect(SOURCES, SRC)
    for h in sys_c:
        if h not in sys_h:
            sys_h.append(h)

    # freeglut has to come before anything that touches GL types
    sys_h.sort(key=lambda h: (0 if h.startswith('GL/') else 1, h))

    parts = [BANNER, '']
    for h in sys_h:
        parts.append('#include <%s>' % h)
    parts.append('')

    for name, body in header_chunks + source_chunks:
        parts.append('/* ===== %s %s */' % (name, '=' * max(0, 62 - len(name))))
        parts.append(body)

    text = '\n'.join(parts).rstrip() + '\n'
    with io.open(OUT, 'w', encoding='utf-8') as fp:
        fp.write(text)

    print('wrote %s  (%d lines, %.1f kB)'
          % (os.path.basename(OUT), text.count('\n') + 1, len(text) / 1024.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
