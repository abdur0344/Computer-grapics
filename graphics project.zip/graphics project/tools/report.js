/* ---------------------------------------------------------------------------
 *  CakeLab  -  tools/report.js
 *
 *  Builds docs/CakeLab_Project_Report.docx in the AIUB report format: cover
 *  page, table of contents, the nine report sections, the object and function
 *  tables, and the ten figures from docs/screenshots.
 *
 *      npm install docx
 *      node tools/report.js
 *
 *  Open the result in Word once and press Ctrl+A then F9 to refresh the table
 *  of contents page numbers, or just accept the ones already stored.
 * ------------------------------------------------------------------------ */
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  ImageRun, PageBreak, PageNumber, Footer, Header, TableOfContents,
  LevelFormat, convertInchesToTwip, VerticalAlign,
} = require('docx');

const PROJECT = 'C:\\Users\\Tanvir\\OneDrive - American International University-Bangladesh\\Desktop\\graphics project';
const SHOTS = path.join(PROJECT, 'docs', 'screenshots');
const OUT = path.join(PROJECT, 'docs', 'CakeLab_Project_Report.docx');

const CONTENT_DXA = 9026;          /* A4 minus one inch margins each side */
const BODY_FONT = 'Times New Roman';
const MONO_FONT = 'Courier New';

/* ------------------------------------------------------------ helpers */
let figureNo = 0;

const p = (text, opts = {}) => new Paragraph({
  alignment: opts.align || AlignmentType.JUSTIFIED,
  spacing: { line: opts.line || 320, before: opts.before || 0, after: opts.after === undefined ? 140 : opts.after },
  indent: opts.indent,
  children: [new TextRun({
    text,
    font: BODY_FONT,
    size: opts.size || 24,
    bold: !!opts.bold,
    italics: !!opts.italics,
    color: opts.color,
  })],
});

/* a paragraph built from [text, {bold|italics|mono}] pairs */
const rich = (parts, opts = {}) => new Paragraph({
  alignment: opts.align || AlignmentType.JUSTIFIED,
  spacing: { line: opts.line || 320, before: opts.before || 0, after: opts.after === undefined ? 140 : opts.after },
  children: parts.map((piece) => {
    const [text, f = {}] = Array.isArray(piece) ? piece : [piece, {}];
    return new TextRun({
      text,
      font: f.mono ? MONO_FONT : BODY_FONT,
      size: f.mono ? 20 : (opts.size || 24),
      bold: !!f.bold,
      italics: !!f.italics,
    });
  }),
});

const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  keepNext: true,
  spacing: { before: 360, after: 200 },
  children: [new TextRun({ text, font: BODY_FONT, size: 30, bold: true, color: '1F3864' })],
});

const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  keepNext: true,
  spacing: { before: 260, after: 140 },
  children: [new TextRun({ text, font: BODY_FONT, size: 26, bold: true, color: '2E5496' })],
});

const bullets = (items) => items.map((t) => new Paragraph({
  numbering: { reference: 'bullets', level: 0 },
  spacing: { line: 300, after: 90 },
  alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text: t, font: BODY_FONT, size: 24 })],
}));

const numbered = (items, ref) => items.map((t) => new Paragraph({
  numbering: { reference: ref || 'nums', level: 0 },
  spacing: { line: 300, after: 90 },
  alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text: t, font: BODY_FONT, size: 24 })],
}));

const cellText = (text, o = {}) => new Paragraph({
  alignment: o.align || AlignmentType.LEFT,
  spacing: { line: 260, before: 40, after: 40 },
  children: (Array.isArray(text) ? text : [[text, {}]]).map(([t, f = {}]) => new TextRun({
    text: t,
    font: f.mono ? MONO_FONT : BODY_FONT,
    size: f.mono ? 18 : (o.size || 21),
    bold: !!f.bold || !!o.bold,
    italics: !!f.italics,
  })),
});

/* headers: array of strings. rows: array of arrays; a cell is a string or
   an array of [text, {mono|bold|italics}] pairs. fracs: column fractions. */
function makeTable(headers, rows, fracs, opts = {}) {
  const widths = fracs.map((f) => Math.round(CONTENT_DXA * f));
  widths[widths.length - 1] = CONTENT_DXA - widths.slice(0, -1).reduce((a, b) => a + b, 0);

  const border = { style: BorderStyle.SINGLE, size: 4, color: 'A6A6A6' };
  const borders = { top: border, bottom: border, left: border, right: border };

  const headRow = new TableRow({
    tableHeader: true,
    children: headers.map((htxt, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: 'DEE6F1' },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      verticalAlign: VerticalAlign.CENTER,
      borders,
      children: [cellText(htxt, { bold: true, size: 21 })],
    })),
  });

  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((cell, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: ri % 2 ? { type: ShadingType.CLEAR, fill: 'F4F6FA' } : undefined,
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      verticalAlign: VerticalAlign.TOP,
      borders,
      children: [cellText(cell, { size: opts.size || 21 })],
    })),
  }));

  return new Table({
    columnWidths: widths,
    width: { size: CONTENT_DXA, type: WidthType.DXA },
    rows: [headRow, ...bodyRows],
  });
}

/* a boxed monospace block, used for the schematic diagrams */
function diagram(text) {
  const lines = text.replace(/\n+$/, '').split('\n');
  const border = { style: BorderStyle.SINGLE, size: 4, color: 'B4C6E7' };
  return new Table({
    columnWidths: [CONTENT_DXA],
    width: { size: CONTENT_DXA, type: WidthType.DXA },
    rows: [new TableRow({
      children: [new TableCell({
        width: { size: CONTENT_DXA, type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: 'F7F9FC' },
        margins: { top: 120, bottom: 120, left: 140, right: 140 },
        borders: { top: border, bottom: border, left: border, right: border },
        children: lines.map((l) => new Paragraph({
          spacing: { line: 200, before: 0, after: 0 },
          children: [new TextRun({ text: l || ' ', font: MONO_FONT, size: 15 })],
        })),
      })],
    })],
  });
}

function figure(file, caption, widthPx) {
  const w = widthPx || 560;
  const h = Math.round(w * 760 / 1280);
  figureNo += 1;
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 160, after: 60 },
      children: [new ImageRun({
        type: 'png',
        data: fs.readFileSync(path.join(SHOTS, file)),
        transformation: { width: w, height: h },
      })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 220 },
      children: [new TextRun({
        text: `Figure ${figureNo}: ${caption}`,
        font: BODY_FONT, size: 20, italics: true, color: '444444',
      })],
    }),
  ];
}

const pageBreak = () => new Paragraph({ children: [new PageBreak()] });
const spacer = (after = 200) => new Paragraph({ spacing: { after }, children: [] });

/* ------------------------------------------------------- cover page */
const coverLine = (text, size, bold, spaceAfter, color) => new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: spaceAfter === undefined ? 120 : spaceAfter },
  children: [new TextRun({ text, font: BODY_FONT, size, bold: !!bold, color })],
});

const membersTable = () => {
  const w = [Math.round(CONTENT_DXA * 0.30), 0];
  w[1] = CONTENT_DXA - w[0];
  const border = { style: BorderStyle.SINGLE, size: 4, color: 'A6A6A6' };
  const borders = { top: border, bottom: border, left: border, right: border };
  const rows = [
    ['Student ID', 'Name'],
    ['23-54110-3', 'Md. Minhaj Rowfun Rabbi Anik'],
    ['23-54309-3', 'Adiba Howlader'],
    ['23-54796-3', 'Md. Tanvir Hasan'],
    ['23-54954-3', 'Abdur Rahman'],
  ];
  return new Table({
    columnWidths: w,
    width: { size: CONTENT_DXA, type: WidthType.DXA },
    rows: rows.map((r, ri) => new TableRow({
      tableHeader: ri === 0,
      children: r.map((c, i) => new TableCell({
        width: { size: w[i], type: WidthType.DXA },
        shading: ri === 0 ? { type: ShadingType.CLEAR, fill: 'DEE6F1' } : undefined,
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        borders,
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { line: 260 },
          children: [new TextRun({ text: c, font: BODY_FONT, size: 22, bold: ri === 0 })],
        })],
      })),
    })),
  });
};

const cover = [
  spacer(400),
  coverLine('American International University Bangladesh', 32, true, 100, '1F3864'),
  coverLine('(AIUB)', 26, true, 240, '1F3864'),
  coverLine('Faculty of Science and Technology', 24, false, 60),
  coverLine('Department of Computer Science', 24, false, 700),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
    border: { top: { style: BorderStyle.SINGLE, size: 6, color: '8EAADB' } },
    children: [new TextRun({ text: '' })],
  }),
  coverLine('Final Project Report', 24, false, 180),
  coverLine('CakeLab', 56, true, 140, '1F3864'),
  coverLine('An Interactive 2D Cake Customization Game', 26, false, 40),
  coverLine('Built with Computer Graphics Primitives', 26, false, 180),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 560 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: '8EAADB' } },
    children: [new TextRun({ text: '' })],
  }),
  coverLine('Course: CSC 3224 — Computer Graphics', 24, true, 60),
  coverLine('Group: E', 24, true, 300),
  membersTable(),
  spacer(360),
  coverLine('Supervised by', 22, false, 60),
  coverLine('Dr. Mohammad Nazmul Alam', 26, true, 400),
  coverLine('Date of Submission: 18 August 2026', 22, false, 0),
];

/* ------------------------------------------------- diagrams (verbatim) */
const DIAG_STRUCTURE = `
                          +---------------------+
                          |      main.cpp       |
                          |  GLUT set-up only   |
                          +----------+----------+
                                     |  callbacks
   +-------------+-------------+-----+-------+---------------+
   |             |             |             |               |
glutDisplayFunc glutMouseFunc glutKeyboardFunc glutTimerFunc glutReshapeFunc
   |             |             |             |               |
   v             v             v             v               v
+---------------------------------------------------------------------+
|                             app.cpp                                 |
|  window layout | stage machine | welcome and finish screens | input  |
+----+---------------+---------------+---------------+----------------+
     |               |               |               |
     v               v               v               v
stage_shape.cpp stage_flavor.cpp stage_toppings.cpp stage_wrap.cpp
  (member 1)      (member 2)       (member 3)        (member 4)
     |               |               |               |
     +---------------+------+--------+---------------+
                            |  reads and writes
                            v
                    +---------------+
                    | cake::Design  |  shape, tiers, flavour,
                    |   (the data)  |  toppings, wrapping
                    +-------+-------+
                            |
                            v
     +----------------------+--------------------------+
     |           cake.cpp    drawCake()                 |
     |  plate -> tiers -> drips -> frosting -> toppings  |
     +----+------------------+---------------------+----+
          |                  |                     |
          v                  v                     v
   toppings.cpp        wrapping.cpp             ui.cpp
  eight ingredients  four packaging styles   buttons, panels
          |                  |                     |
          +------------------+---------------------+
                            |
                            v
                  +---------------------+
                  |       gfx.cpp       |
                  | DDA, Bresenham,     |
                  | midpoint circle and |
                  | ellipse, point      |
                  | loops, fills, text  |
                  +---------------------+
`;

const DIAG_SCREEN = `
+-------------------------------------------------------------------------+
| [logo] CakeLab                     (1)--(2)--(3)--(4)  stage stepper     | header
+--------------------------+----------------------------------------------+
| Stage n of 4             |                                              |
| Stage title              |                                              |
| ------------------------ |                                              |
| [ icon ] Option 1    (v) |              live cake preview               |
| [ icon ] Option 2        |                                              |
| [ icon ] Option 3        |         (the same drawCake() call as         |
| [ icon ] Option 4        |           the finish screen uses)            |
| ...                      |                                              |
| SECTION LABEL            |                                              |
| ( chip )( chip )( chip ) |  +----------------------------------------+  |
|                          |  | CURRENT DESIGN            stage note    | |
|                          |  | Round, Red Velvet, 6 toppings ...       | |
+--------------------------+--+----------------------------------------+--+
| Back (o)(o)(o)(o)(o)  hint text                        Next stage  >    | footer
+-------------------------------------------------------------------------+
`;

const DIAG_FLOW = `
Welcome  --Start-->  Stage 1 Shape  -->  Stage 2 Flavour  -->  Stage 3 Toppings
                          ^                     ^                      |
                          |                     |                      v
                          +--------- Back ------+------------  Stage 4 Wrapping
                                                                       |
                                                                    Finish
                                                                       |
                                                    Back to editing / Design another
`;

/* ------------------------------------------------------------- body */
const body = [];

body.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 240 },
  children: [new TextRun({ text: 'Table of Contents', font: BODY_FONT, size: 30, bold: true, color: '1F3864' })],
}));
body.push(new TableOfContents('Contents', { hyperlink: true, headingStyleRange: '1-2' }));
body.push(pageBreak());

/* 1 */
body.push(h1('1. Introduction'));
body.push(p('CakeLab is a desktop application that lets a user design a virtual cake through a sequence of four guided stages. It is written in C++ using OpenGL and the OpenGL Utility Toolkit (GLUT), and every pixel on screen is produced from the graphics primitives taught in this course. There are no image files, no textures and no third-party libraries: a cherry is a filled circle with a Bezier stem, a plate is an ellipse generated by a parametric point loop, and the sides of the cake are quads extruded from an outline.'));
body.push(p('The design process is organised into four stages:'));
body.push(...numbered([
  'selection of the base shape of the cake,',
  'selection of the flavour and its colour scheme,',
  'placement of decorative ingredients on the top surface,',
  'selection of a wrapping or packaging style.',
]));
body.push(p('Each stage is rendered live, so the cake is visibly updated as choices are made. The finished application works both as a small creative tool and as a demonstration of scan conversion, colour models, geometric transformation, animation and interaction.'));
body.push(...figure('shot_6_finish.png', 'The finish screen, showing a completed three tier Black Forest cake with a ribbon and tag, alongside the design summary.'));

/* 2 */
body.push(h1('2. Objectives'));
body.push(...bullets([
  'Build one complete interactive application out of the separate exercises done during the semester, rather than leaving them as unrelated demonstrations.',
  'Generate every shape from first principles: circles from a parametric point loop, polygons from a regular polygon generator, and straight sided shapes from corner lists.',
  'Implement the incremental scan conversion algorithms from the literature (DDA, Bresenham midpoint line, midpoint circle and midpoint ellipse) and make them visible to the user at run time.',
  'Apply the RGB colour model as a real, data driven part of the program: a flavour is a palette, and the whole cake is redrawn from it.',
  'Apply translation, rotation and scaling to place composite objects on the cake.',
  'Handle mouse and keyboard input through GLUT callbacks, and animate through glutTimerFunc.',
]));

/* 3 */
body.push(h1('3. Schematic Diagram'));
body.push(h2('3.1 Program structure'));
body.push(p('Each box is one source file. Arrows point from a caller to what it calls; every layer depends only on the layer below it.'));
body.push(diagram(DIAG_STRUCTURE));
body.push(spacer(200));
body.push(h2('3.2 Screen layout'));
body.push(p('The window is one continuous scene: a header carrying the stage stepper, a panel of selectable options on the left, the live cake preview on the right, and a footer holding the navigation.'));
body.push(diagram(DIAG_SCREEN));
body.push(spacer(200));
body.push(h2('3.3 Stage flow'));
body.push(diagram(DIAG_FLOW));

/* 4 */
body.push(h1('4. List of Objects and the Functions that Represent Them'));

body.push(h2('4.1 The cake itself'));
body.push(makeTable(
  ['Object', 'Function', 'How it is built'],
  [
    ['Base outline', [['cake::shapeOutlineUnit()', { mono: true }]], 'Circle from gfx::makeCircle() (parametric point loop); polygon from gfx::makeRegularPolygon(); square, rectangle and triangle from corner lists, then subdivided by densify()'],
    ['Plate', [['drawPlate()', { mono: true }]], 'Two stacked ellipses from gfx::fillEllipseGrad(), a rim from gfx::makeEllipse() with gfx::polyline(), and a soft shadow from gfx::softShadow()'],
    ['Tier body (sides)', [['drawTier()', { mono: true }]], 'For each edge of the outline whose outward normal faces the viewer, one GL_QUADS band shaded by that normal'],
    ['Cream filling stripe', [['drawTier()', { mono: true }]], 'A second quad across the middle 40 to 55 per cent of each side band'],
    ['Crumb speckle', [['drawTier()', { mono: true }]], 'Small circles at hashed positions, so that they never move between frames'],
    ['Frosting drips', [['drawTier()', { mono: true }]], 'gfx::fillCapsule() at intervals measured along the front silhouette'],
    ['Frosting collar', [['drawTier()', { mono: true }]], 'A short extrusion of the top rim in the frosting colour'],
    ['Top face', [['drawTier()', { mono: true }]], 'gfx::fillPolyGrad() over the outline, plus a sheen ellipse towards the light'],
    ['Piped border', [['drawTier()', { mono: true }]], 'Small circles spaced by arc length around the top outline, each with a highlight and a shadow dot'],
    ['Whole cake', [['cake::drawCake()', { mono: true }]], 'Plate, then tier by tier from the bottom up, then toppings, then packaging'],
  ],
  [0.20, 0.24, 0.56]
));

body.push(h2('4.2 The ingredients (composite objects)'));
body.push(p('Every ingredient is drawn in its own local coordinate system, roughly minus one to plus one, and is placed by cake::drawTopping(), which pushes a translation, a rotation and a scale before calling it. This is the same principle as the car and jeep exercise: several primitives grouped into one recognisable object.'));
body.push(makeTable(
  ['Ingredient', 'Function', 'Primitives used'],
  [
    ['Berries', [['drawBerry()', { mono: true }]], 'Three graded circles, a highlight circle and a five point star calyx on each'],
    ['Biscuit', [['drawBiscuit()', { mono: true }]], 'Two offset circles for thickness, a graded face, seven dots and sixteen scallop circles'],
    ['Peanuts', [['drawPeanut()', { mono: true }]], 'Four ellipses with a joining rectangle, a Bezier seam and highlight ellipses'],
    ['Cherry', [['drawCherry()', { mono: true }]], 'A graded circle, a Bezier stem drawn as a thick polyline, and a rotated leaf ellipse'],
    ['Fruit slice', [['drawFruitSlice()', { mono: true }]], 'Rind and pith circles, eight gfx::fillArc() segments with radial creases'],
    ['Chocolate chunk', [['drawChocolate()', { mono: true }]], 'Three quads for the top, front and right faces, plus a highlight'],
    ['Candy gem', [['drawGem()', { mono: true }]], 'A squashed hexagon crown, a fan of triangles for the pavilion, a table facet and an animated sparkle'],
    ['Candle', [['drawCandle()', { mono: true }]], 'A rounded rectangle body, slanted stripe polygons, a wick, and a flame of two vertically graded polygons that flicker with time'],
  ],
  [0.20, 0.24, 0.56]
));

body.push(h2('4.3 The packaging'));
body.push(makeTable(
  ['Style', 'Function', 'Primitives used'],
  [
    ['Rope tie', [['ropeBehind(), ropeFront()', { mono: true }]], 'frontBand() round the waist, which is the same silhouette extrusion the cake body uses, a vertical band, twine lines and a bow'],
    ['Gift box', [['boxBehind(), boxFront()', { mono: true }]], 'A back wall, two splayed side walls, a lid built as an explicit quad, a front wall drawn as four rectangles so the window stays clear, glass streaks, a ribbon and a bow'],
    ['Wrapping sheet', [['sheetPetals(), sheetFront()', { mono: true }]], 'Nine petal quads fanned about a knot, sorted into those behind and those in front of the cake, polka dots and a gathered knot'],
    ['Ribbon and tag', [['ribbonFront()', { mono: true }]], 'frontBand() at the waist, a bow, and a swinging tag on a string'],
    ['Bow (shared)', [['drawBow()', { mono: true }]], 'Two Bezier tails drawn with a tapering width, two rotated loop ellipses and a knot'],
  ],
  [0.20, 0.26, 0.54]
));
body.push(...figure('shot_8_rope.png', 'The rope tie: a band follows the silhouette round the waist while a second band runs up the front and over the rim.', 470));
body.push(...figure('shot_9_sheet.png', 'The wrapping sheet: a fan of quads split into the petals behind the cake and the petals in front of it.', 470));

body.push(h2('4.4 The interface'));
body.push(makeTable(
  ['Object', 'Function'],
  [
    ['Window backdrop', [['ui::drawBackdrop()', { mono: true }]]],
    ['Panel and preview frame', [['ui::drawPanel(), ui::drawPanelTinted()', { mono: true }]]],
    ['Option rows and chips', [['ui::drawButton()', { mono: true }], [' with BTN_OPTION, BTN_SWATCH, BTN_CHIP, BTN_ICON, BTN_PRIMARY, BTN_GHOST', { mono: true }]]],
    ['Stage stepper', [['ui::drawStepper()', { mono: true }]]],
    ['Toast messages', [['ui::toast(), ui::toastDraw()', { mono: true }]]],
    ['Confetti on the finish screen', [['spawnConfetti(), updateConfetti(), drawConfetti()', { mono: true }]]],
    ['Application logo', [['drawLogo()', { mono: true }], [' — a miniature cake with an animated flame']]],
  ],
  [0.38, 0.62]
));

/* 5 */
body.push(h1('5. Graphics Techniques Used'));

body.push(h2('5.1 Scan conversion'));
body.push(p('gfx.cpp contains honest implementations of the algorithms reviewed in the literature. They rasterise into GL_POINTS, one pixel at a time, rather than calling an OpenGL line primitive.'));
body.push(makeTable(
  ['Algorithm', 'Function', 'Where it is used'],
  [
    ['DDA', [['gfx::lineDDA()', { mono: true }]], 'The base outline in the scan conversion view'],
    ['Bresenham midpoint line', [['gfx::lineBresenham()', { mono: true }]], 'The top face outline of every straight sided shape, and the vertical extrusion edges'],
    ['Midpoint circle', [['gfx::circleMidpoint()', { mono: true }]], 'Available for circular outlines'],
    ['Midpoint ellipse', [['gfx::ellipseMidpoint()', { mono: true }]], 'The top face of a round cake in the scan conversion view'],
    ['Parametric point loop', [['gfx::circleParametric(), gfx::makeCircle(), gfx::makeEllipse()', { mono: true }]], 'Every round shape in the program'],
  ],
  [0.24, 0.34, 0.42]
));
body.push(p('Pressing A at run time switches the outline drawing over to these functions, so the discrete pixels can be seen on screen next to the finished cake. This makes the difference between the taught algorithm and the hardware primitive visible rather than merely claimed.', { before: 160 }));
body.push(...figure('shot_7_algorithm.png', 'The scan conversion view. Green marks the Bresenham line loop of the top face, blue the DDA base outline, and yellow the Bresenham extrusion edges.'));

body.push(h2('5.2 Colour models'));
body.push(p('gfx::rgb(), gfx::mix(), gfx::shade() and gfx::withAlpha() implement the RGB work; gfx::hsv() converts from hue, saturation and value, and is used to give each candy gem a different hue from a single integer seed.'));
body.push(p('A flavour is a cake::FlavorDef: seven RGB triples for the sponge, the dark sponge, the filling, the frosting, the frosting shadow, the drip and the accent. Choosing a flavour swaps the palette and the entire cake is redrawn from it. Stage two prints the red, green and blue components of the current frosting as three bars and as a hexadecimal value, so the numbers behind the picture are visible.'));
body.push(...figure('shot_3_flavour.png', 'Stage two. The panel shows the exact R, G and B components of the frosting; the strip under the cake shows the five colours the flavour supplies.'));

body.push(h2('5.3 Geometric transformation'));
body.push(p('Transformations go through the OpenGL matrix stack, wrapped by gfx::pushTransform() and gfx::popTransform():'));
body.push(...bullets([
  'Translation places each ingredient at the point the user clicked.',
  'Rotation gives each ingredient a small random tilt, swings the gift tag, tilts the candle flame and turns the loops of a bow.',
  'Scaling varies ingredient size, drives the pop in animation when a piece is first placed, and shrinks each tier of a stacked cake.',
]));
body.push(p('Ingredient positions are stored in the unit coordinate space of the base shape rather than in pixels, so a decorated cake survives a change of shape, a change of tier count and a resize of the window.'));
body.push(...figure('shot_4_toppings.png', 'Stage three. Fourteen ingredients placed on a square base; each is a composite object translated, rotated and scaled into position.'));

body.push(h2('5.4 Hidden surface ordering'));
body.push(p('The cake is drawn with the painter\u2019s algorithm. Tiers are drawn from the bottom up. Within a tier, only edges whose outward normal points towards the viewer are extruded into side faces. Ingredients are sorted back to front before being drawn, so a cherry near the front of the cake correctly overlaps one behind it. Packaging is split into a behind pass and a front pass so that a gift box surrounds the cake rather than hiding it.'));
body.push(p('The square and the rectangle are turned by twenty six and sixteen degrees respectively before the vertical squash is applied. Without that turn their top face and their front face are both axis aligned rectangles, and the cake reads as a flat wall; turned, two side faces meet at a front corner and the solid is immediately legible.'));
body.push(...figure('shot_5_wrap.png', 'Stage four. The gift box is drawn in two passes so that the back wall, side walls and lid sit behind the cake while the window front sits in front of it.'));

body.push(h2('5.5 Animation'));
body.push(p('glutTimerFunc drives a sixty hertz update. It advances a single clock, which the drawing code reads:'));
body.push(...bullets([
  'candle flames flicker from the sum of two sine waves at different frequencies,',
  'gems sparkle, cherries sway and bows breathe,',
  'the stage stepper pulses on the active step,',
  'buttons ease into their hover state,',
  'ingredients pop in with a short scale overshoot,',
  'confetti falls under gravity on the finish screen.',
]));

/* 6 */
body.push(h1('6. Interactive Functions'));
body.push(makeTable(
  ['Callback', 'Handler', 'Behaviour'],
  [
    [[['glutMouseFunc', { mono: true }]], [['app::onMouse()', { mono: true }]], 'Left click on a button, an option row or a chip; left click on the cake places an ingredient; right click removes the one under the cursor'],
    [[['glutMotionFunc', { mono: true }]], [['app::onMotion()', { mono: true }]], 'Dragging with the button held paints a trail of ingredients'],
    [[['glutPassiveMotionFunc', { mono: true }]], [['app::onMotion()', { mono: true }]], 'Updates the hover state of every button and the translucent preview of the ingredient about to be placed'],
    [[['glutKeyboardFunc', { mono: true }]], [['app::onKey()', { mono: true }]], 'Navigation, option selection with the number keys, undo, clear, scatter, reset, random, screenshot, help and quit'],
    [[['glutSpecialFunc', { mono: true }]], [['app::onSpecial()', { mono: true }]], 'Arrow keys to move between stages, F1 for help, F2 for a screenshot'],
    [[['glutReshapeFunc', { mono: true }]], [['app::computeLayout()', { mono: true }]], 'Recomputes the whole layout, so the window can be resized freely'],
    [[['glutTimerFunc', { mono: true }]], [['timer()', { mono: true }], [' in main.cpp']], 'The animation clock'],
  ],
  [0.24, 0.22, 0.54]
));
body.push(p('Buttons are clickable regions: a rectangle, a label and an identifier. ui::hitTest() compares the mouse position reported by glutMouseFunc against that rectangle, exactly as in the moving object exercises done earlier in the course. Mouse coordinates arrive with the origin at the top left, so app::onMouse() flips them once with y = height minus y; everything after that works in the usual mathematical orientation.', { before: 180 }));
body.push(p('Screen positions are converted back into cake coordinates by cake::screenToUV(), and gfx::pointInPoly() decides with the even odd rule whether the click landed on the frosted top of the cake.'));

body.push(h2('6.1 Control summary'));
body.push(makeTable(
  ['Input', 'Action'],
  [
    [[['Enter / N / Right arrow', { mono: true }]], 'Next stage'],
    [[['Backspace / B / Left arrow', { mono: true }]], 'Previous stage'],
    [[['1 to 8', { mono: true }]], 'Choose an option in the current stage'],
    ['Left click', 'Place the selected ingredient on the cake'],
    ['Left drag', 'Place a trail of ingredients'],
    ['Right click', 'Remove the ingredient under the cursor'],
    [[['U', { mono: true }]], 'Undo the last ingredient'],
    [[['C', { mono: true }]], 'Clear every ingredient'],
    [[['X', { mono: true }]], 'Scatter eight of the selected ingredient'],
    [[['A', { mono: true }]], 'Toggle the scan conversion view'],
    [[['P / F2', { mono: true }]], 'Save the window as a BMP picture'],
    [[['R', { mono: true }]], 'Reset the design'],
    [[['Z', { mono: true }]], 'Generate a random cake'],
    [[['H / F1', { mono: true }]], 'Show the control list'],
    [[['Esc', { mono: true }]], 'Quit'],
  ],
  [0.34, 0.66]
));

/* 7 */
body.push(h1('7. Results'));
body.push(p('The application runs at sixty frames per second in a resizable window of 1280 by 760 pixels. A user can move through the four stages in sequence and finish with a complete, uniquely designed cake, which can be saved as a BMP image with the P key.'));
body.push(p('The design space is large: five base shapes, with the polygon available in four variants, three tier counts, eight flavours, eight ingredient types placed freely up to eighty pieces, five packaging styles and six packaging colours.'));
body.push(makeTable(
  ['Measure', 'Value'],
  [
    ['Source files', '12 source files and 5 headers, about 5,300 lines of C++'],
    ['Compiler', 'MinGW g++ 8.1.0, C++11, clean under -Wall -Wextra'],
    ['Executable', 'About 1.2 MB, statically linked, depends only on Windows system libraries'],
    ['Frame rate', '60 frames per second, driven by glutTimerFunc at 16 ms'],
    ['Automated checks', '24 checks, 0 failures'],
  ],
  [0.28, 0.72]
));
body.push(p('Running the program with the --selftest switch drives it with synthetic input: every option of every stage, placing and removing ingredients on all five base shapes, every packaging style over every shape and tier count, the keyboard shortcuts, three window sizes and the finish screen. It reports twenty four checks with no failures.', { before: 180 }));
body.push(...figure('shot_1_welcome.png', 'The welcome screen, listing the group and summarising the techniques the project demonstrates.'));
body.push(...figure('shot_2_shape.png', 'Stage one. The base shape is chosen and the caption reports how the outline was generated.'));
body.push(...figure('shot_10_ribbon.png', 'A two tier butterscotch cake on an eight sided polygon base, finished with the ribbon and tag packaging.'));

/* 8 */
body.push(h1('8. Task Assignment'));
body.push(makeTable(
  ['Member', 'Responsibility', 'Files'],
  [
    ['Md. Minhaj Rowfun Rabbi Anik', 'Stage 1, shape selection: the shape catalogue, the polygon side control, the tier control and the outline annotations in the preview', [['src/stage_shape.cpp', { mono: true }]]],
    ['Adiba Howlader', 'Stage 2, flavour and colour: the eight flavour palettes, the swatch icons, the RGB readout and the palette strip under the cake', [['src/stage_flavor.cpp', { mono: true }]]],
    ['Md. Tanvir Hasan', 'Stage 3, ingredient placement: the placement and removal logic, drag placement, undo, clear and scatter, and the ingredient previews', [['src/stage_toppings.cpp', { mono: true }]]],
    ['Abdur Rahman', 'Stage 4, wrapping and packaging, and overall integration: the four packaging styles, the colour chips, and joining the four stages into one flow', [['src/stage_wrap.cpp', { mono: true }], [' and '], ['src/app.cpp', { mono: true }]]],
  ],
  [0.26, 0.52, 0.22]
));
body.push(p('The shared foundation — gfx, ui, cake, toppings and wrapping — was written together, since all four stages depend on it. A stage is described by a StageDef structure: a title and a handful of callbacks. The shell in app.cpp knows nothing about cherries or ribbons, and a stage knows nothing about the window layout, which is what allowed the four members to work on one stage each without colliding.', { before: 180 }));

/* 9 */
body.push(h1('9. Conclusion'));
body.push(p('CakeLab brings the separate laboratory exercises of the semester together into one working application. Scan conversion, the RGB colour model, geometric transformation, composite objects, animation and event driven interaction all appear in it, not as demonstrations standing on their own but as the parts that make the program work.'));
body.push(p('The staged pattern used here — choose a shape, choose a colour, add detail, finish with a package — is general. The same code structure would carry over to designing greeting cards, gift boxes or simple avatars, since only the catalogue of shapes and the catalogue of decorations would change.'));

/* refs */
body.push(h1('References'));
body.push(...numbered([
  'Foley, J., van Dam, A., Feiner, S. and Hughes, J. Computer Graphics: Principles and Practice. 2nd ed. Addison Wesley. Reviewed for scan conversion of lines and circles and for the structure of the rendering pipeline.',
  'Schaum\u2019s Outline of Theory and Problems of Computer Graphics. Reviewed for the incremental line and circle drawing methods, including the DDA algorithm and Bresenham\u2019s midpoint algorithm.',
  'Shirley, P. and Marschner, S. Fundamentals of Computer Graphics. 3rd ed. Reviewed for colour models, geometric transformations and the OpenGL programming model.',
], 'refs'));

/* ------------------------------------------------------------ assemble */
const margins = {
  top: convertInchesToTwip(1), bottom: convertInchesToTwip(1),
  left: convertInchesToTwip(1), right: convertInchesToTwip(1),
};

const doc = new Document({
  creator: 'Group E, CSC 3224',
  title: 'CakeLab Project Report',
  description: 'An Interactive 2D Cake Customization Game Built with Computer Graphics Primitives',
  numbering: {
    config: [
      {
        reference: 'bullets',
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: '\u2022', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
      {
        reference: 'nums',
        levels: [{
          level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
      {
        reference: 'refs',
        levels: [{
          level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
    ],
  },
  styles: {
    default: {
      document: { run: { font: BODY_FONT, size: 24 } },
    },
  },
  sections: [
    { properties: { page: { margin: margins } }, children: cover },
    {
      properties: { page: { margin: margins, pageNumbers: { start: 1 } } },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.RIGHT,
            spacing: { after: 60 },
            border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'B4C6E7' } },
            children: [new TextRun({
              text: 'CakeLab — CSC 3224 Computer Graphics — Group E',
              font: BODY_FONT, size: 18, color: '666666',
            })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ children: ['Page ', PageNumber.CURRENT], font: BODY_FONT, size: 18, color: '666666' })],
          })],
        }),
      },
      children: body,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUT, buf);
  console.log('wrote', OUT, (buf.length / 1024).toFixed(0) + ' kB,', figureNo, 'figures');
});
