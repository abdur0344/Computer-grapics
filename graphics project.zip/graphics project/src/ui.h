/* ============================================================================
 *  CakeLab  -  ui.h
 *  The interface furniture: colour theme, clickable buttons, panels, the stage
 *  stepper and the toast messages.
 *
 *  A button is nothing more than a rectangle with a label and an identifier.
 *  Hit testing compares the mouse position from glutMouseFunc against that
 *  rectangle, which is the "clickable region" approach used in the moving
 *  object exercises earlier in the course.
 * ==========================================================================*/
#ifndef CAKELAB_UI_H
#define CAKELAB_UI_H

#include "gfx.h"
#include <string>
#include <vector>

namespace ui {

using gfx::Color;
using gfx::Vec2;

/* ------------------------------------------------------------------ theme */
struct Theme {
    Color bgBottom, bgTop;          /* window backdrop gradient          */
    Color stageInner, stageOuter;   /* preview area vignette             */
    Color panel, panelEdge, panelHi;
    Color text, textDim, textFaint;
    Color accent, accentDark, accent2;
    Color ok, danger;
    Color plate, plateEdge;
};
extern Theme T;
void initTheme();

/* ------------------------------------------------------------------ icons */
/*  A button may draw a small pictogram in its icon slot. The stage modules
 *  supply the function, so ui.cpp never needs to know what a cherry is.     */
typedef void (*IconFn)(Vec2 centre, float size, float time, int arg);

/* ---------------------------------------------------------------- buttons */
enum ButtonStyle {
    BTN_OPTION,    /* tall list row with icon, title and subtitle */
    BTN_SWATCH,    /* list row whose icon slot is a colour chip   */
    BTN_PRIMARY,   /* filled call-to-action                       */
    BTN_GHOST,     /* outlined secondary action                   */
    BTN_CHIP,      /* small pill                                  */
    BTN_ICON       /* square icon-only button                     */
};

struct Button {
    float x, y, w, h;
    int   id;
    std::string label;
    std::string sub;
    ButtonStyle style;
    Color  tint;
    IconFn icon;
    int    iconArg;
    bool   enabled;
    bool   selected;
    bool   visible;
    float  hoverAnim;   /* 0..1, eased towards the hover state each frame */
    float  pressAnim;   /* 0..1, decays after a click                     */

    Button();
};

Button makeButton(float x, float y, float w, float h, int id,
                  const std::string& label, ButtonStyle style = BTN_OPTION);

bool hitTest(const Button& b, float mx, float my);
int  hitIndex(const std::vector<Button>& list, float mx, float my);
void animateButtons(std::vector<Button>& list, float mx, float my, float dt);
void drawButton(const Button& b, float time);
void drawButtons(const std::vector<Button>& list, float time);

/* ----------------------------------------------------------------- panels */
void drawBackdrop(float w, float h, float time);
void drawPanel(float x, float y, float w, float h, float radius = 16.0f);
void drawPanelTinted(float x, float y, float w, float h, float radius,
                     const Color& fill, const Color& edge);
void drawSectionLabel(float x, float y, const std::string& s);
void drawDivider(float x, float y, float w);

/* ---------------------------------------------------------------- stepper */
void drawStepper(float x, float y, float w, float h,
                 const std::vector<std::string>& names, int current,
                 int furthestReached, float time);

/* ------------------------------------------------------------- decoration */
void drawCheck(Vec2 centre, float size, const Color& c, float weight = 2.5f);
void drawChevron(Vec2 centre, float size, float dirDeg, const Color& c, float weight = 2.5f);
void drawSparkle(Vec2 centre, float size, const Color& c);
void drawKeyCap(float x, float y, const std::string& key, const Color& c);

/* ----------------------------------------------------------------- toasts */
void toast(const std::string& msg);
void toastUpdate(float dt);
void toastDraw(float screenW, float baseY);

/* ------------------------------------------------------------ text layout */
/*  Wraps a paragraph to a pixel width and draws it downwards from y.        */
float drawWrapped(float x, float y, float maxWidth, const std::string& s,
                  const Color& c, gfx::FontId f, float lineGap = 5.0f);

} /* namespace ui */

#endif /* CAKELAB_UI_H */
