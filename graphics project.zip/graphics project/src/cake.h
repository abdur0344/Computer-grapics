/* ============================================================================
 *  CakeLab  -  cake.h
 *  The design the user is building, and the renderer that turns it into a
 *  picture.
 *
 *  A cake is described entirely by data: a base shape, a flavour, a list of
 *  toppings and a wrapping style. Nothing about the drawing is stored, so the
 *  same Design can be redrawn at any size, in the preview panel or on the
 *  finish screen.
 *
 *  The renderer builds a shallow pseudo-3D look out of flat 2D primitives:
 *    - the base shape is generated as an outline in unit coordinates,
 *    - that outline is squashed vertically to suggest a surface seen from
 *      slightly above,
 *    - edges whose outward normal points towards the viewer are extruded
 *      downwards into the side of the cake,
 *    - frosting, drips and toppings are layered on top.
 * ==========================================================================*/
#ifndef CAKELAB_CAKE_H
#define CAKELAB_CAKE_H

#include "gfx.h"
#include <vector>
#include <string>

namespace cake {

using gfx::Vec2;
using gfx::Color;

/* ------------------------------------------------------------ catalogues */
enum ShapeType {
    SHAPE_CIRCLE = 0, SHAPE_SQUARE, SHAPE_TRIANGLE, SHAPE_RECT, SHAPE_POLYGON,
    SHAPE_COUNT
};

enum FlavorId {
    FLV_STRAWBERRY = 0, FLV_GREEN, FLV_BLACKFOREST, FLV_REDVELVET,
    FLV_MANGO, FLV_CHOCOLATE, FLV_VANILLA, FLV_BUTTERSCOTCH,
    FLV_COUNT
};

enum ToppingId {
    TOP_BERRY = 0, TOP_BISCUIT, TOP_PEANUT, TOP_CHERRY,
    TOP_FRUIT, TOP_CHOCOLATE, TOP_GEM, TOP_CANDLE,
    TOP_COUNT
};

enum WrapId {
    WRAP_NONE = 0, WRAP_ROPE, WRAP_BOX, WRAP_SHEET, WRAP_RIBBON,
    WRAP_COUNT
};

struct ShapeDef   { const char* name; const char* note; };
struct FlavorDef  {
    const char* name;
    const char* note;
    Color sponge, spongeDark, filling;   /* the body of the cake      */
    Color cream, creamDeep, drip;        /* the frosting on top       */
    Color accent;                        /* piping and small details  */
};
struct ToppingDef { const char* name; const char* note; };
struct WrapDef    { const char* name; const char* note; };

const ShapeDef&   shapeDef(int id);
const FlavorDef&  flavorDef(int id);
const ToppingDef& toppingDef(int id);
const WrapDef&    wrapDef(int id);

int          wrapPaletteSize();
Color        wrapPaletteColor(int i);
const char*  wrapPaletteName(int i);

/* --------------------------------------------------------------- design */
struct Placed {
    int   type;
    float u, v;     /* position on the top surface, in unit shape coordinates */
    float rot;      /* orientation in degrees                                 */
    float scale;    /* relative size                                          */
    int   variant;  /* seed for the small deterministic details               */
    float born;     /* time of placement, used for the pop-in animation       */
    Placed() : type(0), u(0), v(0), rot(0), scale(1.0f), variant(0), born(0) {}
};

struct Design {
    int shape;
    int polySides;      /* used when shape == SHAPE_POLYGON, 5..8 */
    int layers;         /* 1..3 stacked tiers                     */
    int flavor;
    std::vector<Placed> toppings;
    int wrap;
    int wrapColor;

    Design();
    void reset();
    bool hasCandle() const;
    int  countOf(int toppingType) const;
};

/* ------------------------------------------------------------- geometry */
/*  Unit outline: a closed loop of points describing the chosen base shape,
 *  roughly inscribed in a circle of radius 1 about the origin.             */
void shapeOutlineUnit(std::vector<Vec2>& out, const Design& d, int steps = 72);
bool insideUnitShape(const Design& d, Vec2 uv, float margin = 0.90f);

/*  Where the cake is drawn and how big it is.                              */
struct Frame {
    Vec2  centre;        /* centre of the bottom tier, at plate height */
    float radius;        /* pixels per unit in x                       */
    float squash;        /* vertical foreshortening of a top face      */
    float layerHeight;   /* height in pixels of one tier               */
};
Frame makeFrame(Vec2 centre, float radius, int layers);

float layerScale(const Design& d, int layerIndex);
float topElevation(const Design& d, const Frame& f);
Vec2  topCentre(const Design& d, const Frame& f);
Vec2  uvToScreen(const Design& d, const Frame& f, Vec2 uv);
bool  screenToUV(const Design& d, const Frame& f, Vec2 screen, Vec2& uvOut);
float toppingPixelSize(const Design& d, const Frame& f);

/* ------------------------------------------------------------ rendering */
struct RenderOpts {
    float time;
    bool  showToppings;
    bool  showWrap;
    bool  showPlate;
    bool  highlightSurface;   /* pulse the top face while placing toppings   */
    bool  algorithmView;      /* redraw outlines with the scan converters    */
    int   ghostTopping;       /* -1, or a topping drawn faintly at the mouse */
    Vec2  ghostUV;
    bool  ghostValid;
    int   selectedTopping;    /* index into Design::toppings, or -1          */
    RenderOpts();
};

void drawCake(const Design& d, const Frame& f, const RenderOpts& o);

/*  Individual pieces, also used to draw the little previews on the buttons. */
void drawTopping(int type, Vec2 centre, float size, float rotDeg, int variant,
                 float time, float alpha = 1.0f);
void drawShapeIcon(int shapeId, int polySides, Vec2 centre, float size, const Color& c);
void drawWrapBehind(const Design& d, const Frame& f, float time);
void drawWrapFront(const Design& d, const Frame& f, float time);
void drawWrapIcon(int wrapId, Vec2 centre, float size, const Color& tint, float time);

/*  A compact one-line description such as "Round, red velvet, 6 toppings".  */
std::string describe(const Design& d);

} /* namespace cake */

#endif /* CAKELAB_CAKE_H */
