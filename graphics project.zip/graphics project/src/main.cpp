/* ============================================================================
 *  CakeLab  -  main.cpp
 *  An interactive 2D cake customisation game built with computer graphics
 *  primitives.
 *
 *  Course     : CSC 3224, Computer Graphics
 *  Group      : E
 *  Members    : Md. Minhaj Rowfun Rabbi Anik, Adiba Howlader,
 *               Md. Tanvir Hasan, Abdur Rahman
 *  Supervisor : Dr. Mohammad Nazmul Alam
 *  Department of Computer Science, Faculty of Science and Technology,
 *  American International University Bangladesh.
 *
 *  This file contains only the GLUT plumbing. Every callback forwards to the
 *  application shell in app.cpp:
 *
 *    glutDisplayFunc        -> app::draw
 *    glutReshapeFunc        -> app::computeLayout
 *    glutMouseFunc          -> app::onMouse
 *    glutMotionFunc         -> app::onMotion   (a button is held down)
 *    glutPassiveMotionFunc  -> app::onMotion   (no button held)
 *    glutKeyboardFunc       -> app::onKey
 *    glutSpecialFunc        -> app::onSpecial
 *    glutTimerFunc          -> the animation clock
 * ==========================================================================*/
#include "app.h"
#include "screenshot.h"
#include <GL/freeglut.h>
#include <cstdio>
#include <cstring>

/*  The GL headers shipped with MinGW stop at OpenGL 1.1, so the multisample
 *  token is spelled out here. The driver itself is far newer and honours it. */
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE 0x809D
#endif

static const int kInitialWidth  = 1280;
static const int kInitialHeight = 760;
static const int kFrameMs       = 16;      /* about 60 updates per second */

static int g_lastMs = 0;

/* ---------------------------------------------------------------------------
 *  Capture mode.  Running "CakeLab.exe --capture" steps through every screen,
 *  writes a BMP of each one and exits. It is only a convenience for putting
 *  figures into the report; the interactive program does not use it.
 * ------------------------------------------------------------------------ */
static bool g_capture     = false;
static int  g_captureStep = 0;
static int  g_captureHold = 0;

static void display();
static void reshape(int w, int h);

static void captureDesign(int shape, int sides, int layers, int flavor,
                          int wrap, int wrapColor, int toppingCount) {
    app::g_design.reset();
    app::g_design.shape     = shape;
    app::g_design.polySides = sides;
    app::g_design.layers    = layers;
    app::g_design.flavor    = flavor;
    app::g_design.wrap      = wrap;
    app::g_design.wrapColor = wrapColor;

    int guard = 0;
    while ((int)app::g_design.toppings.size() < toppingCount && guard < 800) {
        ++guard;
        float u = gfx::hash21((float)guard * 1.7f, 4.3f) * 2.2f - 1.1f;
        float v = gfx::hash21(2.9f, (float)guard * 3.1f) * 2.2f - 1.1f;
        gfx::Vec2 uv(u, v);
        if (!cake::insideUnitShape(app::g_design, uv, 0.82f)) continue;
        cake::Placed p;
        p.type    = guard % cake::TOP_COUNT;
        p.u       = uv.x;
        p.v       = uv.y;
        p.variant = guard;
        p.rot     = (gfx::hash11((float)guard * 2.3f) - 0.5f) * 22.0f;
        p.scale   = 0.88f + 0.28f * gfx::hash11((float)guard * 5.9f);
        p.born    = -10.0f;
        if (p.type == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
        app::g_design.toppings.push_back(p);
    }
}

static const int kCaptureCount = 10;

static const char* applyCaptureStep(int step) {
    app::g_algorithmView = false;
    switch (step) {
        case 0:
            app::g_screen = app::SCREEN_WELCOME;
            return "shot_1_welcome.bmp";
        case 1:
            captureDesign(cake::SHAPE_CIRCLE, 6, 1, cake::FLV_STRAWBERRY,
                          cake::WRAP_NONE, 0, 0);
            app::goToStage(0);
            return "shot_2_shape.bmp";
        case 2:
            captureDesign(cake::SHAPE_POLYGON, 6, 2, cake::FLV_REDVELVET,
                          cake::WRAP_NONE, 0, 0);
            app::goToStage(1);
            return "shot_3_flavour.bmp";
        case 3:
            captureDesign(cake::SHAPE_SQUARE, 6, 1, cake::FLV_CHOCOLATE,
                          cake::WRAP_NONE, 0, 14);
            app::goToStage(2);
            return "shot_4_toppings.bmp";
        case 4:
            captureDesign(cake::SHAPE_CIRCLE, 6, 2, cake::FLV_MANGO,
                          cake::WRAP_BOX, 1, 10);
            app::goToStage(3);
            return "shot_5_wrap.bmp";
        case 5:
            captureDesign(cake::SHAPE_CIRCLE, 6, 3, cake::FLV_BLACKFOREST,
                          cake::WRAP_RIBBON, 0, 16);
            app::goToStage(3);
            app::finish();
            return "shot_6_finish.bmp";
        case 6:
            captureDesign(cake::SHAPE_TRIANGLE, 6, 1, cake::FLV_GREEN,
                          cake::WRAP_NONE, 0, 6);
            app::goToStage(0);
            app::g_algorithmView = true;
            return "shot_7_algorithm.bmp";
        case 7:
            captureDesign(cake::SHAPE_RECT, 6, 1, cake::FLV_VANILLA,
                          cake::WRAP_ROPE, 3, 8);
            app::goToStage(3);
            return "shot_8_rope.bmp";
        case 8:
            captureDesign(cake::SHAPE_CIRCLE, 6, 1, cake::FLV_STRAWBERRY,
                          cake::WRAP_SHEET, 4, 8);
            app::goToStage(3);
            return "shot_9_sheet.bmp";
        default:
            captureDesign(cake::SHAPE_POLYGON, 8, 2, cake::FLV_BUTTERSCOTCH,
                          cake::WRAP_RIBBON, 2, 12);
            app::goToStage(3);
            return "shot_10_ribbon.bmp";
    }
}

static void captureTick() {
    static const char* pending = 0;
    if (g_captureHold == 0) pending = applyCaptureStep(g_captureStep);

    app::g_mouseX = -500.0f;
    app::g_mouseY = -500.0f;
    app::update(1.0f / 60.0f);
    display();

    if (++g_captureHold >= 10) {
        if (shot::saveBMP(pending, 0, 0, (int)app::L.W, (int)app::L.H))
            std::printf("wrote %s\n", pending);
        else
            std::printf("could not write %s\n", pending);
        std::fflush(stdout);
        g_captureHold = 0;
        if (++g_captureStep >= kCaptureCount) glutLeaveMainLoop();
    }
}

/* ---------------------------------------------------------------------------
 *  Self test.  "CakeLab.exe --selftest" drives the whole program with
 *  synthetic input: every option of every stage, placing and removing
 *  ingredients, the keyboard shortcuts, two window sizes and the finish
 *  screen. It reports a pass or fail count and exits. It is a development
 *  aid, run before handing the project in.
 * ------------------------------------------------------------------------ */
static bool g_selftest = false;
static int  g_checks   = 0;
static int  g_failures = 0;

static void check(bool ok, const char* what) {
    ++g_checks;
    if (!ok) {
        ++g_failures;
        std::printf("  FAIL  %s\n", what);
    }
}

/*  Feeds a click at a point given in the bottom-left origin used by the rest
 *  of the program, converting to the top-left origin GLUT reports.          */
static void clickAt(float x, float yFromBottom, int button) {
    int my = (int)(app::L.H - yFromBottom);
    app::onMotion((int)x, my);
    app::onMouse(button, GLUT_DOWN, (int)x, my);
    app::onMouse(button, GLUT_UP,   (int)x, my);
}

static void selfTestRun() {
    std::printf("CakeLab self test\n");

    /* every option of every stage */
    for (int stage = 0; stage < app::STAGE_COUNT; ++stage) {
        app::goToStage(stage);
        check(app::g_stage == stage, "goToStage set the stage");
        size_t options = app::g_options.size();
        check(options > 0, "stage built at least one option");
        for (size_t i = 0; i < options; ++i) {
            app::activateOption((int)i);
            display();
        }
        for (size_t i = 0; i < app::g_extras.size(); ++i) {
            if (!app::g_extras[i].enabled) continue;
            clickAt(app::g_extras[i].x + app::g_extras[i].w * 0.5f,
                    app::g_extras[i].y + app::g_extras[i].h * 0.5f, GLUT_LEFT_BUTTON);
            display();
        }
    }

    /* placing and removing ingredients */
    app::goToStage(2);
    app::toppingsClear();
    cake::Frame f = app::previewFrame();
    gfx::Vec2 top = cake::topCentre(app::g_design, f);
    size_t before = app::g_design.toppings.size();
    clickAt(top.x, top.y, GLUT_LEFT_BUTTON);
    check(app::g_design.toppings.size() == before + 1, "left click placed an ingredient");

    clickAt(top.x, top.y, GLUT_RIGHT_BUTTON);
    check(app::g_design.toppings.size() == before, "right click removed it again");

    clickAt(f.centre.x, f.centre.y - f.radius * 2.0f, GLUT_LEFT_BUTTON);
    check(app::g_design.toppings.size() == before, "a click off the cake places nothing");

    app::toppingsScatter();
    check(app::g_design.toppings.size() > before, "scatter added ingredients");
    size_t scattered = app::g_design.toppings.size();
    app::toppingsUndo();
    check(app::g_design.toppings.size() == scattered - 1, "undo removed exactly one");
    app::toppingsClear();
    check(app::g_design.toppings.empty(), "clear emptied the cake");

    /*  Every base shape must accept a click at the centre of its top face,
     *  and must survive being asked for its outline.                        */
    for (int shape = 0; shape < cake::SHAPE_COUNT; ++shape) {
        app::g_design.shape = shape;
        app::rebuildStage();
        f = app::previewFrame();
        top = cake::topCentre(app::g_design, f);
        app::toppingsClear();
        clickAt(top.x, top.y, GLUT_LEFT_BUTTON);
        check(app::g_design.toppings.size() == 1, cake::shapeDef(shape).name);
        display();
    }
    app::toppingsClear();

    /* keyboard shortcuts, excluding the ones that quit or write files */
    const char* keys = "nbrzaxuc123456789hH";
    for (const char* k = keys; *k; ++k) {
        app::onKey((unsigned char)*k, 0, 0);
        display();
    }
    app::onSpecial(GLUT_KEY_RIGHT, 0, 0);
    app::onSpecial(GLUT_KEY_LEFT, 0, 0);
    app::onSpecial(GLUT_KEY_F1, 0, 0);
    app::onKey('h', 0, 0);
    display();
    check(true, "keyboard handling did not crash");

    /* every wrapping style over every shape */
    for (int wrap = 0; wrap < cake::WRAP_COUNT; ++wrap) {
        for (int shape = 0; shape < cake::SHAPE_COUNT; ++shape) {
            app::g_design.wrap = wrap;
            app::g_design.shape = shape;
            for (int layers = 1; layers <= 3; ++layers) {
                app::g_design.layers = layers;
                display();
            }
        }
    }
    check(true, "every wrapping, shape and tier count rendered");

    /* the window at three sizes */
    int sizes[3][2] = { { 1024, 640 }, { 1600, 900 }, { 1280, 760 } };
    for (int i = 0; i < 3; ++i) {
        reshape(sizes[i][0], sizes[i][1]);
        display();
    }
    check(app::L.W > 0.0f && app::L.H > 0.0f, "layout survived resizing");

    app::finish();
    display();
    check(app::g_screen == app::SCREEN_FINISH, "finish screen reached");
    app::resetDesign();
    check(app::g_design.toppings.empty(), "reset cleared the design");

    std::printf("%d checks, %d failures\n", g_checks, g_failures);
    std::printf(g_failures == 0 ? "SELFTEST PASS\n" : "SELFTEST FAIL\n");
    std::fflush(stdout);
}

static void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    gfx::begin2D((int)app::L.W, (int)app::L.H);
    app::draw();
    glutSwapBuffers();
}

static void reshape(int w, int h) {
    if (w < 1) w = 1;
    if (h < 1) h = 1;
    app::computeLayout(w, h);
    app::rebuildStage();
    gfx::begin2D(w, h);
    glutPostRedisplay();
}

static void timer(int value) {
    int now = glutGet(GLUT_ELAPSED_TIME);
    float dt = (float)(now - g_lastMs) / 1000.0f;
    g_lastMs = now;
    if (dt > 0.10f) dt = 0.10f;          /* never take a huge step */
    if (dt < 0.0f)  dt = 0.0f;

    if (g_selftest) {
        selfTestRun();
        glutLeaveMainLoop();
        return;
    }
    if (g_capture) {
        captureTick();
        glutTimerFunc(1, timer, value);
        return;
    }

    app::update(dt);
    glutPostRedisplay();
    glutTimerFunc(kFrameMs, timer, value);
}

static void mouse(int button, int state, int x, int y) {
    app::onMouse(button, state, x, y);
    glutPostRedisplay();
}

static void motion(int x, int y) {
    app::onMotion(x, y);
}

static void keyboard(unsigned char key, int x, int y) {
    app::onKey(key, x, y);
    glutPostRedisplay();
}

static void special(int key, int x, int y) {
    app::onSpecial(key, x, y);
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    for (int i = 1; i < argc; ++i)
    {
        if (std::strcmp(argv[i], "--capture")  == 0) g_capture  = true;
        if (std::strcmp(argv[i], "--selftest") == 0) g_selftest = true;
    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_MULTISAMPLE);
    glutInitWindowSize(kInitialWidth, kInitialHeight);
    glutInitWindowPosition(60, 30);
    glutCreateWindow("CakeLab  -  Interactive 2D Cake Customisation  -  CSC 3224");

    /*  Closing the window returns from glutMainLoop instead of killing the
     *  process, so the program can shut down tidily.                        */
    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

    glEnable(GL_MULTISAMPLE);
    gfx::enableBlend();
    glClearColor(0.086f, 0.055f, 0.102f, 1.0f);

    app::computeLayout(kInitialWidth, kInitialHeight);
    app::init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutPassiveMotionFunc(motion);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);

    g_lastMs = glutGet(GLUT_ELAPSED_TIME);
    glutTimerFunc(kFrameMs, timer, 0);

    std::printf("CakeLab started. Press H inside the window for the control list.\n");
    glutMainLoop();
    return g_failures == 0 ? 0 : 1;
}
