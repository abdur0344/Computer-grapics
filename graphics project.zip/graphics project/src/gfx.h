/* ============================================================================
 *  CakeLab  -  gfx.h
 *  Course     : CSC 3224, Computer Graphics
 *  Purpose    : Reusable 2D drawing toolkit built on OpenGL / freeGLUT.
 *
 *  Everything CakeLab draws goes through this file. It provides three things:
 *
 *    1. Scan conversion  - DDA line, Bresenham midpoint line, midpoint circle
 *                          and midpoint ellipse. These rasterise into GL_POINTS
 *                          one pixel at a time, exactly as taught in class,
 *                          instead of relying on GL_LINES.
 *    2. Composite shapes - filled circles, ellipses, polygons, rounded rects,
 *                          arcs, stars and capsules, all generated from a
 *                          parametric point loop (no built-in circle call).
 *    3. Colour and text  - RGB / HSV colour model helpers and GLUT font output.
 *
 *  Coordinate system: origin at the bottom-left of the window, y increasing
 *  upwards, one unit == one pixel (set up by begin2D).
 * ==========================================================================*/
#ifndef CAKELAB_GFX_H
#define CAKELAB_GFX_H

#include <GL/freeglut.h>
#include <vector>
#include <string>
#include <cmath>

namespace gfx {

const float PI = 3.14159265358979323846f;

/* ---------------------------------------------------------------- vectors */
struct Vec2 {
    float x, y;
    Vec2() : x(0.0f), y(0.0f) {}
    Vec2(float ax, float ay) : x(ax), y(ay) {}
};

inline Vec2 operator+(const Vec2& a, const Vec2& b) { return Vec2(a.x + b.x, a.y + b.y); }
inline Vec2 operator-(const Vec2& a, const Vec2& b) { return Vec2(a.x - b.x, a.y - b.y); }
inline Vec2 operator*(const Vec2& a, float s)       { return Vec2(a.x * s, a.y * s); }
inline Vec2 operator*(float s, const Vec2& a)       { return Vec2(a.x * s, a.y * s); }
inline float dot(const Vec2& a, const Vec2& b)      { return a.x * b.x + a.y * b.y; }
inline float length(const Vec2& a)                  { return std::sqrt(a.x * a.x + a.y * a.y); }
Vec2  normalize(const Vec2& a);
Vec2  perp(const Vec2& a);                 /* rotate 90 degrees counter-clockwise */
Vec2  rotated(const Vec2& a, float deg);   /* rotation about the origin          */

/* ----------------------------------------------------------------- colour */
/*  The RGB colour model from the Image Representation chapter. Components are
 *  kept in the 0..1 range that OpenGL expects; rgb() converts from the 0..255
 *  byte form that is easier to read when picking a palette.                  */
struct Color {
    float r, g, b, a;
    Color() : r(0.0f), g(0.0f), b(0.0f), a(1.0f) {}
    Color(float R, float G, float B, float A = 1.0f) : r(R), g(G), b(B), a(A) {}
};

Color rgb(int r, int g, int b);
Color rgba(int r, int g, int b, float a);
Color mix(const Color& a, const Color& b, float t);   /* linear interpolation   */
Color shade(const Color& c, float factor);            /* darken / lighten       */
Color withAlpha(const Color& c, float a);
Color hsv(float h, float s, float v, float a = 1.0f); /* HSV -> RGB conversion  */
void  useColor(const Color& c);

/* -------------------------------------------------------- scan conversion */
/*  Each of these walks the shape one pixel at a time and emits a GL_POINTS
 *  vertex, which is what the rasteriser in the course notes does. They are
 *  slower than the GL primitives but they are the honest implementation, and
 *  the application can switch to them at run time (the "algorithm view").    */
void lineDDA(Vec2 a, Vec2 b, const Color& c, float pointSize = 1.0f);
void lineBresenham(Vec2 a, Vec2 b, const Color& c, float pointSize = 1.0f);
void circleMidpoint(Vec2 centre, float r, const Color& c, float pointSize = 1.0f);
void ellipseMidpoint(Vec2 centre, float rx, float ry, const Color& c, float pointSize = 1.0f);
void circleParametric(Vec2 centre, float r, const Color& c, int steps = 180, float pointSize = 1.0f);
void polylineBresenham(const std::vector<Vec2>& pts, const Color& c, bool closed, float pointSize = 1.0f);

/* ------------------------------------------------------ outline generators */
/*  A circle is built from a parametric point loop, never from a library call.
 *  Every other rounded shape in CakeLab reuses this loop.                    */
void makeCircle(std::vector<Vec2>& out, Vec2 centre, float r, int steps = 64);
void makeEllipse(std::vector<Vec2>& out, Vec2 centre, float rx, float ry, int steps = 64);
void makeRegularPolygon(std::vector<Vec2>& out, Vec2 centre, float r, int sides, float rotDeg = 0.0f);
void makeRoundRect(std::vector<Vec2>& out, float x, float y, float w, float h, float r, int cornerSteps = 6);
void makeStar(std::vector<Vec2>& out, Vec2 centre, float rOuter, float rInner, int points, float rotDeg = 0.0f);
void makeBezier(std::vector<Vec2>& out, Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, int steps = 24);

/* ------------------------------------------------------------ filled work */
void line(Vec2 a, Vec2 b, const Color& c, float width = 1.0f);
void polyline(const std::vector<Vec2>& pts, const Color& c, float width = 1.0f, bool closed = false);
void fillPoly(const std::vector<Vec2>& pts, const Color& c);
void fillPolyGrad(const std::vector<Vec2>& pts, Vec2 centre, const Color& inner, const Color& outer);
void fillPolyGradV(const std::vector<Vec2>& pts, const Color& bottom, const Color& top);
void strokePoly(const std::vector<Vec2>& pts, const Color& c, float width = 1.0f);

void fillCircle(Vec2 centre, float r, const Color& c, int steps = 48);
void fillCircleGrad(Vec2 centre, float r, const Color& inner, const Color& outer, int steps = 48);
void fillEllipse(Vec2 centre, float rx, float ry, const Color& c, int steps = 48);
void fillEllipseGrad(Vec2 centre, float rx, float ry, const Color& inner, const Color& outer, int steps = 48);
void strokeCircle(Vec2 centre, float r, const Color& c, float width = 1.0f, int steps = 48);
void ring(Vec2 centre, float rInner, float rOuter, const Color& c, int steps = 48);
void fillArc(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, int steps = 32);
void arcStroke(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, float width = 1.0f, int steps = 32);

void fillRect(float x, float y, float w, float h, const Color& c);
void fillRectGradV(float x, float y, float w, float h, const Color& bottom, const Color& top);
void fillRectGradH(float x, float y, float w, float h, const Color& left, const Color& right);
void strokeRect(float x, float y, float w, float h, const Color& c, float width = 1.0f);
void fillRoundRect(float x, float y, float w, float h, float r, const Color& c);
void fillRoundRectGradV(float x, float y, float w, float h, float r, const Color& bottom, const Color& top);
void strokeRoundRect(float x, float y, float w, float h, float r, const Color& c, float width = 1.0f);

void fillTri(Vec2 a, Vec2 b, Vec2 c, const Color& col);
void fillRegularPolygon(Vec2 centre, float r, int sides, float rotDeg, const Color& c);
void fillStar(Vec2 centre, float rOuter, float rInner, int points, float rotDeg, const Color& c);
void fillCapsule(Vec2 a, Vec2 b, float r, const Color& c);
void softShadow(Vec2 centre, float rx, float ry, float alpha, int steps = 40);

/* ------------------------------------------------------------------- text */
enum FontId { FONT_XS, FONT_S, FONT_M, FONT_L };

float textWidth(const std::string& s, FontId f);
float textHeight(FontId f);
void  text(float x, float y, const std::string& s, const Color& c, FontId f = FONT_M);
void  textCentered(float cx, float y, const std::string& s, const Color& c, FontId f = FONT_M);
void  textRight(float rx, float y, const std::string& s, const Color& c, FontId f = FONT_M);

/*  Stroke fonts are real geometry, so they scale and rotate with the matrix
 *  stack. CakeLab uses them for headings.                                    */
float strokeTextWidth(const std::string& s, float size);
void  strokeText(float x, float y, const std::string& s, const Color& c, float size, float weight = 1.5f);
void  strokeTextCentered(float cx, float y, const std::string& s, const Color& c, float size, float weight = 1.5f);

/* ------------------------------------------------- transforms and clipping */
/*  Geometric transformation, applied through the OpenGL matrix stack:
 *  translate to place an object, rotate to orient it, scale to size it.      */
void pushTransform(Vec2 translate, float rotDeg = 0.0f, float scaleX = 1.0f, float scaleY = 1.0f);
void popTransform();
void pushScissor(float x, float y, float w, float h);
void popScissor();

/* ----------------------------------------------------------- setup / math */
void  begin2D(int w, int h);
void  enableBlend();

float clampf(float v, float lo, float hi);
float lerpf(float a, float b, float t);
float smoothstep(float edge0, float edge1, float x);
float deg2rad(float d);
float rad2deg(float r);
bool  pointInPoly(const std::vector<Vec2>& poly, Vec2 p);

/*  Deterministic pseudo-random helpers. A cake must look identical from one
 *  frame to the next, so std::rand is never used inside a draw call.         */
float hash11(float x);
float hash21(float x, float y);
float valueNoise(float x);

} /* namespace gfx */

#endif /* CAKELAB_GFX_H */
