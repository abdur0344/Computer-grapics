/* ============================================================================
 *  CakeLab  -  screenshot.h
 *  Reads the colour buffer back with glReadPixels and writes it out as an
 *  uncompressed 24 bit BMP, so a finished cake can be handed in with the
 *  report. No image library is involved; the header is written by hand.
 * ==========================================================================*/
#ifndef CAKELAB_SCREENSHOT_H
#define CAKELAB_SCREENSHOT_H

#include <string>

namespace shot {

/*  Grabs the given rectangle of the window and writes it to path.
 *  Returns false if the file could not be opened.                           */
bool saveBMP(const std::string& path, int x, int y, int w, int h);

/*  Picks the next unused name of the form cakelab_001.bmp in the working
 *  directory.                                                               */
std::string nextFilename();

} /* namespace shot */

#endif /* CAKELAB_SCREENSHOT_H */
