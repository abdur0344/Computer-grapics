/* ============================================================================
 *  CakeLab  -  stage_flavor.cpp
 *  Stage 2 of 4  -  Flavour and colour selection.
 *  Group member 2.
 *
 *  This is the colour model stage. Each flavour is a small palette: a sponge
 *  colour, a filling colour, a frosting colour and a drip colour, all stored
 *  as RGB triples. Choosing a flavour swaps the palette and the whole cake is
 *  redrawn from it, which shows directly how one colour table drives every
 *  primitive on screen.
 *
 *  The panel also prints the exact RGB components of the current frosting so
 *  the numeric side of the model is visible, not just the result.
 * ==========================================================================*/
#include "app.h"

namespace app {

using namespace gfx;

static float s_readoutY = 0.0f;

/*  The swatch shows the three main colours of the flavour stacked together. */
static void flavorIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(arg);
    float s = size * 1.05f;
    fillRoundRect(c.x - s, c.y - s, s * 2.0f, s * 0.72f, s * 0.20f, fl.sponge);
    fillRect(c.x - s, c.y - s * 0.30f, s * 2.0f, s * 0.40f, fl.filling);
    fillRoundRect(c.x - s, c.y + s * 0.12f, s * 2.0f, s * 0.86f, s * 0.20f, fl.cream);
    fillCircle(Vec2(c.x + s * 0.46f, c.y + s * 0.52f), s * 0.24f, fl.accent, 14);
    strokeRoundRect(c.x - s, c.y - s, s * 2.0f, s * 2.0f, s * 0.20f,
                    withAlpha(rgb(0, 0, 0), 0.22f), 1.1f);
}

static void flavourBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::FLV_COUNT; ++i) {
        const cake::FlavorDef& fl = cake::flavorDef(i);
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = fl.name;
        b.sub      = fl.note;
        b.icon     = flavorIcon;
        b.iconArg  = i;
        b.tint     = fl.cream;
        b.selected = (g_design.flavor == i);
        g_options.push_back(b);
    }

    float rowH = 41.0f, gap = 5.0f;
    layoutRows(g_options, rowH, gap, panelListTop());
    s_readoutY = panelListTop() - (rowH + gap) * (float)cake::FLV_COUNT - 22.0f;
}

static void flavourOnOption(int id) {
    g_design.flavor = id;
    ui::toast(std::string(cake::flavorDef(id).name) + " selected");
    rebuildStage();
}

static void flavourOnExtra(int id) { (void)id; }

/*  A small bar chart of the red, green and blue components of the frosting. */
static void drawChannelBar(float x, float y, float w, const char* label,
                           float value, const Color& barColor) {
    float h = 9.0f;
    text(x, y - 2.0f, label, ui::T.textFaint, FONT_XS);
    float bx = x + 16.0f;
    float bw = w - 16.0f - 44.0f;
    fillRoundRect(bx, y - 1.0f, bw, h, h * 0.5f, withAlpha(ui::T.panelEdge, 0.65f));
    fillRoundRect(bx, y - 1.0f, bw * clampf(value, 0.0f, 1.0f), h, h * 0.5f, barColor);
    char buf[16];
    std::sprintf(buf, "%3d", (int)(value * 255.0f + 0.5f));
    text(bx + bw + 8.0f, y - 2.0f, buf, ui::T.textDim, FONT_XS);
}

static void flavourDrawPanelExtra() {
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;

    ui::drawSectionLabel(x, s_readoutY, "FROSTING COLOUR, RGB MODEL");
    float y = s_readoutY - 20.0f;

    drawChannelBar(x, y,          w, "R", fl.cream.r, rgb(236,  86,  86));
    drawChannelBar(x, y - 17.0f,  w, "G", fl.cream.g, rgb( 96, 214, 126));
    drawChannelBar(x, y - 34.0f,  w, "B", fl.cream.b, rgb( 96, 156, 236));

    char hex[32];
    std::sprintf(hex, "#%02X%02X%02X",
                 (int)(fl.cream.r * 255.0f + 0.5f),
                 (int)(fl.cream.g * 255.0f + 0.5f),
                 (int)(fl.cream.b * 255.0f + 0.5f));
    fillRoundRect(x, y - 62.0f, 22.0f, 16.0f, 4.0f, fl.cream);
    strokeRoundRect(x, y - 62.0f, 22.0f, 16.0f, 4.0f, withAlpha(rgb(0, 0, 0), 0.3f), 1.0f);
    text(x + 30.0f, y - 59.0f, hex, ui::T.textDim, FONT_S);
}

/*  Under the cake, the full palette that the flavour supplies.              */
static void flavourDrawPreviewOverlay() {
    cake::Frame f = previewFrame();
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);

    struct Sw { const char* name; Color c; };
    Sw swatches[5] = {
        { "sponge",  fl.sponge  },
        { "filling", fl.filling },
        { "frosting",fl.cream   },
        { "drip",    fl.drip    },
        { "accent",  fl.accent  }
    };

    float chipW = 78.0f, chipH = 34.0f, gap = 10.0f;
    float total = chipW * 5.0f + gap * 4.0f;
    float x0 = f.centre.x - total * 0.5f;
    float y0 = L.previewY + 58.0f;

    for (int i = 0; i < 5; ++i) {
        float x = x0 + (chipW + gap) * (float)i;
        fillRoundRect(x, y0, chipW, chipH, 8.0f, swatches[i].c);
        strokeRoundRect(x, y0, chipW, chipH, 8.0f, withAlpha(rgb(0, 0, 0), 0.28f), 1.1f);
        textCentered(x + chipW * 0.5f, y0 + chipH + 8.0f, swatches[i].name,
                     ui::T.textFaint, FONT_XS);
    }
    textRight(previewCaptionRight(), previewCaptionY(0),
              "One palette drives every primitive on the cake",
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool flavourCanAdvance() { return true; }

const StageDef& stageFlavor() {
    static StageDef s = {
        "flavor",
        "Pick a flavour",
        "Stage 2 of 4",
        "Each flavour is a small RGB palette applied to the whole cake.",
        flavourBuild, flavourOnOption, flavourOnExtra, flavourDrawPanelExtra, flavourDrawPreviewOverlay,
        0, 0, flavourCanAdvance
    };
    return s;
}

} /* namespace app */
