/* ============================================================================
 *  CakeLab  -  screenshot.cpp
 * ==========================================================================*/
#include "screenshot.h"
#include <GL/freeglut.h>
#include <cstdio>
#include <cstring>
#include <vector>

namespace shot {

static void put16(unsigned char* p, unsigned short v) {
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
}

static void put32(unsigned char* p, unsigned int v) {
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
    p[2] = (unsigned char)((v >> 16) & 0xFF);
    p[3] = (unsigned char)((v >> 24) & 0xFF);
}

bool saveBMP(const std::string& path, int x, int y, int w, int h) {
    if (w <= 0 || h <= 0) return false;

    std::vector<unsigned char> rgbData((size_t)w * (size_t)h * 3, 0);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadBuffer(GL_FRONT);
    glReadPixels(x, y, w, h, GL_RGB, GL_UNSIGNED_BYTE, &rgbData[0]);

    /*  BMP rows are padded to a multiple of four bytes and are stored bottom
     *  up, which is the order glReadPixels already returns.                  */
    int rowRaw = w * 3;
    int rowPad = (4 - (rowRaw % 4)) % 4;
    int rowSize = rowRaw + rowPad;
    unsigned int imageSize = (unsigned int)rowSize * (unsigned int)h;
    unsigned int fileSize = 54u + imageSize;

    unsigned char header[54];
    std::memset(header, 0, sizeof(header));
    header[0] = 'B'; header[1] = 'M';
    put32(header + 2, fileSize);
    put32(header + 10, 54u);           /* pixel data offset */
    put32(header + 14, 40u);           /* DIB header size   */
    put32(header + 18, (unsigned int)w);
    put32(header + 22, (unsigned int)h);
    put16(header + 26, 1);             /* colour planes     */
    put16(header + 28, 24);            /* bits per pixel    */
    put32(header + 34, imageSize);
    put32(header + 38, 2835u);         /* 72 dpi, pixels per metre */
    put32(header + 42, 2835u);

    std::FILE* fp = std::fopen(path.c_str(), "wb");
    if (!fp) return false;
    std::fwrite(header, 1, sizeof(header), fp);

    std::vector<unsigned char> row((size_t)rowSize, 0);
    for (int r = 0; r < h; ++r) {
        const unsigned char* src = &rgbData[(size_t)r * (size_t)w * 3];
        for (int c = 0; c < w; ++c) {                 /* RGB -> BGR */
            row[(size_t)c * 3 + 0] = src[(size_t)c * 3 + 2];
            row[(size_t)c * 3 + 1] = src[(size_t)c * 3 + 1];
            row[(size_t)c * 3 + 2] = src[(size_t)c * 3 + 0];
        }
        for (int p = 0; p < rowPad; ++p) row[(size_t)rowRaw + (size_t)p] = 0;
        std::fwrite(&row[0], 1, (size_t)rowSize, fp);
    }
    std::fclose(fp);
    return true;
}

std::string nextFilename() {
    char buf[64];
    for (int i = 1; i < 1000; ++i) {
        std::sprintf(buf, "cakelab_%03d.bmp", i);
        std::FILE* fp = std::fopen(buf, "rb");
        if (!fp) return std::string(buf);
        std::fclose(fp);
    }
    return std::string("cakelab_overflow.bmp");
}

} /* namespace shot */
