/* ============================================================================
 *  CakeLab  -  stage_wrap.cpp
 *  Stage 4 of 4  -  Wrapping and packaging.
 *  Group member 4, who also handles the integration of the four stages.
 *
 *  Nothing new is invented here. A rope tie is two shaded bands plus a bow
 *  made of ellipses and Bezier tails; a gift box is four rectangles with the
 *  window left open; a wrapping sheet is a fan of triangles; the ribbon is the
 *  same silhouette extrusion the cake body uses, only much shorter. The stage
 *  exists to show that the routines written for stages one and two are enough
 *  to build something completely different.
 * ==========================================================================*/
#include "app.h"

namespace app {

using namespace gfx;

static const int ID_COLOR_BASE = 400;
static float s_colorLabelY = 0.0f;

static void wrapIcon(Vec2 c, float size, float time, int arg) {
    cake::drawWrapIcon(arg, c, size * 0.92f, cake::wrapPaletteColor(g_design.wrapColor), time);
}

static void wrappingBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::WRAP_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::wrapDef(i).name;
        b.sub      = cake::wrapDef(i).note;
        b.icon     = wrapIcon;
        b.iconArg  = i;
        b.selected = (g_design.wrap == i);
        g_options.push_back(b);
    }

    float rowH = 56.0f, gap = 9.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;
    s_colorLabelY = panelListTop() - (rowH + gap) * (float)cake::WRAP_COUNT - 20.0f;

    int n = cake::wrapPaletteSize();
    for (int i = 0; i < n; ++i) {
        ui::Button b;
        b.id       = ID_COLOR_BASE + i;
        b.style    = ui::BTN_CHIP;
        b.tint     = cake::wrapPaletteColor(i);
        b.selected = (g_design.wrapColor == i);
        b.enabled  = (g_design.wrap != cake::WRAP_NONE);
        g_extras.push_back(b);
    }
    float chipW = (w - 5.0f * 8.0f) / 6.0f;
    layoutChips(g_extras, x, s_colorLabelY - 12.0f, chipW, 34.0f, 8.0f, 6);
}

static void wrappingOnOption(int id) {
    g_design.wrap = id;
    if (id == cake::WRAP_NONE) ui::toast("Serving the cake unwrapped");
    else ui::toast(std::string(cake::wrapDef(id).name) + " in " +
                   cake::wrapPaletteName(g_design.wrapColor));
    rebuildStage();
}

static void wrappingOnExtra(int id) {
    if (id >= ID_COLOR_BASE) {
        g_design.wrapColor = id - ID_COLOR_BASE;
        if (g_design.wrap == cake::WRAP_NONE) g_design.wrap = cake::WRAP_RIBBON;
        ui::toast(std::string(cake::wrapPaletteName(g_design.wrapColor)) + " packaging");
        rebuildStage();
    }
}

static void wrappingDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    ui::drawSectionLabel(x, s_colorLabelY,
                         g_design.wrap == cake::WRAP_NONE ? "PACKAGING COLOUR  (pick a style first)"
                                                          : "PACKAGING COLOUR");
    /* the chosen colour written out, so the swatch is not the only clue */
    if (g_design.wrap != cake::WRAP_NONE) {
        char buf[64];
        std::sprintf(buf, "%s  -  %s", cake::wrapDef(g_design.wrap).name,
                     cake::wrapPaletteName(g_design.wrapColor));
        text(x, s_colorLabelY - 70.0f, buf, ui::T.textDim, FONT_S);
    }
}

static void wrappingDrawPreviewOverlay() {
    const char* msg = (g_design.wrap == cake::WRAP_NONE)
        ? "No packaging: the cake is served straight from the plate"
        : "The packaging reuses the same shape and colour routines as the cake";
    textRight(previewCaptionRight(), previewCaptionY(0), msg,
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool wrappingCanAdvance() { return true; }

const StageDef& stageWrap() {
    static StageDef s = {
        "wrap",
        "Wrap it up",
        "Stage 4 of 4",
        "The packaging is built from the same primitives as the cake itself.",
        wrappingBuild, wrappingOnOption, wrappingOnExtra, wrappingDrawPanelExtra, wrappingDrawPreviewOverlay,
        0, 0, wrappingCanAdvance
    };
    return s;
}

} /* namespace app */
