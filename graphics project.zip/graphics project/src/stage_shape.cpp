/* ============================================================================
 *  CakeLab  -  stage_shape.cpp
 *  Stage 1 of 4  -  Shape selection.
 *  Group member 1.
 *
 *  The user picks the base shape of the cake. Every shape is produced by the
 *  outline generators in gfx.h: the round cake comes from a parametric point
 *  loop, the polygon from the regular polygon generator, and the straight
 *  sided shapes from their corner lists. Nothing calls a built-in circle.
 *
 *  Two extra controls belong to this stage because they change the geometry
 *  rather than the decoration: the number of sides when the polygon shape is
 *  chosen, and the number of stacked tiers.
 * ==========================================================================*/
#include "app.h"

namespace app {

using namespace gfx;

/* option ids are the shape enum itself; the chips use offset ranges */
static const int ID_SIDES_BASE  = 100;
static const int ID_LAYERS_BASE = 200;

static float s_sidesLabelY  = 0.0f;
static float s_layersLabelY = 0.0f;

/* --------------------------------------------------------------- icons */
static void shapeIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    cake::drawShapeIcon(arg, g_design.polySides, c, size * 0.92f, fl.cream);
}

static void tierIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    int n = arg;
    for (int i = 0; i < n; ++i) {
        float k = std::pow(0.72f, (float)i);
        float w = size * 1.30f * k;
        float h = size * 0.34f;
        fillRoundRect(c.x - w * 0.5f, c.y - size * 0.62f + (float)i * h * 1.06f,
                      w, h * 0.92f, h * 0.22f, fl.sponge);
    }
}

/* --------------------------------------------------------------- build */
static void shapeBuild() {
    g_options.clear();
    g_extras.clear();

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;

    for (int i = 0; i < cake::SHAPE_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::shapeDef(i).name;
        b.sub      = cake::shapeDef(i).note;
        b.icon     = shapeIcon;
        b.iconArg  = i;
        b.selected = (g_design.shape == i);
        g_options.push_back(b);
    }

    float rowH = 56.0f, gap = 9.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float y = panelListTop() - (rowH + gap) * (float)cake::SHAPE_COUNT;

    /* sides of the polygon, only meaningful for the polygon shape */
    s_sidesLabelY = y - 22.0f;
    y = s_sidesLabelY - 12.0f;
    for (int s = 5; s <= 8; ++s) {
        ui::Button b;
        b.id      = ID_SIDES_BASE + s;
        b.style   = ui::BTN_CHIP;
        char buf[8];
        std::sprintf(buf, "%d", s);
        b.label   = buf;
        b.enabled = (g_design.shape == cake::SHAPE_POLYGON);
        b.selected= (g_design.polySides == s) && b.enabled;
        g_extras.push_back(b);
    }
    layoutChips(g_extras, x, y, (w - 3.0f * 10.0f) / 4.0f, 32.0f, 10.0f, 4);

    /* stacked tiers */
    size_t firstTier = g_extras.size();
    s_layersLabelY = (y - 32.0f) - 24.0f;
    float ty = s_layersLabelY - 12.0f;
    const char* tierNames[3] = { "1 tier", "2 tiers", "3 tiers" };
    for (int i = 0; i < 3; ++i) {
        ui::Button b;
        b.id       = ID_LAYERS_BASE + (i + 1);
        b.style    = ui::BTN_CHIP;
        b.label    = tierNames[i];
        b.icon     = tierIcon;
        b.iconArg  = i + 1;
        b.selected = (g_design.layers == i + 1);
        g_extras.push_back(b);
    }
    std::vector<ui::Button> tail(g_extras.begin() + (long)firstTier, g_extras.end());
    layoutChips(tail, x, ty, (w - 2.0f * 10.0f) / 3.0f, 40.0f, 10.0f, 3);
    for (size_t i = 0; i < tail.size(); ++i) g_extras[firstTier + i] = tail[i];
}

/* -------------------------------------------------------------- events */
static void shapeOnOption(int id) {
    g_design.shape = id;
    if (id == cake::SHAPE_POLYGON)
        ui::toast(std::string("Polygon with ") + (char)('0' + g_design.polySides) + " sides");
    else
        ui::toast(std::string(cake::shapeDef(id).name) + " base selected");

    /* toppings are positioned in shape space, so clear any that now fall
       outside the new outline                                              */
    size_t before = g_design.toppings.size();
    std::vector<cake::Placed> keep;
    for (size_t i = 0; i < g_design.toppings.size(); ++i) {
        Vec2 uv(g_design.toppings[i].u, g_design.toppings[i].v);
        if (cake::insideUnitShape(g_design, uv)) keep.push_back(g_design.toppings[i]);
    }
    g_design.toppings = keep;
    if (keep.size() != before)
        ui::toast("Trimmed toppings that fell outside the new shape");

    rebuildStage();
}

static void shapeOnExtra(int id) {
    if (id > ID_LAYERS_BASE) {
        g_design.layers = id - ID_LAYERS_BASE;
        char buf[48];
        std::sprintf(buf, "%d tier cake", g_design.layers);
        ui::toast(buf);
    } else if (id > ID_SIDES_BASE) {
        g_design.polySides = id - ID_SIDES_BASE;
        g_design.shape = cake::SHAPE_POLYGON;
        char buf[48];
        std::sprintf(buf, "Regular polygon, %d sides", g_design.polySides);
        ui::toast(buf);
    }
    rebuildStage();
}

static void shapeDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    bool  poly = (g_design.shape == cake::SHAPE_POLYGON);
    ui::drawSectionLabel(x, s_sidesLabelY,
                         poly ? "NUMBER OF SIDES" : "NUMBER OF SIDES  (polygon only)");
    ui::drawSectionLabel(x, s_layersLabelY, "STACKED TIERS");
}

/*  The preview gains a small annotation showing how the outline was made.   */
static void shapeDrawPreviewOverlay() {
    cake::Frame f = previewFrame();
    std::vector<Vec2> unit;
    cake::shapeOutlineUnit(unit, g_design, 72);

    int corners = 0;
    switch (g_design.shape) {
        case cake::SHAPE_CIRCLE:   corners = 0; break;
        case cake::SHAPE_TRIANGLE: corners = 3; break;
        case cake::SHAPE_SQUARE:   corners = 4; break;
        case cake::SHAPE_RECT:     corners = 4; break;
        case cake::SHAPE_POLYGON:  corners = g_design.polySides; break;
        default: break;
    }

    /* mark the generated vertices so the point loop is visible */
    float sTop = cake::layerScale(g_design, g_design.layers - 1);
    Vec2  c    = cake::topCentre(g_design, f);
    for (size_t i = 0; i < unit.size(); i += (corners > 0 ? 4 : 6)) {
        Vec2 p(f.centre.x + unit[i].x * f.radius * sTop,
               f.centre.y + unit[i].y * f.radius * f.squash * sTop +
               cake::topElevation(g_design, f));
        fillCircle(p, 2.0f, withAlpha(rgb(255, 255, 255), 0.30f), 8);
    }

    char buf[128];
    if (corners == 0)
        std::sprintf(buf, "Round base: 72 points from x = r cos t, y = r sin t");
    else
        std::sprintf(buf, "%d corner base, edges subdivided into %d points",
                     corners, (int)unit.size());
    (void)c;
    textRight(previewCaptionRight(), previewCaptionY(0), buf,
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool shapeCanAdvance() { return true; }

/* --------------------------------------------------------------- table */
const StageDef& stageShape() {
    static StageDef s = {
        "shape",
        "Choose the base shape",
        "Stage 1 of 4",
        "Every outline is generated point by point, not by a built-in shape call.",
        shapeBuild, shapeOnOption, shapeOnExtra, shapeDrawPanelExtra, shapeDrawPreviewOverlay,
        0, 0, shapeCanAdvance
    };
    return s;
}

} /* namespace app */
