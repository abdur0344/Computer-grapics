/* ============================================================================
 *  CakeLab  -  gfx.cpp
 *  Implementation of the 2D drawing toolkit. See gfx.h for the overview.
 * ==========================================================================*/
#include "gfx.h"
#include <algorithm>
#include <cstdlib>

namespace gfx {

/* ==========================================================================
 *  Vectors and scalar maths
 * ========================================================================*/
Vec2 normalize(const Vec2& a) {
    float len = length(a);
    if (len < 1e-6f) return Vec2(0.0f, 0.0f);
    return Vec2(a.x / len, a.y / len);
}

Vec2 perp(const Vec2& a) { return Vec2(-a.y, a.x); }

Vec2 rotated(const Vec2& a, float deg) {
    float r = deg2rad(deg);
    float c = std::cos(r), s = std::sin(r);
    return Vec2(a.x * c - a.y * s, a.x * s + a.y * c);
}

float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
float lerpf(float a, float b, float t)    { return a + (b - a) * t; }
float deg2rad(float d)                    { return d * PI / 180.0f; }
float rad2deg(float r)                    { return r * 180.0f / PI; }

float smoothstep(float edge0, float edge1, float x) {
    if (edge1 - edge0 == 0.0f) return x < edge0 ? 0.0f : 1.0f;
    float t = clampf((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

/*  A hash instead of rand(): the same input always gives the same output, so
 *  scattered detail such as sprinkles stays put between frames.              */
float hash11(float x) {
    float s = std::sin(x * 127.1f) * 43758.5453f;
    return s - std::floor(s);
}

float hash21(float x, float y) {
    float s = std::sin(x * 127.1f + y * 311.7f) * 43758.5453f;
    return s - std::floor(s);
}

float valueNoise(float x) {
    float i = std::floor(x);
    float f = x - i;
    float u = f * f * (3.0f - 2.0f * f);
    return lerpf(hash11(i), hash11(i + 1.0f), u);
}

bool pointInPoly(const std::vector<Vec2>& poly, Vec2 p) {
    /* Even-odd rule: count how many edges a ray to the right crosses. */
    bool inside = false;
    size_t n = poly.size();
    if (n < 3) return false;
    for (size_t i = 0, j = n - 1; i < n; j = i++) {
        bool straddles = (poly[i].y > p.y) != (poly[j].y > p.y);
        if (straddles) {
            float t = (p.y - poly[i].y) / (poly[j].y - poly[i].y);
            float xCross = poly[i].x + t * (poly[j].x - poly[i].x);
            if (p.x < xCross) inside = !inside;
        }
    }
    return inside;
}

/* ==========================================================================
 *  Colour model
 * ========================================================================*/
Color rgb(int r, int g, int b) {
    return Color(r / 255.0f, g / 255.0f, b / 255.0f, 1.0f);
}

Color rgba(int r, int g, int b, float a) {
    return Color(r / 255.0f, g / 255.0f, b / 255.0f, a);
}

Color mix(const Color& a, const Color& b, float t) {
    t = clampf(t, 0.0f, 1.0f);
    return Color(lerpf(a.r, b.r, t), lerpf(a.g, b.g, t),
                 lerpf(a.b, b.b, t), lerpf(a.a, b.a, t));
}

Color shade(const Color& c, float factor) {
    return Color(clampf(c.r * factor, 0.0f, 1.0f),
                 clampf(c.g * factor, 0.0f, 1.0f),
                 clampf(c.b * factor, 0.0f, 1.0f), c.a);
}

Color withAlpha(const Color& c, float a) { return Color(c.r, c.g, c.b, a); }

/*  HSV to RGB. Hue is in degrees, saturation and value in 0..1.             */
Color hsv(float h, float s, float v, float a) {
    h = std::fmod(h, 360.0f);
    if (h < 0.0f) h += 360.0f;
    float c = v * s;
    float x = c * (1.0f - std::fabs(std::fmod(h / 60.0f, 2.0f) - 1.0f));
    float m = v - c;
    float r = 0.0f, g = 0.0f, b = 0.0f;
    if      (h <  60.0f) { r = c; g = x; }
    else if (h < 120.0f) { r = x; g = c; }
    else if (h < 180.0f) { g = c; b = x; }
    else if (h < 240.0f) { g = x; b = c; }
    else if (h < 300.0f) { r = x; b = c; }
    else                 { r = c; b = x; }
    return Color(r + m, g + m, b + m, a);
}

void useColor(const Color& c) { glColor4f(c.r, c.g, c.b, c.a); }

/* ==========================================================================
 *  Scan conversion
 *
 *  These follow the incremental algorithms from the course notes. Each one
 *  produces integer pixel positions and emits them as GL_POINTS.
 * ========================================================================*/

/*  Digital Differential Analyser.
 *  Step along the dominant axis in unit increments and advance the other axis
 *  by its constant slope increment, rounding to the nearest pixel.           */
void lineDDA(Vec2 a, Vec2 b, const Color& c, float pointSize) {
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    int steps = (int)(std::max(std::fabs(dx), std::fabs(dy)) + 0.5f);
    if (steps <= 0) steps = 1;

    float xInc = dx / (float)steps;
    float yInc = dy / (float)steps;
    float x = a.x, y = a.y;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; ++i) {
        glVertex2f(std::floor(x + 0.5f), std::floor(y + 0.5f));
        x += xInc;
        y += yInc;
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Bresenham midpoint line, integer arithmetic only, valid in all octants.
 *  The decision variable err tracks which side of the ideal line the midpoint
 *  between the two candidate pixels falls on.                                */
void lineBresenham(Vec2 a, Vec2 b, const Color& c, float pointSize) {
    int x0 = (int)std::floor(a.x + 0.5f), y0 = (int)std::floor(a.y + 0.5f);
    int x1 = (int)std::floor(b.x + 0.5f), y1 = (int)std::floor(b.y + 0.5f);

    int dx =  std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (;;) {
        glVertex2i(x0, y0);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Midpoint circle algorithm. One octant is generated and the remaining seven
 *  are obtained by symmetry, which is why only x and y are stepped.          */
void circleMidpoint(Vec2 centre, float r, const Color& c, float pointSize) {
    int cx = (int)std::floor(centre.x + 0.5f);
    int cy = (int)std::floor(centre.y + 0.5f);
    int radius = (int)std::floor(r + 0.5f);
    if (radius <= 0) return;

    int x = 0, y = radius;
    int d = 1 - radius;             /* decision variable */

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    while (x <= y) {
        glVertex2i(cx + x, cy + y);  glVertex2i(cx - x, cy + y);
        glVertex2i(cx + x, cy - y);  glVertex2i(cx - x, cy - y);
        glVertex2i(cx + y, cy + x);  glVertex2i(cx - y, cy + x);
        glVertex2i(cx + y, cy - x);  glVertex2i(cx - y, cy - x);
        if (d < 0) {
            d += 2 * x + 3;
        } else {
            d += 2 * (x - y) + 5;
            --y;
        }
        ++x;
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Midpoint ellipse algorithm, in two regions split where the tangent slope
 *  passes through -1. Four-way symmetry.                                     */
void ellipseMidpoint(Vec2 centre, float rx, float ry, const Color& c, float pointSize) {
    long a = (long)std::floor(rx + 0.5f);
    long b = (long)std::floor(ry + 0.5f);
    if (a <= 0 || b <= 0) return;
    int cx = (int)std::floor(centre.x + 0.5f);
    int cy = (int)std::floor(centre.y + 0.5f);

    long aa = a * a, bb = b * b;
    long x = 0, y = b;
    long d1 = bb - aa * b + aa / 4;
    long dx = 2 * bb * x, dy = 2 * aa * y;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);

    while (dx < dy) {                            /* region 1 */
        glVertex2i(cx + (int)x, cy + (int)y); glVertex2i(cx - (int)x, cy + (int)y);
        glVertex2i(cx + (int)x, cy - (int)y); glVertex2i(cx - (int)x, cy - (int)y);
        if (d1 < 0) {
            ++x; dx += 2 * bb; d1 += dx + bb;
        } else {
            ++x; --y; dx += 2 * bb; dy -= 2 * aa; d1 += dx - dy + bb;
        }
    }

    long d2 = bb * (x * x + x) + aa * (y - 1) * (y - 1) - aa * bb;
    /* the term above is the region-2 decision variable evaluated at the
       midpoint of the first candidate pair                                   */
    while (y >= 0) {                             /* region 2 */
        glVertex2i(cx + (int)x, cy + (int)y); glVertex2i(cx - (int)x, cy + (int)y);
        glVertex2i(cx + (int)x, cy - (int)y); glVertex2i(cx - (int)x, cy - (int)y);
        if (d2 > 0) {
            --y; dy -= 2 * aa; d2 += aa - dy;
        } else {
            ++x; --y; dy -= 2 * aa; dx += 2 * bb; d2 += dx - dy + aa;
        }
    }
    glEnd();
    glPointSize(1.0f);
}

/*  The parametric point loop: x = cx + r cos t, y = cy + r sin t.
 *  This is the form used for every filled round shape in CakeLab.            */
void circleParametric(Vec2 centre, float r, const Color& c, int steps, float pointSize) {
    if (steps < 3) steps = 3;
    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (int i = 0; i < steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + r * std::cos(t), centre.y + r * std::sin(t));
    }
    glEnd();
    glPointSize(1.0f);
}

void polylineBresenham(const std::vector<Vec2>& pts, const Color& c, bool closed, float pointSize) {
    if (pts.size() < 2) return;
    for (size_t i = 0; i + 1 < pts.size(); ++i)
        lineBresenham(pts[i], pts[i + 1], c, pointSize);
    if (closed) lineBresenham(pts.back(), pts.front(), c, pointSize);
}

/* ==========================================================================
 *  Outline generators (all parametric point loops)
 * ========================================================================*/
void makeCircle(std::vector<Vec2>& out, Vec2 centre, float r, int steps) {
    makeEllipse(out, centre, r, r, steps);
}

void makeEllipse(std::vector<Vec2>& out, Vec2 centre, float rx, float ry, int steps) {
    if (steps < 3) steps = 3;
    out.clear();
    out.reserve((size_t)steps);
    for (int i = 0; i < steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        out.push_back(Vec2(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t)));
    }
}

void makeRegularPolygon(std::vector<Vec2>& out, Vec2 centre, float r, int sides, float rotDeg) {
    if (sides < 3) sides = 3;
    out.clear();
    out.reserve((size_t)sides);
    float phase = deg2rad(rotDeg);
    for (int i = 0; i < sides; ++i) {
        float t = phase + 2.0f * PI * (float)i / (float)sides;
        out.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
}

void makeRoundRect(std::vector<Vec2>& out, float x, float y, float w, float h, float r, int cornerSteps) {
    out.clear();
    r = clampf(r, 0.0f, std::min(w, h) * 0.5f);
    if (cornerSteps < 1) cornerSteps = 1;

    struct Corner { float cx, cy, a0; };
    Corner corners[4] = {
        { x + w - r, y + r,     270.0f },   /* bottom right */
        { x + w - r, y + h - r,   0.0f },   /* top right    */
        { x + r,     y + h - r,  90.0f },   /* top left     */
        { x + r,     y + r,     180.0f }    /* bottom left  */
    };
    for (int k = 0; k < 4; ++k) {
        for (int i = 0; i <= cornerSteps; ++i) {
            float a = deg2rad(corners[k].a0 + 90.0f * (float)i / (float)cornerSteps);
            out.push_back(Vec2(corners[k].cx + r * std::cos(a),
                               corners[k].cy + r * std::sin(a)));
        }
    }
}

void makeStar(std::vector<Vec2>& out, Vec2 centre, float rOuter, float rInner, int points, float rotDeg) {
    if (points < 2) points = 2;
    out.clear();
    out.reserve((size_t)points * 2);
    float phase = deg2rad(rotDeg);
    for (int i = 0; i < points * 2; ++i) {
        float t = phase + PI * (float)i / (float)points;
        float r = (i % 2 == 0) ? rOuter : rInner;
        out.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
}

void makeBezier(std::vector<Vec2>& out, Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, int steps) {
    if (steps < 1) steps = 1;
    out.clear();
    out.reserve((size_t)steps + 1);
    for (int i = 0; i <= steps; ++i) {
        float t  = (float)i / (float)steps;
        float u  = 1.0f - t;
        float b0 = u * u * u;
        float b1 = 3.0f * u * u * t;
        float b2 = 3.0f * u * t * t;
        float b3 = t * t * t;
        out.push_back(Vec2(b0 * p0.x + b1 * p1.x + b2 * p2.x + b3 * p3.x,
                           b0 * p0.y + b1 * p1.y + b2 * p2.y + b3 * p3.y));
    }
}

/* ==========================================================================
 *  Filled and stroked drawing
 * ========================================================================*/
static Vec2 centroidOf(const std::vector<Vec2>& pts) {
    Vec2 c(0.0f, 0.0f);
    if (pts.empty()) return c;
    for (size_t i = 0; i < pts.size(); ++i) { c.x += pts[i].x; c.y += pts[i].y; }
    c.x /= (float)pts.size();
    c.y /= (float)pts.size();
    return c;
}

void line(Vec2 a, Vec2 b, const Color& c, float width) {
    if (width <= 1.25f) {
        useColor(c);
        glBegin(GL_LINES);
        glVertex2f(a.x, a.y);
        glVertex2f(b.x, b.y);
        glEnd();
        return;
    }
    Vec2 d = b - a;
    float len = length(d);
    if (len < 1e-4f) { fillCircle(a, width * 0.5f, c, 10); return; }
    Vec2 n = perp(Vec2(d.x / len, d.y / len)) * (width * 0.5f);
    useColor(c);
    glBegin(GL_QUADS);
    glVertex2f(a.x + n.x, a.y + n.y);
    glVertex2f(b.x + n.x, b.y + n.y);
    glVertex2f(b.x - n.x, b.y - n.y);
    glVertex2f(a.x - n.x, a.y - n.y);
    glEnd();
}

void polyline(const std::vector<Vec2>& pts, const Color& c, float width, bool closed) {
    if (pts.size() < 2) return;
    for (size_t i = 0; i + 1 < pts.size(); ++i) line(pts[i], pts[i + 1], c, width);
    if (closed) line(pts.back(), pts.front(), c, width);
    if (width > 2.5f) {                       /* round off the joints */
        for (size_t i = closed ? 0 : 1; i + (closed ? 0 : 1) < pts.size(); ++i)
            fillCircle(pts[i], width * 0.5f, c, 10);
    }
}

void fillPoly(const std::vector<Vec2>& pts, const Color& c) {
    if (pts.size() < 3) return;
    Vec2 mid = centroidOf(pts);
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(mid.x, mid.y);
    for (size_t i = 0; i < pts.size(); ++i) glVertex2f(pts[i].x, pts[i].y);
    glVertex2f(pts[0].x, pts[0].y);
    glEnd();
}

void fillPolyGrad(const std::vector<Vec2>& pts, Vec2 centre, const Color& inner, const Color& outer) {
    if (pts.size() < 3) return;
    glBegin(GL_TRIANGLE_FAN);
    useColor(inner);
    glVertex2f(centre.x, centre.y);
    useColor(outer);
    for (size_t i = 0; i < pts.size(); ++i) glVertex2f(pts[i].x, pts[i].y);
    glVertex2f(pts[0].x, pts[0].y);
    glEnd();
}

void fillPolyGradV(const std::vector<Vec2>& pts, const Color& bottom, const Color& top) {
    if (pts.size() < 3) return;
    float lo = pts[0].y, hi = pts[0].y;
    for (size_t i = 1; i < pts.size(); ++i) {
        lo = std::min(lo, pts[i].y);
        hi = std::max(hi, pts[i].y);
    }
    float span = (hi - lo) > 1e-4f ? (hi - lo) : 1.0f;
    Vec2 mid = centroidOf(pts);

    glBegin(GL_TRIANGLE_FAN);
    useColor(mix(bottom, top, (mid.y - lo) / span));
    glVertex2f(mid.x, mid.y);
    for (size_t i = 0; i <= pts.size(); ++i) {
        const Vec2& p = pts[i % pts.size()];
        useColor(mix(bottom, top, (p.y - lo) / span));
        glVertex2f(p.x, p.y);
    }
    glEnd();
}

void strokePoly(const std::vector<Vec2>& pts, const Color& c, float width) {
    polyline(pts, c, width, true);
}

void fillCircle(Vec2 centre, float r, const Color& c, int steps) {
    fillEllipse(centre, r, r, c, steps);
}

void fillEllipse(Vec2 centre, float rx, float ry, const Color& c, int steps) {
    if (steps < 3) steps = 3;
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centre.x, centre.y);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t));
    }
    glEnd();
}

void fillCircleGrad(Vec2 centre, float r, const Color& inner, const Color& outer, int steps) {
    fillEllipseGrad(centre, r, r, inner, outer, steps);
}

void fillEllipseGrad(Vec2 centre, float rx, float ry, const Color& inner, const Color& outer, int steps) {
    if (steps < 3) steps = 3;
    glBegin(GL_TRIANGLE_FAN);
    useColor(inner);
    glVertex2f(centre.x, centre.y);
    useColor(outer);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t));
    }
    glEnd();
}

void strokeCircle(Vec2 centre, float r, const Color& c, float width, int steps) {
    std::vector<Vec2> pts;
    makeCircle(pts, centre, r, steps);
    polyline(pts, c, width, true);
}

void ring(Vec2 centre, float rInner, float rOuter, const Color& c, int steps) {
    if (steps < 3) steps = 3;
    useColor(c);
    glBegin(GL_TRIANGLE_STRIP);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        float cs = std::cos(t), sn = std::sin(t);
        glVertex2f(centre.x + rInner * cs, centre.y + rInner * sn);
        glVertex2f(centre.x + rOuter * cs, centre.y + rOuter * sn);
    }
    glEnd();
}

void fillArc(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, int steps) {
    if (steps < 2) steps = 2;
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centre.x, centre.y);
    for (int i = 0; i <= steps; ++i) {
        float t = deg2rad(lerpf(startDeg, endDeg, (float)i / (float)steps));
        glVertex2f(centre.x + r * std::cos(t), centre.y + r * std::sin(t));
    }
    glEnd();
}

void arcStroke(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, float width, int steps) {
    if (steps < 2) steps = 2;
    std::vector<Vec2> pts;
    pts.reserve((size_t)steps + 1);
    for (int i = 0; i <= steps; ++i) {
        float t = deg2rad(lerpf(startDeg, endDeg, (float)i / (float)steps));
        pts.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
    polyline(pts, c, width, false);
}

void fillRect(float x, float y, float w, float h, const Color& c) {
    useColor(c);
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
}

void fillRectGradV(float x, float y, float w, float h, const Color& bottom, const Color& top) {
    glBegin(GL_QUADS);
    useColor(bottom); glVertex2f(x, y);     glVertex2f(x + w, y);
    useColor(top);    glVertex2f(x + w, y + h); glVertex2f(x, y + h);
    glEnd();
}

void fillRectGradH(float x, float y, float w, float h, const Color& left, const Color& right) {
    glBegin(GL_QUADS);
    useColor(left);  glVertex2f(x, y);         glVertex2f(x, y + h);
    useColor(right); glVertex2f(x + w, y + h); glVertex2f(x + w, y);
    glEnd();
}

void strokeRect(float x, float y, float w, float h, const Color& c, float width) {
    std::vector<Vec2> pts;
    pts.push_back(Vec2(x, y));
    pts.push_back(Vec2(x + w, y));
    pts.push_back(Vec2(x + w, y + h));
    pts.push_back(Vec2(x, y + h));
    polyline(pts, c, width, true);
}

void fillRoundRect(float x, float y, float w, float h, float r, const Color& c) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    fillPoly(pts, c);
}

void fillRoundRectGradV(float x, float y, float w, float h, float r, const Color& bottom, const Color& top) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    fillPolyGradV(pts, bottom, top);
}

void strokeRoundRect(float x, float y, float w, float h, float r, const Color& c, float width) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    polyline(pts, c, width, true);
}

void fillTri(Vec2 a, Vec2 b, Vec2 c, const Color& col) {
    useColor(col);
    glBegin(GL_TRIANGLES);
    glVertex2f(a.x, a.y);
    glVertex2f(b.x, b.y);
    glVertex2f(c.x, c.y);
    glEnd();
}

void fillRegularPolygon(Vec2 centre, float r, int sides, float rotDeg, const Color& c) {
    std::vector<Vec2> pts;
    makeRegularPolygon(pts, centre, r, sides, rotDeg);
    fillPoly(pts, c);
}

void fillStar(Vec2 centre, float rOuter, float rInner, int points, float rotDeg, const Color& c) {
    std::vector<Vec2> pts;
    makeStar(pts, centre, rOuter, rInner, points, rotDeg);
    fillPoly(pts, c);
}

void fillCapsule(Vec2 a, Vec2 b, float r, const Color& c) {
    line(a, b, c, r * 2.0f);
    fillCircle(a, r, c, 16);
    fillCircle(b, r, c, 16);
}

void softShadow(Vec2 centre, float rx, float ry, float alpha, int steps) {
    /* Three stacked translucent ellipses approximate a soft falloff. */
    for (int i = 3; i >= 1; --i) {
        float k = (float)i / 3.0f;
        fillEllipse(centre, rx * (0.6f + 0.4f * k), ry * (0.6f + 0.4f * k),
                    Color(0.0f, 0.0f, 0.0f, alpha * 0.34f), steps);
    }
}

/* ==========================================================================
 *  Text
 * ========================================================================*/
static void* bitmapFont(FontId f) {
    switch (f) {
        case FONT_XS: return GLUT_BITMAP_HELVETICA_10;
        case FONT_S:  return GLUT_BITMAP_HELVETICA_12;
        case FONT_M:  return GLUT_BITMAP_HELVETICA_18;
        case FONT_L:  return GLUT_BITMAP_TIMES_ROMAN_24;
    }
    return GLUT_BITMAP_HELVETICA_18;
}

float textWidth(const std::string& s, FontId f) {
    return (float)glutBitmapLength((void*)bitmapFont(f), (const unsigned char*)s.c_str());
}

float textHeight(FontId f) {
    switch (f) {
        case FONT_XS: return 10.0f;
        case FONT_S:  return 12.0f;
        case FONT_M:  return 18.0f;
        case FONT_L:  return 24.0f;
    }
    return 18.0f;
}

void text(float x, float y, const std::string& s, const Color& c, FontId f) {
    useColor(c);
    glRasterPos2f(std::floor(x), std::floor(y));
    void* font = bitmapFont(f);
    for (size_t i = 0; i < s.size(); ++i)
        glutBitmapCharacter(font, (int)(unsigned char)s[i]);
}

void textCentered(float cx, float y, const std::string& s, const Color& c, FontId f) {
    text(cx - textWidth(s, f) * 0.5f, y, s, c, f);
}

void textRight(float rx, float y, const std::string& s, const Color& c, FontId f) {
    text(rx - textWidth(s, f), y, s, c, f);
}

/*  GLUT stroke fonts are drawn in a 119.05 unit em box.                      */
static const float kStrokeEm = 119.05f;

float strokeTextWidth(const std::string& s, float size) {
    float w = (float)glutStrokeLength(GLUT_STROKE_ROMAN, (const unsigned char*)s.c_str());
    return w * (size / kStrokeEm);
}

void strokeText(float x, float y, const std::string& s, const Color& c, float size, float weight) {
    float scale = size / kStrokeEm;
    useColor(c);
    glLineWidth(weight);
    glPushMatrix();
    glTranslatef(x, y, 0.0f);
    glScalef(scale, scale, 1.0f);
    for (size_t i = 0; i < s.size(); ++i)
        glutStrokeCharacter(GLUT_STROKE_ROMAN, (int)(unsigned char)s[i]);
    glPopMatrix();
    glLineWidth(1.0f);
}

void strokeTextCentered(float cx, float y, const std::string& s, const Color& c, float size, float weight) {
    strokeText(cx - strokeTextWidth(s, size) * 0.5f, y, s, c, size, weight);
}

/* ==========================================================================
 *  Transforms, clipping and set-up
 * ========================================================================*/
void pushTransform(Vec2 translate, float rotDeg, float scaleX, float scaleY) {
    glPushMatrix();
    glTranslatef(translate.x, translate.y, 0.0f);   /* translation */
    if (rotDeg != 0.0f) glRotatef(rotDeg, 0.0f, 0.0f, 1.0f);  /* rotation */
    if (scaleX != 1.0f || scaleY != 1.0f) glScalef(scaleX, scaleY, 1.0f); /* scaling */
}

void popTransform() { glPopMatrix(); }

void pushScissor(float x, float y, float w, float h) {
    glEnable(GL_SCISSOR_TEST);
    glScissor((GLint)x, (GLint)y, (GLsizei)std::max(0.0f, w), (GLsizei)std::max(0.0f, h));
}

void popScissor() { glDisable(GL_SCISSOR_TEST); }

void begin2D(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, (GLdouble)w, 0.0, (GLdouble)h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void enableBlend() {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
}

} /* namespace gfx */
