/* ============================================================================
 *  CakeLab  -  cake.cpp
 *  The design data, the geometry that positions it on screen, and the renderer
 *  that draws the cake itself. Toppings live in toppings.cpp and packaging in
 *  wrapping.cpp; everything else about the cake is here.
 * ==========================================================================*/
#include "cake.h"
#include <algorithm>
#include <cstdio>

namespace cake {

using namespace gfx;

/* ==========================================================================
 *  Catalogues
 * ========================================================================*/
static const ShapeDef kShapes[SHAPE_COUNT] = {
    { "Round",     "classic circle, drawn point by point" },
    { "Square",    "four equal sides, sharp corners"      },
    { "Triangle",  "three sides, a slice of a cake"       },
    { "Rectangle", "wide sheet cake"                      },
    { "Polygon",   "regular n-gon, five to eight sides"   }
};

struct FlavorNote { const char* name; const char* note; };
static const FlavorNote kFlavorNames[FLV_COUNT] = {
    { "Strawberry",   "pink sponge, berry cream"      },
    { "Green Tea",    "matcha sponge, pistachio cream"},
    { "Black Forest", "cocoa sponge, white cream"     },
    { "Red Velvet",   "crimson crumb, cheese icing"   },
    { "Mango",        "golden sponge, mango cream"    },
    { "Chocolate",    "dark sponge, fudge frosting"   },
    { "Vanilla",      "butter sponge, plain cream"    },
    { "Butterscotch", "caramel sponge and glaze"      }
};

/*  The colour tables are filled once at start-up so that rgb() can be used
 *  (the 0..255 form is far easier to read than 0..1 literals).              */
static FlavorDef g_flavors[FLV_COUNT];
static bool      g_flavorsReady = false;

static void buildFlavors() {
    if (g_flavorsReady) return;
    for (int i = 0; i < FLV_COUNT; ++i) {
        g_flavors[i].name = kFlavorNames[i].name;
        g_flavors[i].note = kFlavorNames[i].note;
    }
    FlavorDef* f;

    f = &g_flavors[FLV_STRAWBERRY];
    f->sponge = rgb(248,214,222); f->spongeDark = rgb(224,170,186); f->filling = rgb(234, 92,126);
    f->cream  = rgb(255,190,207); f->creamDeep  = rgb(230,140,168); f->drip    = rgb(255,164,190);
    f->accent = rgb(214, 52, 96);

    f = &g_flavors[FLV_GREEN];
    f->sponge = rgb(216,232,190); f->spongeDark = rgb(176,202,146); f->filling = rgb(126,178, 96);
    f->cream  = rgb(198,228,168); f->creamDeep  = rgb(148,190,118); f->drip    = rgb(176,214,140);
    f->accent = rgb( 86,148, 68);

    f = &g_flavors[FLV_BLACKFOREST];
    f->sponge = rgb( 88, 54, 47); f->spongeDark = rgb( 54, 32, 28); f->filling = rgb(250,246,240);
    f->cream  = rgb(250,247,242); f->creamDeep  = rgb(212,202,194); f->drip    = rgb( 66, 39, 33);
    f->accent = rgb(178, 26, 42);

    f = &g_flavors[FLV_REDVELVET];
    f->sponge = rgb(170, 42, 54); f->spongeDark = rgb(118, 26, 36); f->filling = rgb(252,248,242);
    f->cream  = rgb(252,249,244); f->creamDeep  = rgb(218,206,196); f->drip    = rgb(206, 72, 86);
    f->accent = rgb(140, 28, 42);

    f = &g_flavors[FLV_MANGO];
    f->sponge = rgb(255,226,160); f->spongeDark = rgb(230,190,108); f->filling = rgb(255,182, 66);
    f->cream  = rgb(255,208,110); f->creamDeep  = rgb(230,168, 68); f->drip    = rgb(255,190, 80);
    f->accent = rgb(226,132, 26);

    f = &g_flavors[FLV_CHOCOLATE];
    f->sponge = rgb( 98, 61, 45); f->spongeDark = rgb( 60, 36, 25); f->filling = rgb(146, 94, 62);
    f->cream  = rgb( 86, 51, 37); f->creamDeep  = rgb( 54, 31, 21); f->drip    = rgb( 70, 40, 28);
    f->accent = rgb(208,152, 98);

    f = &g_flavors[FLV_VANILLA];
    f->sponge = rgb(250,235,206); f->spongeDark = rgb(226,206,170); f->filling = rgb(255,248,228);
    f->cream  = rgb(255,247,232); f->creamDeep  = rgb(226,212,186); f->drip    = rgb(246,232,200);
    f->accent = rgb(214,180,120);

    f = &g_flavors[FLV_BUTTERSCOTCH];
    f->sponge = rgb(238,196,132); f->spongeDark = rgb(204,158, 94); f->filling = rgb(198,124, 52);
    f->cream  = rgb(228,168, 92); f->creamDeep  = rgb(188,128, 60); f->drip    = rgb(214,146, 70);
    f->accent = rgb(150, 88, 32);

    g_flavorsReady = true;
}

static const ToppingDef kToppings[TOP_COUNT] = {
    { "Berries",   "blueberry cluster"       },
    { "Biscuit",   "round wafer biscuit"     },
    { "Peanuts",   "roasted peanut halves"   },
    { "Cherry",    "glace cherry with stem"  },
    { "Fruit",     "orange slice"            },
    { "Chocolate", "chocolate chunk"         },
    { "Gems",      "candy gem, faceted"      },
    { "Candle",    "lit candle, animated"    }
};

static const WrapDef kWraps[WRAP_COUNT] = {
    { "Open",          "no packaging, serve as is"    },
    { "Rope Tie",      "two bands crossed with a bow" },
    { "Gift Box",      "open box with a window front"  },
    { "Wrapping Sheet","patterned sheet, folded"      },
    { "Ribbon & Tag",  "waist ribbon and a name tag"  }
};

const ShapeDef&   shapeDef(int id)   { return kShapes[(id >= 0 && id < SHAPE_COUNT) ? id : 0]; }
const ToppingDef& toppingDef(int id) { return kToppings[(id >= 0 && id < TOP_COUNT) ? id : 0]; }
const WrapDef&    wrapDef(int id)    { return kWraps[(id >= 0 && id < WRAP_COUNT) ? id : 0]; }

const FlavorDef& flavorDef(int id) {
    buildFlavors();
    return g_flavors[(id >= 0 && id < FLV_COUNT) ? id : 0];
}

/* --------------------------------------------------------- wrap palette */
static const int kWrapPaletteN = 6;
static Color g_wrapPalette[kWrapPaletteN];
static bool  g_wrapPaletteReady = false;
static const char* kWrapPaletteNames[kWrapPaletteN] = {
    "Rose", "Gold", "Mint", "Sky", "Lilac", "Cocoa"
};

static void buildWrapPalette() {
    if (g_wrapPaletteReady) return;
    g_wrapPalette[0] = rgb(238, 104, 140);
    g_wrapPalette[1] = rgb(246, 190,  80);
    g_wrapPalette[2] = rgb(114, 208, 168);
    g_wrapPalette[3] = rgb(112, 176, 232);
    g_wrapPalette[4] = rgb(186, 148, 232);
    g_wrapPalette[5] = rgb(150, 104,  74);
    g_wrapPaletteReady = true;
}

int wrapPaletteSize() { return kWrapPaletteN; }

Color wrapPaletteColor(int i) {
    buildWrapPalette();
    if (i < 0) i = 0;
    if (i >= kWrapPaletteN) i = kWrapPaletteN - 1;
    return g_wrapPalette[i];
}

const char* wrapPaletteName(int i) {
    if (i < 0) i = 0;
    if (i >= kWrapPaletteN) i = kWrapPaletteN - 1;
    return kWrapPaletteNames[i];
}

/* ==========================================================================
 *  Design
 * ========================================================================*/
Design::Design() { reset(); }

void Design::reset() {
    shape     = SHAPE_CIRCLE;
    polySides = 6;
    layers    = 1;
    flavor    = FLV_STRAWBERRY;
    toppings.clear();
    wrap      = WRAP_NONE;
    wrapColor = 0;
}

bool Design::hasCandle() const {
    for (size_t i = 0; i < toppings.size(); ++i)
        if (toppings[i].type == TOP_CANDLE) return true;
    return false;
}

int Design::countOf(int toppingType) const {
    int n = 0;
    for (size_t i = 0; i < toppings.size(); ++i)
        if (toppings[i].type == toppingType) ++n;
    return n;
}

std::string describe(const Design& d) {
    char buf[192];
    std::sprintf(buf, "%s, %s, %d topping%s, %s",
                 shapeDef(d.shape).name,
                 flavorDef(d.flavor).name,
                 (int)d.toppings.size(),
                 d.toppings.size() == 1 ? "" : "s",
                 wrapDef(d.wrap).name);
    return std::string(buf);
}

/* ==========================================================================
 *  Geometry
 * ========================================================================*/
/*  Corners are preserved exactly and long edges are subdivided, so that the
 *  same code can shade a circle and a triangle without special cases.       */
static void densify(const std::vector<Vec2>& base, int targetSteps, std::vector<Vec2>& out) {
    out.clear();
    size_t n = base.size();
    if (n < 3) { out = base; return; }

    float perimeter = 0.0f;
    for (size_t i = 0; i < n; ++i)
        perimeter += length(base[(i + 1) % n] - base[i]);
    if (perimeter < 1e-5f) { out = base; return; }

    float target = perimeter / (float)targetSteps;
    for (size_t i = 0; i < n; ++i) {
        Vec2 a = base[i];
        Vec2 b = base[(i + 1) % n];
        float len = length(b - a);
        int cuts = (int)(len / target + 0.5f);
        if (cuts < 1) cuts = 1;
        for (int k = 0; k < cuts; ++k) {
            float t = (float)k / (float)cuts;
            out.push_back(Vec2(lerpf(a.x, b.x, t), lerpf(a.y, b.y, t)));
        }
    }
}

void shapeOutlineUnit(std::vector<Vec2>& out, const Design& d, int steps) {
    std::vector<Vec2> base;
    switch (d.shape) {
        case SHAPE_CIRCLE:
            makeCircle(base, Vec2(0.0f, 0.0f), 1.0f, steps);
            out = base;
            return;
        case SHAPE_SQUARE: {
            /*  The square is turned a little before it is squashed. Without
             *  that turn its top face and its front face are both axis
             *  aligned rectangles and the cake reads as a flat wall; turned,
             *  two side faces meet at a front corner and the solid is
             *  immediately legible.                                          */
            float s = 0.78f;
            base.push_back(Vec2( s, -s)); base.push_back(Vec2( s,  s));
            base.push_back(Vec2(-s,  s)); base.push_back(Vec2(-s, -s));
            for (size_t i = 0; i < base.size(); ++i) base[i] = rotated(base[i], 26.0f);
            break;
        }
        case SHAPE_RECT: {
            float w = 1.02f, h = 0.58f;
            base.push_back(Vec2( w, -h)); base.push_back(Vec2( w,  h));
            base.push_back(Vec2(-w,  h)); base.push_back(Vec2(-w, -h));
            for (size_t i = 0; i < base.size(); ++i) base[i] = rotated(base[i], 16.0f);
            break;
        }
        case SHAPE_TRIANGLE: {
            /* counter-clockwise, flat side towards the viewer */
            makeRegularPolygon(base, Vec2(0.0f, -0.08f), 1.12f, 3, 90.0f);
            break;
        }
        case SHAPE_POLYGON: {
            int sides = d.polySides;
            if (sides < 5) sides = 5;
            if (sides > 8) sides = 8;
            makeRegularPolygon(base, Vec2(0.0f, 0.0f), 1.02f, sides,
                               -90.0f + 180.0f / (float)sides);
            break;
        }
        default:
            makeCircle(base, Vec2(0.0f, 0.0f), 1.0f, steps);
            out = base;
            return;
    }
    densify(base, steps, out);
}

bool insideUnitShape(const Design& d, Vec2 uv, float margin) {
    std::vector<Vec2> poly;
    shapeOutlineUnit(poly, d, 48);
    for (size_t i = 0; i < poly.size(); ++i) poly[i] = poly[i] * margin;
    return pointInPoly(poly, uv);
}

Frame makeFrame(Vec2 centre, float radius, int layers) {
    Frame f;
    f.centre      = centre;
    f.radius      = radius;
    f.squash      = 0.40f;
    /*  A single tier is roughly half as tall as it is wide; stacked tiers are
     *  shorter each so that a three tier cake still fits the preview.        */
    f.layerHeight = radius * (layers >= 3 ? 0.36f : (layers == 2 ? 0.44f : 0.52f));
    return f;
}

float layerScale(const Design& d, int layerIndex) {
    if (d.layers <= 1) return 1.0f;
    return std::pow(0.78f, (float)layerIndex);
}

float topElevation(const Design& d, const Frame& f) {
    return f.layerHeight * (float)d.layers;
}

Vec2 topCentre(const Design& d, const Frame& f) {
    return Vec2(f.centre.x, f.centre.y + topElevation(d, f));
}

Vec2 uvToScreen(const Design& d, const Frame& f, Vec2 uv) {
    float s = layerScale(d, d.layers - 1);
    return Vec2(f.centre.x + uv.x * f.radius * s,
                f.centre.y + uv.y * f.radius * f.squash * s + topElevation(d, f));
}

bool screenToUV(const Design& d, const Frame& f, Vec2 screen, Vec2& uvOut) {
    float s = layerScale(d, d.layers - 1);
    if (f.radius < 1e-3f || s < 1e-3f) return false;
    uvOut.x = (screen.x - f.centre.x) / (f.radius * s);
    uvOut.y = (screen.y - f.centre.y - topElevation(d, f)) / (f.radius * f.squash * s);
    return insideUnitShape(d, uvOut);
}

float toppingPixelSize(const Design& d, const Frame& f) {
    return f.radius * 0.105f * layerScale(d, d.layers - 1);
}

/* ==========================================================================
 *  Render options
 * ========================================================================*/
RenderOpts::RenderOpts()
    : time(0.0f), showToppings(true), showWrap(true), showPlate(true),
      highlightSurface(false), algorithmView(false), ghostTopping(-1),
      ghostUV(0.0f, 0.0f), ghostValid(false), selectedTopping(-1) {}

/* ==========================================================================
 *  Cake rendering
 * ========================================================================*/
static const Vec2 kLightDir(-0.62f, 0.78f);   /* light from the upper left */

static void outlineAt(const std::vector<Vec2>& unit, const Frame& f,
                      float scale, float elevation, std::vector<Vec2>& out) {
    out.resize(unit.size());
    for (size_t i = 0; i < unit.size(); ++i) {
        out[i] = Vec2(f.centre.x + unit[i].x * f.radius * scale,
                      f.centre.y + unit[i].y * f.radius * f.squash * scale + elevation);
    }
}

/*  Outward normal of the edge starting at index i, in unit space, assuming a
 *  counter-clockwise loop.                                                  */
static Vec2 edgeNormal(const std::vector<Vec2>& unit, size_t i) {
    const Vec2& a = unit[i];
    const Vec2& b = unit[(i + 1) % unit.size()];
    return normalize(Vec2(b.y - a.y, -(b.x - a.x)));
}

static void drawPlate(const Design& d, const Frame& f, const Color& plate, const Color& edge) {
    float s = 1.0f;
    for (int i = 0; i < d.layers; ++i) s = std::max(s, layerScale(d, i));
    float rx = f.radius * s * 1.30f;
    float ry = f.radius * f.squash * s * 1.30f;

    softShadow(Vec2(f.centre.x, f.centre.y - ry * 0.30f), rx * 1.05f, ry * 0.80f, 0.30f);
    fillEllipse(Vec2(f.centre.x, f.centre.y - 7.0f), rx, ry, shade(edge, 0.86f), 64);
    fillEllipseGrad(Vec2(f.centre.x, f.centre.y - 2.0f), rx, ry,
                    mix(plate, rgb(255, 255, 255), 0.35f), shade(plate, 0.88f), 64);
    {
        std::vector<Vec2> rim;
        makeEllipse(rim, Vec2(f.centre.x, f.centre.y - 2.0f), rx, ry, 64);
        polyline(rim, withAlpha(edge, 0.85f), 1.6f, true);
        makeEllipse(rim, Vec2(f.centre.x, f.centre.y - 2.0f), rx * 0.86f, ry * 0.86f, 64);
        polyline(rim, withAlpha(edge, 0.45f), 1.1f, true);
    }
    /* a soft sheen sweeping across the plate */
    fillEllipse(Vec2(f.centre.x - rx * 0.34f, f.centre.y + ry * 0.20f),
                rx * 0.34f, ry * 0.30f, withAlpha(rgb(255, 255, 255), 0.22f), 32);
}

/*  One tier: the extruded sides, the filling stripe, the frosting collar,
 *  the drips and the frosted top face.                                      */
static void drawTier(const Design& d, const Frame& f, const std::vector<Vec2>& unit,
                     int layer, const RenderOpts& o) {
    const FlavorDef& fl = flavorDef(d.flavor);
    float scale = layerScale(d, layer);
    float eBot  = f.layerHeight * (float)layer;
    float eTop  = f.layerHeight * (float)(layer + 1);

    std::vector<Vec2> top, bot;
    outlineAt(unit, f, scale, eTop, top);
    outlineAt(unit, f, scale, eBot, bot);

    size_t n = unit.size();
    float  h = f.layerHeight;

    /* ---- 1. the sides of the tier ------------------------------------- */
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;                    /* facing away    */

        size_t j = (i + 1) % n;
        float k = clampf(0.88f + 0.30f * (-nrm.x * kLightDir.x + 0.0f), 0.56f, 1.16f);

        Color spTop = shade(fl.sponge,     k);
        Color spBot = shade(fl.spongeDark, k * 0.94f);

        glBegin(GL_QUADS);
        useColor(spTop); glVertex2f(top[i].x, top[i].y); glVertex2f(top[j].x, top[j].y);
        useColor(spBot); glVertex2f(bot[j].x, bot[j].y); glVertex2f(bot[i].x, bot[i].y);
        glEnd();

        /* the cream filling that runs through the middle of the sponge */
        float f0 = 0.40f, f1 = 0.55f;
        Color fillCol = shade(fl.filling, k);
        glBegin(GL_QUADS);
        useColor(fillCol);
        glVertex2f(top[i].x, top[i].y - h * f0); glVertex2f(top[j].x, top[j].y - h * f0);
        glVertex2f(top[j].x, top[j].y - h * f1); glVertex2f(top[i].x, top[i].y - h * f1);
        glEnd();

        /* crumb speckle, deterministic so it never crawls between frames */
        for (int s = 0; s < 3; ++s) {
            float ta = hash21((float)(i * 7 + s), (float)layer * 3.0f + 1.0f);
            float tb = 0.10f + 0.78f * hash21((float)(i * 13 + s), (float)layer * 5.0f + 2.0f);
            if (tb > f0 - 0.04f && tb < f1 + 0.04f) continue;
            Vec2 p(lerpf(top[i].x, top[j].x, ta), lerpf(top[i].y, top[j].y, ta) - h * tb);
            fillCircle(p, h * 0.022f, withAlpha(shade(fl.spongeDark, 0.82f), 0.55f), 8);
        }
    }

    /* ---- 2. drips of frosting running down the front ------------------ */
    float dripSpacing = std::max(30.0f, f.radius * 0.185f);
    float travelled   = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) { travelled = 0.0f; continue; }
        size_t j = (i + 1) % n;
        float segLen = length(top[j] - top[i]);
        float pos = dripSpacing - travelled;
        while (pos < segLen) {
            float t = pos / std::max(segLen, 1e-4f);
            Vec2 p(lerpf(top[i].x, top[j].x, t), lerpf(top[i].y, top[j].y, t));
            float seed = hash21(p.x * 0.11f, (float)layer * 4.0f + 0.5f);
            float len  = h * (0.10f + 0.30f * seed);
            float rad  = h * (0.048f + 0.030f * hash11(p.x * 0.07f + (float)layer));
            Color c    = mix(fl.cream, fl.drip, 0.55f);
            fillCapsule(Vec2(p.x, p.y - rad * 0.2f), Vec2(p.x, p.y - len), rad, c);
            fillCircle(Vec2(p.x - rad * 0.30f, p.y - len + rad * 0.25f), rad * 0.30f,
                       withAlpha(rgb(255, 255, 255), 0.28f), 10);
            pos += dripSpacing;
        }
        travelled = std::fmod(travelled + segLen, dripSpacing);
    }

    /* ---- 3. the frosting collar sitting on the rim -------------------- */
    float collar = h * 0.20f;
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;
        size_t j = (i + 1) % n;
        float k = clampf(0.90f + 0.26f * (-nrm.x * kLightDir.x), 0.60f, 1.18f);
        glBegin(GL_QUADS);
        useColor(shade(fl.cream, k));
        glVertex2f(top[i].x, top[i].y);
        glVertex2f(top[j].x, top[j].y);
        useColor(shade(fl.creamDeep, k * 0.95f));
        glVertex2f(top[j].x, top[j].y - collar);
        glVertex2f(top[i].x, top[i].y - collar);
        glEnd();
    }

    /* ---- 4. the frosted top face -------------------------------------- */
    Vec2 c = Vec2(f.centre.x, f.centre.y + eTop);
    fillPolyGrad(top, Vec2(c.x - f.radius * scale * 0.16f, c.y + f.radius * f.squash * scale * 0.20f),
                 mix(fl.cream, rgb(255, 255, 255), 0.30f), fl.creamDeep);

    /* a soft sheen towards the light */
    fillEllipse(Vec2(c.x - f.radius * scale * 0.34f, c.y + f.radius * f.squash * scale * 0.30f),
                f.radius * scale * 0.30f, f.radius * f.squash * scale * 0.26f,
                withAlpha(rgb(255, 255, 255), 0.16f), 32);

    polyline(top, withAlpha(shade(fl.creamDeep, 0.80f), 0.55f), 1.4f, true);

    /* ---- 5. piped dollops around the rim ------------------------------ */
    float pipeSpacing = std::max(20.0f, f.radius * scale * 0.16f);
    float acc = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        size_t j = (i + 1) % n;
        float segLen = length(top[j] - top[i]);
        float pos = pipeSpacing - acc;
        while (pos < segLen) {
            float t = pos / std::max(segLen, 1e-4f);
            Vec2 p(lerpf(top[i].x, top[j].x, t), lerpf(top[i].y, top[j].y, t));
            Vec2 inward = normalize(Vec2(c.x - p.x, c.y - p.y));
            Vec2 q = p + inward * (f.radius * scale * 0.045f);
            float r = f.radius * scale * 0.048f;
            fillCircle(q, r, mix(fl.cream, rgb(255, 255, 255), 0.16f), 14);
            fillCircle(Vec2(q.x - r * 0.28f, q.y + r * 0.26f), r * 0.40f,
                       withAlpha(rgb(255, 255, 255), 0.40f), 10);
            fillCircle(Vec2(q.x + r * 0.10f, q.y - r * 0.42f), r * 0.55f,
                       withAlpha(shade(fl.creamDeep, 0.90f), 0.30f), 10);
            pos += pipeSpacing;
        }
        acc = std::fmod(acc + segLen, pipeSpacing);
    }

    /* ---- 6. optional highlight of the placement surface --------------- */
    if (o.highlightSurface && layer == d.layers - 1) {
        float pulse = 0.5f + 0.5f * std::sin(o.time * 2.6f);
        std::vector<Vec2> inner(top.size());
        for (size_t i = 0; i < top.size(); ++i) {
            inner[i] = Vec2(c.x + (top[i].x - c.x) * 0.90f,
                            c.y + (top[i].y - c.y) * 0.90f);
        }
        polyline(inner, withAlpha(rgb(255, 255, 255), 0.18f + 0.22f * pulse), 2.0f, true);
    }
}

/*  Toppings are painted from the back of the cake towards the front so that
 *  the ones nearer the viewer correctly overlap the ones behind.            */
static void drawToppings(const Design& d, const Frame& f, const RenderOpts& o) {
    std::vector<int> order;
    order.reserve(d.toppings.size());
    for (size_t i = 0; i < d.toppings.size(); ++i) order.push_back((int)i);

    const std::vector<Placed>& tp = d.toppings;
    for (size_t a = 1; a < order.size(); ++a) {          /* insertion sort by v */
        int key = order[a];
        size_t b = a;
        while (b > 0 && tp[(size_t)order[b - 1]].v < tp[(size_t)key].v) {
            order[b] = order[b - 1];
            --b;
        }
        order[b] = key;
    }

    float base = toppingPixelSize(d, f);
    for (size_t k = 0; k < order.size(); ++k) {
        int idx = order[k];
        const Placed& p = tp[(size_t)idx];
        Vec2 pos = uvToScreen(d, f, Vec2(p.u, p.v));

        /* pop-in: a short scale overshoot when the piece is first placed */
        float age  = clampf((o.time - p.born) / 0.28f, 0.0f, 1.0f);
        float pop  = age < 1.0f ? (1.0f + 0.35f * std::sin(age * PI)) * age : 1.0f;
        float size = base * p.scale * pop;

        fillEllipse(Vec2(pos.x + size * 0.10f, pos.y - size * 0.42f),
                    size * 0.66f, size * 0.26f, withAlpha(rgb(60, 30, 45), 0.22f), 20);

        drawTopping(p.type, pos, size, p.rot, p.variant, o.time, 1.0f);

        if (o.selectedTopping == idx) {
            float pulse = 0.5f + 0.5f * std::sin(o.time * 6.0f);
            strokeCircle(pos, size * 1.25f, withAlpha(rgb(255, 120, 120), 0.55f + 0.35f * pulse),
                         2.0f, 24);
        }
    }

    if (o.ghostTopping >= 0 && o.ghostValid) {
        Vec2 pos = uvToScreen(d, f, o.ghostUV);
        drawTopping(o.ghostTopping, pos, base, 0.0f, 3, o.time, 0.45f);
        strokeCircle(pos, base * 1.30f, withAlpha(rgb(255, 255, 255), 0.35f), 1.4f, 24);
    }
}

/*  The algorithm view redraws the silhouette using the scan converters, so a
 *  viewer can see the actual rasterised pixels of the shapes on screen.      */
static void drawAlgorithmOverlay(const Design& d, const Frame& f, const RenderOpts& o) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 72);

    float scale = layerScale(d, d.layers - 1);
    Vec2  c     = topCentre(d, f);
    Color hot   = rgb(120, 255, 200);
    Color cool  = rgb(140, 190, 255);

    if (d.shape == SHAPE_CIRCLE) {
        ellipseMidpoint(c, f.radius * scale, f.radius * f.squash * scale, hot, 2.0f);
        text(c.x - f.radius * scale, c.y + f.radius * f.squash * scale + 14.0f,
             "midpoint ellipse", hot, FONT_XS);
    } else {
        std::vector<Vec2> top;
        outlineAt(unit, f, scale, topElevation(d, f), top);
        polylineBresenham(top, hot, true, 2.0f);
        text(c.x - f.radius * scale, c.y + f.radius * f.squash * scale + 14.0f,
             "Bresenham line loop", hot, FONT_XS);
    }

    /* the base of the bottom tier, drawn with the DDA */
    std::vector<Vec2> bot;
    outlineAt(unit, f, layerScale(d, 0), 0.0f, bot);
    for (size_t i = 0; i < bot.size(); ++i)
        lineDDA(bot[i], bot[(i + 1) % bot.size()], cool, 2.0f);
    text(f.centre.x - f.radius, f.centre.y - f.radius * f.squash - 22.0f,
         "DDA base outline", cool, FONT_XS);

    /* the vertical extrusion edges that build the sides */
    for (size_t i = 0; i < unit.size(); i += 6) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;
        std::vector<Vec2> t2;
        outlineAt(unit, f, layerScale(d, 0), f.layerHeight, t2);
        lineBresenham(t2[i], bot[i], withAlpha(rgb(255, 220, 120), 0.9f), 1.6f);
    }
    (void)o;
}

void drawCake(const Design& d, const Frame& f, const RenderOpts& o) {
    buildFlavors();
    buildWrapPalette();

    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 72);

    if (o.showWrap && d.wrap != WRAP_NONE) drawWrapBehind(d, f, o.time);
    if (o.showPlate) drawPlate(d, f, rgb(240, 234, 242), rgb(186, 176, 192));

    for (int layer = 0; layer < d.layers; ++layer)
        drawTier(d, f, unit, layer, o);

    if (o.showToppings) drawToppings(d, f, o);
    if (o.showWrap && d.wrap != WRAP_NONE) drawWrapFront(d, f, o.time);
    if (o.algorithmView) drawAlgorithmOverlay(d, f, o);
}

/* ==========================================================================
 *  Shape icon used on the option buttons
 * ========================================================================*/
void drawShapeIcon(int shapeId, int polySides, Vec2 centre, float size, const Color& c) {
    Color edge = shade(c, 0.72f);
    switch (shapeId) {
        case SHAPE_CIRCLE:
            fillCircle(centre, size, c, 40);
            strokeCircle(centre, size, edge, 1.6f, 40);
            break;
        case SHAPE_SQUARE:
            fillRoundRect(centre.x - size * 0.86f, centre.y - size * 0.86f,
                          size * 1.72f, size * 1.72f, size * 0.14f, c);
            strokeRoundRect(centre.x - size * 0.86f, centre.y - size * 0.86f,
                            size * 1.72f, size * 1.72f, size * 0.14f, edge, 1.6f);
            break;
        case SHAPE_RECT:
            fillRoundRect(centre.x - size * 1.05f, centre.y - size * 0.62f,
                          size * 2.10f, size * 1.24f, size * 0.14f, c);
            strokeRoundRect(centre.x - size * 1.05f, centre.y - size * 0.62f,
                            size * 2.10f, size * 1.24f, size * 0.14f, edge, 1.6f);
            break;
        case SHAPE_TRIANGLE: {
            std::vector<Vec2> p;
            makeRegularPolygon(p, Vec2(centre.x, centre.y - size * 0.10f), size * 1.14f, 3, 90.0f);
            fillPoly(p, c);
            polyline(p, edge, 1.6f, true);
            break;
        }
        case SHAPE_POLYGON: {
            int sides = polySides < 5 ? 5 : (polySides > 8 ? 8 : polySides);
            std::vector<Vec2> p;
            makeRegularPolygon(p, centre, size * 1.02f, sides, -90.0f + 180.0f / (float)sides);
            fillPoly(p, c);
            polyline(p, edge, 1.6f, true);
            break;
        }
        default: break;
    }
}

} /* namespace cake */
