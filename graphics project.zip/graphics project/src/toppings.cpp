/* ============================================================================
 *  CakeLab  -  toppings.cpp
 *  Every decorative ingredient the user can place on the cake.
 *
 *  Each ingredient is a composite object: several primitives grouped together
 *  and drawn in its own local coordinate system, which runs roughly from -1 to
 *  +1. drawTopping() pushes a translation, a rotation and a scale before
 *  calling the piece, so the same code draws a cherry at any position, any
 *  angle and any size. This is the "car and jeep" pattern from the lab work,
 *  applied to cake decorations.
 * ==========================================================================*/
#include "cake.h"
#include <algorithm>

namespace cake {

using namespace gfx;

/*  All colours pass through A() so that a whole ingredient can be drawn
 *  half transparent when it is only a placement preview.                    */
static float g_alpha = 1.0f;
static Color A(const Color& c) { return Color(c.r, c.g, c.b, c.a * g_alpha); }

/* -------------------------------------------------------------- berries */
static void drawBerry(int variant, float time) {
    (void)time;
    Color deep = rgb( 46,  44, 110);
    Color mid  = rgb( 78,  76, 168);
    Color lit  = rgb(126, 128, 216);
    if (variant % 3 == 1) { deep = rgb( 92, 24,  62); mid = rgb(146, 40,  96); lit = rgb(196, 84, 142); }
    if (variant % 3 == 2) { deep = rgb( 24,  62, 46); mid = rgb( 48, 108, 78); lit = rgb( 96, 168, 128); }

    struct B { float x, y, r; };
    B balls[3] = { { -0.36f, 0.28f, 0.44f }, { 0.38f, 0.22f, 0.40f }, { 0.00f, -0.22f, 0.56f } };

    for (int i = 0; i < 3; ++i) {
        Vec2 c(balls[i].x, balls[i].y);
        float r = balls[i].r;
        fillCircleGrad(c, r, A(mid), A(deep), 26);
        fillCircle(Vec2(c.x - r * 0.30f, c.y + r * 0.34f), r * 0.30f, A(withAlpha(lit, 0.85f)), 14);
        /* the little crown at the top of a blueberry */
        fillStar(Vec2(c.x + r * 0.05f, c.y + r * 0.42f), r * 0.30f, r * 0.12f, 5, 18.0f,
                 A(shade(deep, 0.7f)));
    }
}

/* -------------------------------------------------------------- biscuit */
static void drawBiscuit(int variant, float time) {
    (void)time;
    Color edge = rgb(176, 126,  76);
    Color face = rgb(226, 182, 128);
    Color dot  = rgb(126,  84,  48);
    if (variant % 2 == 1) { edge = rgb(104, 68, 44); face = rgb(150, 104, 68); dot = rgb(72, 44, 28); }

    fillCircle(Vec2(0.0f, -0.16f), 0.92f, A(shade(edge, 0.82f)), 32);   /* thickness */
    fillCircle(Vec2(0.0f,  0.00f), 0.92f, A(edge), 32);
    fillCircleGrad(Vec2(0.0f, 0.0f), 0.80f, A(mix(face, rgb(255, 255, 255), 0.18f)), A(face), 32);
    strokeCircle(Vec2(0.0f, 0.0f), 0.80f, A(withAlpha(shade(edge, 0.75f), 0.7f)), 0.05f, 32);

    for (int i = 0; i < 7; ++i) {
        float a = 2.0f * PI * (float)i / 7.0f + 0.4f;
        float rr = (i == 6) ? 0.0f : 0.45f;
        fillCircle(Vec2(std::cos(a) * rr, std::sin(a) * rr), 0.085f, A(dot), 10);
    }
    /* scalloped rim, drawn with the parametric loop */
    for (int i = 0; i < 16; ++i) {
        float a = 2.0f * PI * (float)i / 16.0f;
        fillCircle(Vec2(std::cos(a) * 0.92f, std::sin(a) * 0.92f), 0.085f, A(edge), 8);
    }
}

/* -------------------------------------------------------------- peanuts */
static void drawPeanut(int variant, float time) {
    (void)time;
    (void)variant;
    Color shell     = rgb(214, 168, 104);
    Color shellDark = rgb(168, 122,  66);
    Color shellLite = rgb(240, 208, 150);

    fillEllipse(Vec2(-0.34f, -0.06f), 0.50f, 0.44f, A(shellDark), 26);
    fillEllipse(Vec2( 0.34f, -0.06f), 0.46f, 0.40f, A(shellDark), 26);
    fillEllipse(Vec2(-0.34f,  0.02f), 0.48f, 0.42f, A(shell), 26);
    fillEllipse(Vec2( 0.34f,  0.02f), 0.44f, 0.38f, A(shell), 26);
    fillRect(-0.34f, -0.20f, 0.68f, 0.44f, A(shell));

    fillEllipse(Vec2(-0.44f, 0.18f), 0.18f, 0.12f, A(withAlpha(shellLite, 0.8f)), 16);
    fillEllipse(Vec2( 0.26f, 0.20f), 0.14f, 0.09f, A(withAlpha(shellLite, 0.6f)), 16);

    /* the seam that pinches the shell in the middle */
    std::vector<Vec2> seam;
    makeBezier(seam, Vec2(-0.78f, 0.06f), Vec2(-0.20f, 0.26f), Vec2(0.20f, -0.18f), Vec2(0.76f, 0.04f), 18);
    polyline(seam, A(withAlpha(shellDark, 0.75f)), 0.05f, false);
    fillCircle(Vec2(0.0f, 0.05f), 0.07f, A(withAlpha(shellDark, 0.5f)), 10);
}

/* --------------------------------------------------------------- cherry */
static void drawCherry(int variant, float time) {
    Color body     = (variant % 2 == 0) ? rgb(198, 30, 52) : rgb(166, 22, 68);
    Color bodyDeep = shade(body, 0.62f);
    Color stem     = rgb(96, 128, 54);

    float sway = std::sin(time * 1.6f + (float)variant) * 3.0f;

    std::vector<Vec2> curve;
    makeBezier(curve, Vec2(0.04f, 0.55f), Vec2(0.10f, 1.02f),
               Vec2(0.42f + sway * 0.01f, 1.10f), Vec2(0.62f + sway * 0.012f, 1.42f), 16);
    polyline(curve, A(stem), 0.10f, false);

    /* leaf */
    pushTransform(Vec2(0.72f, 1.30f), 24.0f + sway, 1.0f, 1.0f);
    fillEllipse(Vec2(0.16f, 0.06f), 0.26f, 0.12f, A(rgb(112, 158, 62)), 20);
    line(Vec2(-0.06f, 0.02f), Vec2(0.38f, 0.08f), A(shade(rgb(112, 158, 62), 0.7f)), 0.03f);
    popTransform();

    fillCircleGrad(Vec2(0.0f, 0.0f), 0.78f, A(mix(body, rgb(255, 140, 150), 0.25f)), A(bodyDeep), 32);
    fillEllipse(Vec2(-0.26f, 0.30f), 0.22f, 0.15f, A(withAlpha(rgb(255, 255, 255), 0.60f)), 18);
    fillEllipse(Vec2( 0.28f, -0.34f), 0.20f, 0.10f, A(withAlpha(rgb(255, 200, 200), 0.20f)), 18);
    fillCircle(Vec2(0.05f, 0.52f), 0.10f, A(shade(bodyDeep, 0.8f)), 12);
}

/* ---------------------------------------------------------- fruit slice */
static void drawFruitSlice(int variant, float time) {
    (void)time;
    Color rind   = rgb(236, 142,  38);
    Color pith   = rgb(255, 232, 196);
    Color flesh  = rgb(255, 172,  60);
    Color fleshD = rgb(236, 132,  30);
    if (variant % 3 == 1) { rind = rgb(206, 60, 74); flesh = rgb(240, 96, 110); fleshD = rgb(200, 54, 70); }
    if (variant % 3 == 2) { rind = rgb(158, 190, 52); flesh = rgb(206, 232, 118); fleshD = rgb(158, 196, 70); }

    fillCircle(Vec2(0.0f, 0.0f), 0.96f, A(rind), 40);
    fillCircle(Vec2(0.0f, 0.0f), 0.86f, A(pith), 40);

    for (int i = 0; i < 8; ++i) {
        float a0 = 45.0f * (float)i + 3.0f;
        float a1 = 45.0f * (float)(i + 1) - 3.0f;
        fillArc(Vec2(0.0f, 0.0f), 0.78f, a0, a1, A(flesh), 10);
        /* a faint radial crease so the segments read separately */
        float am = deg2rad((a0 + a1) * 0.5f);
        line(Vec2(0.0f, 0.0f), Vec2(std::cos(am) * 0.74f, std::sin(am) * 0.74f),
             A(withAlpha(fleshD, 0.45f)), 0.035f);
    }
    fillCircle(Vec2(0.0f, 0.0f), 0.13f, A(pith), 16);
    fillEllipse(Vec2(-0.30f, 0.34f), 0.26f, 0.16f, A(withAlpha(rgb(255, 255, 255), 0.28f)), 20);
}

/* ------------------------------------------------------ chocolate chunk */
static void drawChocolate(int variant, float time) {
    (void)time;
    Color top   = rgb(120,  76,  48);
    Color front = rgb( 82,  48,  28);
    Color side  = rgb( 62,  35,  20);
    if (variant % 3 == 1) { top = rgb(232, 216, 190); front = rgb(198, 176, 146); side = rgb(168, 146, 116); }
    if (variant % 3 == 2) { top = rgb(196, 128,  72); front = rgb(150,  90,  46); side = rgb(120,  70,  34); }

    float w = 0.72f, dpt = 0.34f, hgt = 0.40f;

    std::vector<Vec2> topFace;
    topFace.push_back(Vec2(-w,  0.10f));
    topFace.push_back(Vec2(-w + dpt,  0.10f + dpt * 0.62f));
    topFace.push_back(Vec2( w,        0.10f + dpt * 0.62f));
    topFace.push_back(Vec2( w - dpt,  0.10f));
    fillPoly(topFace, A(top));

    fillRect(-w, 0.10f - hgt, 2.0f * w - dpt, hgt, A(front));

    std::vector<Vec2> rightFace;
    rightFace.push_back(Vec2(w - dpt, 0.10f));
    rightFace.push_back(Vec2(w,       0.10f + dpt * 0.62f));
    rightFace.push_back(Vec2(w,       0.10f + dpt * 0.62f - hgt));
    rightFace.push_back(Vec2(w - dpt, 0.10f - hgt));
    fillPoly(rightFace, A(side));

    line(Vec2(-w, 0.10f), Vec2(w - dpt, 0.10f), A(withAlpha(shade(top, 1.25f), 0.6f)), 0.045f);
    fillRect(-w + 0.08f, 0.10f - hgt * 0.85f, 0.10f, hgt * 0.62f,
             A(withAlpha(rgb(255, 255, 255), 0.14f)));
}

/* ------------------------------------------------------------ candy gem */
static void drawGem(int variant, float time) {
    float hue = std::fmod(35.0f + (float)(variant % 6) * 58.0f, 360.0f);
    Color bright = hsv(hue, 0.62f, 1.00f);
    Color midC   = hsv(hue, 0.78f, 0.86f);
    Color deep   = hsv(hue, 0.86f, 0.60f);

    std::vector<Vec2> crown;
    makeRegularPolygon(crown, Vec2(0.0f, 0.24f), 0.72f, 6, 0.0f);
    for (size_t i = 0; i < crown.size(); ++i) crown[i].y = 0.24f + (crown[i].y - 0.24f) * 0.62f;
    fillPoly(crown, A(midC));

    /* the pavilion, a fan of triangles meeting at the point */
    for (size_t i = 0; i < crown.size(); ++i) {
        const Vec2& a = crown[i];
        const Vec2& b = crown[(i + 1) % crown.size()];
        if (a.y < 0.24f || b.y < 0.24f) {
            float k = 0.62f + 0.38f * hash11((float)i * 3.7f + (float)variant);
            fillTri(a, b, Vec2(0.0f, -0.86f), A(shade(deep, k)));
        }
    }
    fillPoly(crown, A(withAlpha(bright, 0.35f)));

    std::vector<Vec2> table;
    makeRegularPolygon(table, Vec2(0.0f, 0.26f), 0.34f, 6, 0.0f);
    for (size_t i = 0; i < table.size(); ++i) table[i].y = 0.26f + (table[i].y - 0.26f) * 0.62f;
    fillPoly(table, A(mix(bright, rgb(255, 255, 255), 0.35f)));
    polyline(crown, A(withAlpha(rgb(255, 255, 255), 0.45f)), 0.035f, true);

    float tw = 0.5f + 0.5f * std::sin(time * 3.2f + (float)variant * 1.7f);
    fillStar(Vec2(-0.30f, 0.44f), 0.22f + 0.08f * tw, 0.06f, 4, 0.0f,
             A(withAlpha(rgb(255, 255, 255), 0.55f + 0.35f * tw)));
}

/* --------------------------------------------------------------- candle */
static void drawCandle(int variant, float time) {
    Color waxA = rgb(255, 250, 244);
    Color waxB = rgb(238, 110, 140);
    if (variant % 3 == 1) { waxB = rgb(112, 186, 232); }
    if (variant % 3 == 2) { waxB = rgb(140, 206, 150); }

    float bodyW = 0.30f, bodyBot = -0.86f, bodyTop = 0.60f;

    /* body, with candy stripes drawn as slanted bands clipped to the body */
    fillRoundRect(-bodyW, bodyBot, bodyW * 2.0f, bodyTop - bodyBot, bodyW * 0.35f, A(waxA));
    for (int i = -3; i <= 5; ++i) {
        float y0 = bodyBot + (float)i * 0.30f;
        std::vector<Vec2> band;
        band.push_back(Vec2(-bodyW, clampf(y0,          bodyBot, bodyTop)));
        band.push_back(Vec2(-bodyW, clampf(y0 + 0.14f,  bodyBot, bodyTop)));
        band.push_back(Vec2( bodyW, clampf(y0 + 0.32f,  bodyBot, bodyTop)));
        band.push_back(Vec2( bodyW, clampf(y0 + 0.18f,  bodyBot, bodyTop)));
        fillPoly(band, A(waxB));
    }
    fillRect(-bodyW, bodyBot, bodyW * 0.55f, bodyTop - bodyBot,
             A(withAlpha(rgb(255, 255, 255), 0.22f)));
    fillEllipse(Vec2(0.0f, bodyTop), bodyW, bodyW * 0.34f, A(shade(waxA, 0.94f)), 20);
    strokeRoundRect(-bodyW, bodyBot, bodyW * 2.0f, bodyTop - bodyBot, bodyW * 0.35f,
                    A(withAlpha(rgb(160, 120, 140), 0.45f)), 0.035f);

    /* wick */
    line(Vec2(0.0f, bodyTop), Vec2(0.03f, bodyTop + 0.16f), A(rgb(60, 48, 44)), 0.055f);

    /* flame: two teardrops with a little independent flicker */
    float f1 = std::sin(time * 9.3f + (float)variant * 2.1f);
    float f2 = std::sin(time * 14.7f + (float)variant * 3.7f);
    float flick = 0.6f * f1 + 0.4f * f2;
    float tilt  = flick * 6.0f;
    float sy    = 1.0f + 0.10f * flick;
    Vec2  base(0.03f, bodyTop + 0.14f);

    fillCircleGrad(Vec2(base.x, base.y + 0.30f), 0.62f,
                   A(withAlpha(rgb(255, 190, 90), 0.30f)),
                   A(withAlpha(rgb(255, 160, 60), 0.0f)), 24);

    pushTransform(base, tilt, 1.0f, sy);
    std::vector<Vec2> flame;
    flame.push_back(Vec2( 0.00f, 0.72f));
    flame.push_back(Vec2( 0.17f, 0.34f));
    flame.push_back(Vec2( 0.15f, 0.10f));
    flame.push_back(Vec2( 0.00f, 0.00f));
    flame.push_back(Vec2(-0.15f, 0.10f));
    flame.push_back(Vec2(-0.17f, 0.34f));
    fillPolyGradV(flame, A(rgb(238, 96, 40)), A(rgb(255, 208, 80)));

    std::vector<Vec2> core;
    core.push_back(Vec2( 0.00f, 0.46f));
    core.push_back(Vec2( 0.09f, 0.24f));
    core.push_back(Vec2( 0.00f, 0.06f));
    core.push_back(Vec2(-0.09f, 0.24f));
    fillPolyGradV(core, A(withAlpha(rgb(120, 170, 255), 0.85f)), A(withAlpha(rgb(255, 255, 220), 0.95f)));
    popTransform();
}

/* ==========================================================================
 *  Dispatch
 * ========================================================================*/
void drawTopping(int type, Vec2 centre, float size, float rotDeg, int variant,
                 float time, float alpha) {
    g_alpha = clampf(alpha, 0.0f, 1.0f);
    pushTransform(centre, rotDeg, size, size);
    switch (type) {
        case TOP_BERRY:     drawBerry(variant, time);      break;
        case TOP_BISCUIT:   drawBiscuit(variant, time);    break;
        case TOP_PEANUT:    drawPeanut(variant, time);     break;
        case TOP_CHERRY:    drawCherry(variant, time);     break;
        case TOP_FRUIT:     drawFruitSlice(variant, time); break;
        case TOP_CHOCOLATE: drawChocolate(variant, time);  break;
        case TOP_GEM:       drawGem(variant, time);        break;
        case TOP_CANDLE:    drawCandle(variant, time);     break;
        default: break;
    }
    popTransform();
    g_alpha = 1.0f;
}

} /* namespace cake */
