/* ============================================================================
 *  CakeLab  -  app.h
 *  The application shell: window layout, the stage machine and the shared
 *  state that the four stage modules read and write.
 *
 *  The program is one window with four sequential stages. Each stage owns a
 *  panel of option buttons on the left and shares the live preview on the
 *  right. A stage is described by a StageDef, which is nothing more than a
 *  title and a set of callbacks, so adding or reordering stages does not
 *  touch the shell.
 * ==========================================================================*/
#ifndef CAKELAB_APP_H
#define CAKELAB_APP_H

#include "cake.h"
#include "ui.h"
#include <vector>
#include <string>

namespace app {

enum Screen { SCREEN_WELCOME = 0, SCREEN_STAGE, SCREEN_FINISH };

const int STAGE_COUNT = 4;

/* ----------------------------------------------------------------- layout */
struct Layout {
    float W, H;
    float headerY, headerH;
    float footerY, footerH;
    float panelX, panelY, panelW, panelH;
    float previewX, previewY, previewW, previewH;
};
extern Layout L;
void computeLayout(int w, int h);

/* ----------------------------------------------------------- stage plumbing */
struct StageDef {
    const char* key;
    const char* title;
    const char* subtitle;
    const char* hint;

    void (*build)();                 /* fill g_options / g_extras            */
    void (*onOption)(int id);        /* an option row was clicked            */
    void (*onExtra)(int id);         /* a chip in the extras row was clicked */
    void (*drawPanelExtra)();        /* anything below the option list       */
    void (*drawPreviewOverlay)();    /* stage specific marks in the preview  */
    void (*onPreviewMouse)(float x, float y, int button, int state);
    void (*onPreviewMotion)(float x, float y);
    bool (*canAdvance)();            /* is the Next button enabled           */
};

const StageDef& stageShape();
const StageDef& stageFlavor();
const StageDef& stageToppings();
const StageDef& stageWrap();
const StageDef& currentStage();

/* ------------------------------------------------------------ shared state */
extern cake::Design           g_design;
extern std::vector<ui::Button> g_options;
extern std::vector<ui::Button> g_extras;
extern float g_time;
extern float g_mouseX, g_mouseY;
extern int   g_stage;
extern int   g_screen;
extern int   g_furthest;
extern bool  g_algorithmView;

/*  Where the cake is drawn in the preview panel.                            */
cake::Frame previewFrame();
float previewCaptionY(int line);
float previewCaptionRight();
cake::Frame heroFrame(float cx, float cy, float radius);

/* ------------------------------------------------- helpers for the stages */
float panelListTop();
float panelListBottom();
void  layoutRows(std::vector<ui::Button>& list, float rowH, float gap, float topEdge);
void  layoutChips(std::vector<ui::Button>& list, float x, float y, float chipW,
                  float chipH, float gap, int perRow);
void  rebuildStage();
void  markDirty();

/* --------------------------------------------------------------- lifecycle */
void init();
void update(float dt);
void draw();

void onMouse(int button, int state, int mx, int my);
void onMotion(int mx, int my);
void onKey(unsigned char key, int mx, int my);
void onSpecial(int key, int mx, int my);

void activateOption(int index);
void toppingsUndo();
void toppingsClear();
void toppingsScatter();
int  toppingsSelected();
bool toppingsGhostValid();
cake::Vec2 toppingsGhostUV();
int  toppingsHoverIndex();
void toppingsResetHover();

void goToStage(int s);
void nextStage();
void prevStage();
void resetDesign();
void randomizeDesign();
void finish();
void saveScreenshot();

} /* namespace app */

#endif /* CAKELAB_APP_H */
