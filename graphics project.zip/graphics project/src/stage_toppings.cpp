/* ============================================================================
 *  CakeLab  -  stage_toppings.cpp
 *  Stage 3 of 4  -  Ingredient placement.
 *  Group member 3.
 *
 *  This is the transformation stage. Each ingredient is a composite object
 *  built at the origin in its own coordinates; putting one on the cake is a
 *  translation to the clicked point, plus a small rotation and scale so that
 *  no two pieces look identical.
 *
 *  Positions are stored in the unit coordinate space of the base shape rather
 *  than in pixels, so the decoration survives a change of shape, a change of
 *  tier count and a change of window size.
 * ==========================================================================*/
#include "app.h"
#include <algorithm>

namespace app {

using namespace gfx;

static const int ID_UNDO    = 300;
static const int ID_CLEAR   = 301;
static const int ID_SCATTER = 302;
static const size_t MAX_TOPPINGS = 80;

static int   s_selected  = cake::TOP_CHERRY;
static bool  s_dragging  = false;
static Vec2  s_lastPlace(-99.0f, -99.0f);
static Vec2  s_ghostUV(0.0f, 0.0f);
static bool  s_ghostValid = false;
static int   s_hoverIndex = -1;
static int   s_scatterSeed = 7;

/* --------------------------------------------------------------- icons */
static void toppingIcon(Vec2 c, float size, float time, int arg) {
    cake::drawTopping(arg, Vec2(c.x, c.y - (arg == cake::TOP_CANDLE ? size * 0.20f : 0.0f)),
                      size * (arg == cake::TOP_CANDLE ? 0.72f : 0.95f), 0.0f, 2, time, 1.0f);
}

static void actionIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    switch (arg) {
        case 0:   /* undo */
            arcStroke(c, size * 0.72f, 40.0f, 300.0f, ui::T.textDim, 2.0f, 20);
            fillTri(Vec2(c.x - size * 0.20f, c.y + size * 0.60f),
                    Vec2(c.x + size * 0.34f, c.y + size * 0.74f),
                    Vec2(c.x + size * 0.10f, c.y + size * 0.20f), ui::T.textDim);
            break;
        case 1:   /* clear */
            line(Vec2(c.x - size * 0.55f, c.y - size * 0.55f),
                 Vec2(c.x + size * 0.55f, c.y + size * 0.55f), ui::T.danger, 2.2f);
            line(Vec2(c.x - size * 0.55f, c.y + size * 0.55f),
                 Vec2(c.x + size * 0.55f, c.y - size * 0.55f), ui::T.danger, 2.2f);
            break;
        case 2:   /* scatter */
            for (int i = 0; i < 5; ++i) {
                float a = 2.0f * PI * (float)i / 5.0f + 0.3f;
                fillCircle(Vec2(c.x + std::cos(a) * size * 0.55f,
                                c.y + std::sin(a) * size * 0.55f),
                           size * 0.16f, ui::T.accent2, 10);
            }
            break;
        default: break;
    }
}

/* --------------------------------------------------------------- build */
static void toppingBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::TOP_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::toppingDef(i).name;
        char sub[64];
        int  n = g_design.countOf(i);
        if (n > 0) std::sprintf(sub, "%s  -  %d placed", cake::toppingDef(i).note, n);
        else       std::sprintf(sub, "%s", cake::toppingDef(i).note);
        b.sub      = sub;
        b.icon     = toppingIcon;
        b.iconArg  = i;
        b.selected = (s_selected == i);
        g_options.push_back(b);
    }

    float rowH = 44.0f, gap = 5.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;
    float y = panelListTop() - (rowH + gap) * (float)cake::TOP_COUNT - 32.0f;

    const char* names[3] = { "Undo", "Clear", "Scatter" };
    for (int i = 0; i < 3; ++i) {
        ui::Button b;
        b.id      = ID_UNDO + i;
        b.style   = ui::BTN_CHIP;
        b.label   = names[i];
        b.icon    = actionIcon;
        b.iconArg = i;
        b.enabled = (i == 2) || !g_design.toppings.empty();
        g_extras.push_back(b);
    }
    layoutChips(g_extras, x, y, (w - 2.0f * 9.0f) / 3.0f, 34.0f, 9.0f, 3);
}

/* ------------------------------------------------------------ placing */
static void placeAt(Vec2 uv) {
    if (g_design.toppings.size() >= MAX_TOPPINGS) {
        ui::toast("That is as much as this cake can hold");
        return;
    }
    cake::Placed p;
    p.type    = s_selected;
    p.u       = uv.x;
    p.v       = uv.y;
    p.variant = (int)(hash21(uv.x * 31.7f, uv.y * 17.3f) * 6.0f) + (int)g_design.toppings.size();
    p.rot     = (hash21(uv.y * 13.0f, uv.x * 7.0f) - 0.5f) * 24.0f;
    p.scale   = 0.86f + 0.30f * hash21(uv.x * 5.5f, uv.y * 9.1f);
    p.born    = g_time;
    if (s_selected == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
    g_design.toppings.push_back(p);
    s_lastPlace = uv;
    rebuildStage();
}

static int nearestTopping(Vec2 screen) {
    cake::Frame f = previewFrame();
    float best = 1e9f;
    int   bestIdx = -1;
    float reach = cake::toppingPixelSize(g_design, f) * 1.25f;
    for (size_t i = 0; i < g_design.toppings.size(); ++i) {
        Vec2 p = cake::uvToScreen(g_design, f, Vec2(g_design.toppings[i].u,
                                                    g_design.toppings[i].v));
        float d = length(p - screen);
        if (d < best && d < reach) { best = d; bestIdx = (int)i; }
    }
    return bestIdx;
}

void toppingsUndo() {
    if (g_design.toppings.empty()) { ui::toast("Nothing to undo"); return; }
    g_design.toppings.pop_back();
    ui::toast("Removed the last ingredient");
    rebuildStage();
}

void toppingsClear() {
    if (g_design.toppings.empty()) { ui::toast("The cake is already plain"); return; }
    g_design.toppings.clear();
    ui::toast("Cleared every ingredient");
    rebuildStage();
}

/*  Scatters eight pieces of the current ingredient by rejection sampling in
 *  the unit square and keeping only the points inside the base shape.       */
void toppingsScatter() {
    int placed = 0;
    for (int attempt = 0; attempt < 400 && placed < 8; ++attempt) {
        ++s_scatterSeed;
        float u = hash21((float)s_scatterSeed * 1.7f, 3.1f) * 2.0f - 1.0f;
        float v = hash21(5.3f, (float)s_scatterSeed * 2.9f) * 2.0f - 1.0f;
        Vec2 uv(u * 1.15f, v * 1.15f);
        if (!cake::insideUnitShape(g_design, uv, 0.82f)) continue;
        if (g_design.toppings.size() >= MAX_TOPPINGS) break;
        placeAt(uv);
        ++placed;
    }
    if (placed == 0) ui::toast("No room left on the surface");
    else {
        char buf[64];
        std::sprintf(buf, "Scattered %d %s", placed, cake::toppingDef(s_selected).name);
        ui::toast(buf);
    }
}

/* -------------------------------------------------------------- events */
static void toppingOnOption(int id) {
    s_selected = id;
    ui::toast(std::string(cake::toppingDef(id).name) + " ready, click the cake to place");
    rebuildStage();
}

static void toppingOnExtra(int id) {
    if      (id == ID_UNDO)    toppingsUndo();
    else if (id == ID_CLEAR)   toppingsClear();
    else if (id == ID_SCATTER) toppingsScatter();
}

static void toppingOnPreviewMouse(float x, float y, int button, int state) {
    cake::Frame f = previewFrame();
    Vec2 uv;
    bool inside = cake::screenToUV(g_design, f, Vec2(x, y), uv);

    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            s_dragging = true;
            if (inside && cake::insideUnitShape(g_design, uv, 0.86f)) placeAt(uv);
            else ui::toast("Click on the frosted top of the cake");
        } else {
            s_dragging = false;
            s_lastPlace = Vec2(-99.0f, -99.0f);
        }
    } else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        int idx = nearestTopping(Vec2(x, y));
        if (idx >= 0) {
            g_design.toppings.erase(g_design.toppings.begin() + idx);
            ui::toast("Ingredient removed");
            rebuildStage();
        } else {
            ui::toast("Right click directly on an ingredient to remove it");
        }
    }
}

static void toppingOnPreviewMotion(float x, float y) {
    cake::Frame f = previewFrame();
    Vec2 uv;
    s_ghostValid = cake::screenToUV(g_design, f, Vec2(x, y), uv) &&
                   cake::insideUnitShape(g_design, uv, 0.86f);
    s_ghostUV    = uv;
    s_hoverIndex = nearestTopping(Vec2(x, y));

    if (s_dragging && s_ghostValid) {
        float gap = 0.20f;
        if (length(uv - s_lastPlace) > gap) placeAt(uv);
    }
}

/* ------------------------------------------------------------ drawing */
static void toppingDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    float y = panelListTop() - (44.0f + 5.0f) * (float)cake::TOP_COUNT - 12.0f;
    ui::drawSectionLabel(x, y, "PLACEMENT");
}

static void toppingDrawPreviewOverlay() {
    cake::Frame f = previewFrame();

    char buf[96];
    std::sprintf(buf, "%d ingredient%s placed", (int)g_design.toppings.size(),
                 g_design.toppings.size() == 1 ? "" : "s");
    textRight(previewCaptionRight(), previewCaptionY(0), buf,
              withAlpha(ui::T.textDim, 0.9f), FONT_XS);
    textRight(previewCaptionRight(), previewCaptionY(1),
              "left click or drag to place, right click to remove",
              withAlpha(ui::T.textFaint, 0.9f), FONT_XS);

    if (s_ghostValid) {
        Vec2 p = cake::uvToScreen(g_design, f, s_ghostUV);
        float r = cake::toppingPixelSize(g_design, f) * 1.5f;
        Color mark = withAlpha(rgb(255, 255, 255), 0.28f);
        line(Vec2(p.x - r, p.y), Vec2(p.x - r * 0.55f, p.y), mark, 1.4f);
        line(Vec2(p.x + r * 0.55f, p.y), Vec2(p.x + r, p.y), mark, 1.4f);
        line(Vec2(p.x, p.y - r), Vec2(p.x, p.y - r * 0.55f), mark, 1.4f);
        line(Vec2(p.x, p.y + r * 0.55f), Vec2(p.x, p.y + r), mark, 1.4f);
    }
}

static bool toppingCanAdvance() { return true; }

/* ------------------------------------------------- state the shell reads */
int  toppingsSelected()    { return s_selected; }
bool toppingsGhostValid()  { return s_ghostValid; }
Vec2 toppingsGhostUV()     { return s_ghostUV; }
int  toppingsHoverIndex()  { return s_hoverIndex; }
void toppingsResetHover()  { s_ghostValid = false; s_hoverIndex = -1; s_dragging = false; }

const StageDef& stageToppings() {
    static StageDef s = {
        "toppings",
        "Decorate the top",
        "Stage 3 of 4",
        "Each ingredient is translated to the point you click, then turned and sized a little.",
        toppingBuild, toppingOnOption, toppingOnExtra, toppingDrawPanelExtra, toppingDrawPreviewOverlay,
        toppingOnPreviewMouse, toppingOnPreviewMotion, toppingCanAdvance
    };
    return s;
}

} /* namespace app */
