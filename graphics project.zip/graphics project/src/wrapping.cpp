/* ============================================================================
 *  CakeLab  -  wrapping.cpp
 *  Stage four: how the finished cake is packaged.
 *
 *  Each style is built from the same primitives as the cake itself, which is
 *  the point of doing this stage last: the shape and colour routines written
 *  for stages one and two are simply called again with different parameters.
 *
 *  Anything that belongs behind the cake is drawn by drawWrapBehind, anything
 *  in front by drawWrapFront, so the packaging correctly surrounds the cake.
 * ==========================================================================*/
#include "cake.h"
#include <algorithm>

namespace cake {

using namespace gfx;

/* ==========================================================================
 *  Measurements taken from the current design
 * ========================================================================*/
struct Metrics {
    float cx;
    float halfW;        /* half width of the bottom tier, in pixels     */
    float halfWTop;     /* half width of the top tier                   */
    float frontY;       /* lowest point of the base outline on screen   */
    float backY;        /* highest point of the base outline on screen  */
    float topY;         /* elevation of the top surface                 */
    float topFrontY;    /* front edge of the top surface                */
    float topBackY;     /* back edge of the top surface                 */
    float height;
};

static Metrics measure(const Design& d, const Frame& f) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 48);

    float maxX = 0.0f, minY = 0.0f, maxY = 0.0f;
    for (size_t i = 0; i < unit.size(); ++i) {
        maxX = std::max(maxX, std::fabs(unit[i].x));
        minY = std::min(minY, unit[i].y);
        maxY = std::max(maxY, unit[i].y);
    }

    float sTop = layerScale(d, d.layers - 1);
    Metrics m;
    m.cx        = f.centre.x;
    m.halfW     = maxX * f.radius;
    m.halfWTop  = maxX * f.radius * sTop;
    m.frontY    = f.centre.y + minY * f.radius * f.squash;
    m.backY     = f.centre.y + maxY * f.radius * f.squash;
    m.topY      = f.centre.y + topElevation(d, f);
    m.topFrontY = m.topY + minY * f.radius * f.squash * sTop;
    m.topBackY  = m.topY + maxY * f.radius * f.squash * sTop;
    m.height    = m.topY - m.frontY;
    return m;
}

/*  Outward normal of edge i of a counter-clockwise unit outline.            */
static Vec2 edgeNormalLocal(const std::vector<Vec2>& unit, size_t i) {
    const Vec2& a = unit[i];
    const Vec2& b = unit[(i + 1) % unit.size()];
    return normalize(Vec2(b.y - a.y, -(b.x - a.x)));
}

/*  A band that hugs the front silhouette of the cake at a chosen height.
 *  Exactly the same extrusion the cake body uses, only much shorter.        */
static void frontBand(const Design& d, const Frame& f, float elevation,
                      float thickness, const Color& c, int layer) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 64);
    float s = layerScale(d, layer);

    size_t n = unit.size();
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormalLocal(unit, i);
        if (nrm.y >= -0.02f) continue;
        size_t j = (i + 1) % n;

        Vec2 a(f.centre.x + unit[i].x * f.radius * s,
               f.centre.y + unit[i].y * f.radius * f.squash * s + elevation);
        Vec2 b(f.centre.x + unit[j].x * f.radius * s,
               f.centre.y + unit[j].y * f.radius * f.squash * s + elevation);

        float k = clampf(0.86f + 0.30f * (-nrm.x * -0.62f), 0.58f, 1.18f);
        glBegin(GL_QUADS);
        useColor(shade(c, k * 1.06f));
        glVertex2f(a.x, a.y);
        glVertex2f(b.x, b.y);
        useColor(shade(c, k * 0.78f));
        glVertex2f(b.x, b.y - thickness);
        glVertex2f(a.x, a.y - thickness);
        glEnd();
    }
}

/*  A short strip laid on the top surface running back from the front rim,
 *  so that a band coming up the front of the cake looks as though it carries
 *  on over the top instead of stopping dead at the edge.                    */
static void topStripNS(const Metrics& m, float halfWidth, float depth, const Color& c) {
    float yBack = lerpf(m.topFrontY, m.topBackY, depth);
    glBegin(GL_QUADS);
    useColor(shade(c, 0.80f));
    glVertex2f(m.cx - halfWidth, yBack);
    glVertex2f(m.cx + halfWidth, yBack);
    useColor(shade(c, 1.08f));
    glVertex2f(m.cx + halfWidth, m.topFrontY);
    glVertex2f(m.cx - halfWidth, m.topFrontY);
    glEnd();
}

/* ==========================================================================
 *  A ribbon bow, reused by three of the four styles
 * ========================================================================*/
static void drawBow(Vec2 c, float size, const Color& col, float time, float phase) {
    Color lite = mix(col, rgb(255, 255, 255), 0.28f);
    Color dark = shade(col, 0.68f);
    float breathe = 1.0f + 0.02f * std::sin(time * 1.8f + phase);

    /* tails first, so the loops sit on top of them */
    for (int s = -1; s <= 1; s += 2) {
        std::vector<Vec2> tail;
        makeBezier(tail,
                   Vec2(c.x, c.y - size * 0.10f),
                   Vec2(c.x + (float)s * size * 0.30f, c.y - size * 0.70f),
                   Vec2(c.x + (float)s * size * 0.28f, c.y - size * 1.10f),
                   Vec2(c.x + (float)s * size * 0.78f, c.y - size * 1.42f), 16);
        for (size_t i = 0; i + 1 < tail.size(); ++i) {
            float t = (float)i / (float)(tail.size() - 1);
            line(tail[i], tail[i + 1], mix(col, dark, t * 0.8f), size * (0.30f - 0.14f * t));
        }
        /* the notched end of a ribbon tail */
        Vec2 e = tail.back();
        fillTri(Vec2(e.x - (float)s * size * 0.16f, e.y + size * 0.12f),
                Vec2(e.x + (float)s * size * 0.14f, e.y + size * 0.02f),
                Vec2(e.x - (float)s * size * 0.02f, e.y - size * 0.16f), dark);
    }

    for (int s = -1; s <= 1; s += 2) {
        pushTransform(Vec2(c.x + (float)s * size * 0.44f, c.y + size * 0.16f),
                      (float)s * 24.0f, breathe, breathe);
        fillEllipse(Vec2(0.0f, 0.0f), size * 0.48f, size * 0.34f, col, 26);
        fillEllipse(Vec2(0.0f, size * 0.06f), size * 0.36f, size * 0.24f, lite, 24);
        fillEllipse(Vec2((float)-s * size * 0.16f, -size * 0.06f),
                    size * 0.20f, size * 0.14f, withAlpha(dark, 0.55f), 20);
        popTransform();
    }

    fillRoundRect(c.x - size * 0.20f, c.y - size * 0.16f,
                  size * 0.40f, size * 0.36f, size * 0.12f, dark);
    fillRoundRect(c.x - size * 0.14f, c.y - size * 0.10f,
                  size * 0.20f, size * 0.24f, size * 0.08f, withAlpha(lite, 0.65f));
}

/* ==========================================================================
 *  Style 1 : rope tie
 * ========================================================================*/
static void ropeBehind(const Design& d, const Frame& f, const Color& c) {
    Metrics m = measure(d, f);
    /* the part of the vertical band that passes over the top and down the
       back of the cake; almost all of it ends up hidden, which is correct  */
    float bw = std::max(9.0f, m.halfW * 0.085f);
    fillRect(m.cx - bw, m.backY - 6.0f, bw * 2.0f,
             m.topY - m.backY + 10.0f, shade(c, 0.50f));
}

static void ropeFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    float bw = std::max(9.0f, m.halfW * 0.085f);

    /*  One band runs round the waist of the cake, following the silhouette
     *  exactly as the cake body does. The other comes up the front and over
     *  the rim. They cross at the front, where the bow is tied.             */
    float elev  = f.layerHeight * 0.58f;
    float thick = std::max(13.0f, f.layerHeight * 0.24f);
    frontBand(d, f, elev, thick, c, 0);
    frontBand(d, f, elev - thick * 0.26f, thick * 0.13f, shade(c, 0.58f), 0);
    if (d.layers > 1)
        frontBand(d, f, f.layerHeight * (float)(d.layers - 1) + f.layerHeight * 0.58f,
                  thick * 0.70f, c, d.layers - 1);

    /* the vertical band, from the plate up to the top rim and a little over */
    float yTop = m.topFrontY;
    float yBot = m.frontY - 4.0f;
    fillRectGradH(m.cx - bw, yBot, bw * 2.0f, yTop - yBot,
                  shade(c, 0.68f), mix(c, rgb(255, 255, 255), 0.22f));
    topStripNS(m, bw, 0.30f, c);

    /*  The twine texture that makes it read as a rope rather than a ribbon. */
    int turns = (int)((yTop - yBot) / (bw * 0.70f));
    for (int i = 0; i <= turns; ++i) {
        float y = yBot + (float)i * bw * 0.70f;
        line(Vec2(m.cx - bw, y), Vec2(m.cx + bw, y + bw * 0.40f),
             withAlpha(shade(c, 0.58f), 0.50f), 1.6f);
    }

    drawBow(Vec2(m.cx, f.centre.y + elev - thick * 0.28f),
            std::max(18.0f, m.halfW * 0.24f), c, time, 0.0f);
}

/* ==========================================================================
 *  Style 2 : gift box with a window
 * ========================================================================*/
static void boxGeometry(const Metrics& m, float& x0, float& x1,
                        float& yBot, float& frontTop, float& backTop) {
    float pad = m.halfW * 0.22f;
    x0       = m.cx - m.halfW - pad;
    x1       = m.cx + m.halfW + pad;
    yBot     = m.frontY - m.height * 0.12f;
    frontTop = yBot + m.height * 0.60f;
    backTop  = yBot + m.height * 0.78f;
}

static void boxBehind(const Design& d, const Frame& f, const Color& c) {
    Metrics m = measure(d, f);
    float x0, x1, yBot, frontTop, backTop;
    boxGeometry(m, x0, x1, yBot, frontTop, backTop);

    /*  The lid, leaning back from the top edge of the rear wall. It is built
     *  as an explicit quad rather than a rotation, so its far corner cannot
     *  swing away from the hinge however wide the box happens to be.        */
    float lidH  = m.height * 0.50f;
    float lean  = 20.0f;
    Vec2  up(std::sin(deg2rad(lean)) * lidH, std::cos(deg2rad(lean)) * lidH);
    Vec2  hingeA(x0 - 4.0f, backTop);
    Vec2  hingeB(x1 + 4.0f, backTop);

    std::vector<Vec2> lid;
    lid.push_back(hingeA);
    lid.push_back(hingeB);
    lid.push_back(hingeB + up);
    lid.push_back(hingeA + up);
    fillPolyGradV(lid, shade(c, 0.52f), shade(c, 0.80f));

    Vec2 ra = hingeA + (hingeB - hingeA) * 0.44f;
    Vec2 rb = hingeA + (hingeB - hingeA) * 0.56f;
    std::vector<Vec2> stripe;
    stripe.push_back(ra);
    stripe.push_back(rb);
    stripe.push_back(rb + up);
    stripe.push_back(ra + up);
    fillPoly(stripe, shade(c, 1.05f));
    polyline(lid, shade(c, 0.40f), 2.0f, true);

    /* rear wall */
    fillRectGradV(x0, yBot, x1 - x0, backTop - yBot, shade(c, 0.40f), shade(c, 0.60f));
    strokeRect(x0, yBot, x1 - x0, backTop - yBot, shade(c, 0.32f), 1.6f);

    /*  Inner side walls, splayed slightly outwards so the box reads as open. */
    float splay = m.halfW * 0.10f;
    for (int s = -1; s <= 1; s += 2) {
        float xin  = (s < 0) ? x0 : x1;
        float xout = xin + (float)s * splay;
        std::vector<Vec2> wall;
        wall.push_back(Vec2(xin,  yBot));
        wall.push_back(Vec2(xout, yBot - m.height * 0.03f));
        wall.push_back(Vec2(xout, frontTop + m.height * 0.10f));
        wall.push_back(Vec2(xin,  backTop));
        fillPolyGradV(wall, shade(c, 0.46f), shade(c, 0.72f));
        polyline(wall, shade(c, 0.34f), 1.4f, true);
    }

    /* a shadow inside the box so the cake sits in something */
    fillRectGradV(x0, yBot, x1 - x0, (backTop - yBot) * 0.5f,
                  withAlpha(rgb(0, 0, 0), 0.40f), withAlpha(rgb(0, 0, 0), 0.0f));
}

static void boxFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    float x0, x1, yBot, frontTop, backTop;
    boxGeometry(m, x0, x1, yBot, frontTop, backTop);
    (void)backTop;

    float bandH = (frontTop - yBot) * 0.20f;      /* solid strip at the base */
    float wx0 = x0 + (x1 - x0) * 0.07f;
    float wx1 = x1 - (x1 - x0) * 0.07f;
    float wy0 = yBot + bandH + (frontTop - yBot) * 0.06f;
    float wy1 = frontTop - (frontTop - yBot) * 0.10f;

    /*  The front wall is drawn as a frame of four rectangles so that the
     *  window in the middle is left clear and the cake shows through.       */
    fillRectGradV(x0, yBot, x1 - x0, wy0 - yBot, shade(c, 0.70f), shade(c, 0.94f));
    fillRectGradV(x0, wy1, x1 - x0, frontTop - wy1, shade(c, 0.96f), shade(c, 1.06f));
    fillRectGradV(x0, wy0, wx0 - x0, wy1 - wy0, shade(c, 0.76f), shade(c, 0.98f));
    fillRectGradV(wx1, wy0, x1 - wx1, wy1 - wy0, shade(c, 0.76f), shade(c, 0.98f));

    /* a suggestion of glass across the opening */
    fillRectGradV(wx0, wy0, wx1 - wx0, wy1 - wy0,
                  withAlpha(rgb(255, 255, 255), 0.03f),
                  withAlpha(rgb(255, 255, 255), 0.10f));
    for (int i = 0; i < 2; ++i) {
        float gx = wx0 + (wx1 - wx0) * (0.12f + 0.26f * (float)i);
        float sl = (wy1 - wy0) * 0.30f;
        std::vector<Vec2> streak;
        streak.push_back(Vec2(gx, wy0));
        streak.push_back(Vec2(gx + sl, wy1));
        streak.push_back(Vec2(gx + sl + 12.0f, wy1));
        streak.push_back(Vec2(gx + 12.0f, wy0));
        fillPoly(streak, withAlpha(rgb(255, 255, 255), 0.06f));
    }
    strokeRect(wx0, wy0, wx1 - wx0, wy1 - wy0, withAlpha(shade(c, 0.48f), 0.95f), 2.2f);

    /* outer edges, then the ribbon band along the base with its bow */
    strokeRect(x0, yBot, x1 - x0, frontTop - yBot, shade(c, 0.42f), 2.0f);
    fillRectGradV(x0, yBot + bandH * 0.16f, x1 - x0, bandH * 0.68f,
                  shade(c, 0.56f), mix(c, rgb(255, 255, 255), 0.30f));
    drawBow(Vec2(m.cx, yBot + bandH * 0.52f), std::max(16.0f, m.halfW * 0.20f),
            mix(c, rgb(255, 255, 255), 0.22f), time, 1.2f);
}

/* ==========================================================================
 *  Style 3 : wrapping sheet
 * ========================================================================*/
static void sheetPetals(const Design& d, const Frame& f, const Color& c,
                        bool behind, float time) {
    Metrics m = measure(d, f);
    Vec2 knot(m.cx, m.frontY - m.height * 0.16f);
    int  n = 9;

    for (int i = 0; i < n; ++i) {
        float t   = (float)i / (float)(n - 1);
        float ang = lerpf(196.0f, -16.0f, t);
        bool isBack = (ang > 40.0f && ang < 140.0f);
        if (isBack != behind) continue;

        float len   = m.height * (1.18f + 0.30f * std::sin(t * PI));
        float spread= 13.0f;
        float wob   = std::sin(time * 0.9f + (float)i) * 1.2f;

        Vec2 tip  = knot + Vec2(std::cos(deg2rad(ang + wob)), std::sin(deg2rad(ang + wob))) * len;
        Vec2 sideA= knot + Vec2(std::cos(deg2rad(ang - spread)), std::sin(deg2rad(ang - spread))) * (len * 0.86f);
        Vec2 sideB= knot + Vec2(std::cos(deg2rad(ang + spread)), std::sin(deg2rad(ang + spread))) * (len * 0.86f);

        Color petal = shade(c, behind ? 0.62f : (0.86f + 0.20f * hash11((float)i * 2.3f)));
        std::vector<Vec2> p;
        p.push_back(knot);
        p.push_back(sideA);
        p.push_back(tip);
        p.push_back(sideB);
        fillPoly(p, petal);
        polyline(p, withAlpha(shade(petal, 0.72f), 0.75f), 1.4f, true);
        line(knot, tip, withAlpha(shade(petal, 1.20f), 0.45f), 2.0f);

        /* polka dots on the visible side of the sheet */
        if (!behind) {
            for (int k = 1; k <= 3; ++k) {
                float u = 0.28f * (float)k;
                Vec2 q = knot + (tip - knot) * u;
                fillCircle(q, m.height * 0.022f,
                           withAlpha(rgb(255, 255, 255), 0.30f), 10);
            }
        }
    }
}

static void sheetFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    sheetPetals(d, f, c, false, time);

    /* the gathered twist at the bottom, plus a tie */
    Vec2 knot(m.cx, m.frontY - m.height * 0.16f);
    float kr = m.halfW * 0.24f;
    fillEllipseGrad(knot, kr, kr * 0.72f, mix(c, rgb(255, 255, 255), 0.20f), shade(c, 0.55f), 28);
    for (int i = 0; i < 5; ++i) {
        float a = deg2rad(lerpf(200.0f, -20.0f, (float)i / 4.0f));
        line(knot, knot + Vec2(std::cos(a), std::sin(a)) * (kr * 0.92f),
             withAlpha(shade(c, 0.62f), 0.6f), 1.6f);
    }
    drawBow(Vec2(knot.x, knot.y + kr * 0.30f), kr * 0.78f, shade(c, 1.12f), time, 2.4f);
}

/* ==========================================================================
 *  Style 4 : waist ribbon and gift tag
 * ========================================================================*/
static void ribbonFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    int   layer = 0;
    float elev  = f.layerHeight * 0.62f;
    float thick = std::max(12.0f, f.layerHeight * 0.30f);

    frontBand(d, f, elev, thick, c, layer);
    frontBand(d, f, elev - thick * 0.30f, thick * 0.14f, shade(c, 0.55f), layer);

    /* if the cake is tiered, tie the upper tier as well */
    if (d.layers > 1)
        frontBand(d, f, f.layerHeight * (float)(d.layers - 1) + f.layerHeight * 0.60f,
                  thick * 0.72f, c, d.layers - 1);

    float bowSize = std::max(18.0f, m.halfW * 0.26f);
    drawBow(Vec2(m.cx, f.centre.y + elev - thick * 0.35f), bowSize, c, time, 0.6f);

    /* a small tag on a string, swinging gently */
    float swing = std::sin(time * 1.4f) * 5.0f;
    Vec2  anchor(m.cx + bowSize * 0.70f, f.centre.y + elev - thick * 0.30f);
    pushTransform(anchor, swing, 1.0f, 1.0f);
    line(Vec2(0.0f, 0.0f), Vec2(bowSize * 0.30f, -bowSize * 0.62f),
         withAlpha(rgb(250, 246, 240), 0.85f), 1.6f);
    pushTransform(Vec2(bowSize * 0.30f, -bowSize * 0.62f), -16.0f, 1.0f, 1.0f);
    fillRoundRect(-bowSize * 0.10f, -bowSize * 0.62f, bowSize * 0.86f, bowSize * 0.62f,
                  bowSize * 0.10f, rgb(252, 248, 238));
    strokeRoundRect(-bowSize * 0.10f, -bowSize * 0.62f, bowSize * 0.86f, bowSize * 0.62f,
                    bowSize * 0.10f, rgb(196, 178, 158), 1.2f);
    fillCircle(Vec2(bowSize * 0.02f, -bowSize * 0.14f), bowSize * 0.055f, rgb(196, 178, 158), 10);
    for (int i = 0; i < 2; ++i)
        fillRect(bowSize * 0.14f, -bowSize * (0.34f + 0.14f * (float)i),
                 bowSize * 0.52f, bowSize * 0.055f, withAlpha(rgb(150, 120, 130), 0.75f));
    popTransform();
    popTransform();
}

/* ==========================================================================
 *  Entry points
 * ========================================================================*/
void drawWrapBehind(const Design& d, const Frame& f, float time) {
    Color c = wrapPaletteColor(d.wrapColor);
    switch (d.wrap) {
        case WRAP_ROPE:  ropeBehind(d, f, c);                 break;
        case WRAP_BOX:   boxBehind(d, f, c);                  break;
        case WRAP_SHEET: sheetPetals(d, f, c, true, time);    break;
        case WRAP_RIBBON:                                     break;
        default: break;
    }
}

void drawWrapFront(const Design& d, const Frame& f, float time) {
    Color c = wrapPaletteColor(d.wrapColor);
    switch (d.wrap) {
        case WRAP_ROPE:   ropeFront(d, f, c, time);   break;
        case WRAP_BOX:    boxFront(d, f, c, time);    break;
        case WRAP_SHEET:  sheetFront(d, f, c, time);  break;
        case WRAP_RIBBON: ribbonFront(d, f, c, time); break;
        default: break;
    }
}

/* ==========================================================================
 *  Small pictograms for the option buttons
 * ========================================================================*/
void drawWrapIcon(int wrapId, Vec2 c, float size, const Color& tint, float time) {
    Color dark = shade(tint, 0.62f);
    switch (wrapId) {
        case WRAP_NONE:
            strokeCircle(c, size * 0.82f, withAlpha(tint, 0.75f), 1.8f, 28);
            line(Vec2(c.x - size * 0.52f, c.y - size * 0.52f),
                 Vec2(c.x + size * 0.52f, c.y + size * 0.52f), withAlpha(tint, 0.75f), 1.8f);
            break;
        case WRAP_ROPE:
            fillRoundRect(c.x - size * 0.78f, c.y - size * 0.66f, size * 1.56f, size * 1.32f,
                          size * 0.16f, shade(tint, 0.86f));
            fillRect(c.x - size * 0.12f, c.y - size * 0.66f, size * 0.24f, size * 1.32f, tint);
            fillRect(c.x - size * 0.78f, c.y - size * 0.12f, size * 1.56f, size * 0.24f, tint);
            fillCircle(c, size * 0.20f, dark, 14);
            break;
        case WRAP_BOX:
            fillRect(c.x - size * 0.80f, c.y - size * 0.72f, size * 1.60f, size * 1.16f, shade(tint, 0.80f));
            fillRect(c.x - size * 0.92f, c.y + size * 0.40f, size * 1.84f, size * 0.32f, tint);
            fillRect(c.x - size * 0.44f, c.y - size * 0.44f, size * 0.88f, size * 0.68f,
                     withAlpha(rgb(255, 255, 255), 0.35f));
            break;
        case WRAP_SHEET: {
            for (int i = 0; i < 5; ++i) {
                float a = deg2rad(lerpf(200.0f, -20.0f, (float)i / 4.0f));
                std::vector<Vec2> p;
                p.push_back(Vec2(c.x, c.y - size * 0.72f));
                p.push_back(Vec2(c.x + std::cos(a - 0.20f) * size * 1.10f,
                                 c.y - size * 0.72f + std::sin(a - 0.20f) * size * 1.10f));
                p.push_back(Vec2(c.x + std::cos(a + 0.20f) * size * 1.10f,
                                 c.y - size * 0.72f + std::sin(a + 0.20f) * size * 1.10f));
                fillPoly(p, shade(tint, 0.70f + 0.12f * (float)(i % 3)));
            }
            fillCircle(Vec2(c.x, c.y - size * 0.72f), size * 0.22f, dark, 14);
            break;
        }
        case WRAP_RIBBON:
            fillRoundRect(c.x - size * 0.86f, c.y - size * 0.30f, size * 1.72f, size * 0.34f,
                          size * 0.10f, shade(tint, 0.80f));
            drawBow(Vec2(c.x, c.y + size * 0.16f), size * 0.62f, tint, time, 0.0f);
            break;
        default: break;
    }
}

} /* namespace cake */
