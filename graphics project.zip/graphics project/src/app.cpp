/* ============================================================================
 *  CakeLab  -  app.cpp
 *  The shell that holds the four stages together: layout, the welcome and
 *  finish screens, the header, the footer, the input routing and the timer
 *  driven animation.
 * ==========================================================================*/
#include "app.h"
#include "screenshot.h"
#include <algorithm>
#include <cstdio>

namespace app {

using namespace gfx;

/* ==========================================================================
 *  State
 * ========================================================================*/
Layout L;
cake::Design            g_design;
std::vector<ui::Button> g_options;
std::vector<ui::Button> g_extras;
float g_time      = 0.0f;
float g_mouseX    = 0.0f;
float g_mouseY    = 0.0f;
int   g_stage     = 0;
int   g_screen    = SCREEN_WELCOME;
int   g_furthest  = 0;
bool  g_algorithmView = false;

static std::vector<ui::Button> g_nav;
static bool  g_help        = false;
static float g_slide       = 0.0f;   /* stage change transition, 1 -> 0     */
static float g_slideDir    = 1.0f;
static float g_finishAnim  = 0.0f;
static cake::Design g_demo;          /* the cake shown on the welcome page  */
static int   g_randomSeed  = 11;

/* nav button identifiers */
enum {
    NAV_BACK = 1, NAV_NEXT, NAV_RESET, NAV_RANDOM, NAV_ALGO, NAV_SHOT, NAV_HELP,
    NAV_START = 20, NAV_DEMO,
    NAV_EDIT = 30, NAV_NEW, NAV_SAVE
};

static const char* kMembers[4] = {
    "Md. Minhaj Rowfun Rabbi Anik",
    "Adiba Howlader",
    "Md. Tanvir Hasan",
    "Abdur Rahman"
};

/* ==========================================================================
 *  Layout
 * ========================================================================*/
void computeLayout(int w, int h) {
    L.W = (float)std::max(w, 900);
    L.H = (float)std::max(h, 620);

    L.headerH = 74.0f;
    L.headerY = L.H - L.headerH - 10.0f;
    L.footerH = 58.0f;
    L.footerY = 10.0f;

    float gap = 14.0f;
    float contentBottom = L.footerY + L.footerH + gap;
    float contentTop    = L.headerY - gap;

    L.panelW = clampf(L.W * 0.29f, 320.0f, 390.0f);
    L.panelX = 14.0f;
    L.panelY = contentBottom;
    L.panelH = contentTop - contentBottom;

    L.previewX = L.panelX + L.panelW + gap;
    L.previewY = contentBottom;
    L.previewW = L.W - L.previewX - 14.0f;
    L.previewH = L.panelH;
}

float panelListTop()    { return L.panelY + L.panelH - 92.0f; }
float panelListBottom() { return L.panelY + 14.0f; }

void layoutRows(std::vector<ui::Button>& list, float rowH, float gap, float topEdge) {
    float y = topEdge;
    for (size_t i = 0; i < list.size(); ++i) {
        list[i].x = L.panelX + 18.0f;
        list[i].w = L.panelW - 36.0f;
        list[i].h = rowH;
        list[i].y = y - rowH;
        y -= (rowH + gap);
    }
}

void layoutChips(std::vector<ui::Button>& list, float x, float y, float chipW,
                 float chipH, float gap, int perRow) {
    for (size_t i = 0; i < list.size(); ++i) {
        int col = (int)i % perRow;
        int row = (int)i / perRow;
        list[i].x = x + (chipW + gap) * (float)col;
        list[i].y = y - (chipH + gap) * (float)row - chipH;
        list[i].w = chipW;
        list[i].h = chipH;
    }
}

/*  Sizes the cake to the space available and then centres it on its own
 *  bounding box, so a one tier cake and a three tier cake both sit nicely.  */
static cake::Frame fitFrame(const cake::Design& d, float cx, float areaY,
                            float areaH, float maxRadius, float anchor) {
    float r  = std::min(maxRadius, areaH * 0.34f);
    float lh = r * (d.layers >= 3 ? 0.36f : (d.layers == 2 ? 0.44f : 0.52f));
    float sTop = cake::layerScale(d, d.layers - 1);

    float topOff = lh * (float)d.layers + r * 0.40f * sTop + r * 0.26f;
    float botOff = -r * 0.46f;
    float cy = areaY + areaH * anchor - (topOff + botOff) * 0.5f;

    return cake::makeFrame(Vec2(cx, cy), r, d.layers);
}

cake::Frame previewFrame() {
    return fitFrame(g_design, L.previewX + L.previewW * 0.5f,
                    L.previewY, L.previewH, L.previewW * 0.30f, 0.56f);
}

float previewCaptionY(int line) { return L.previewY + 39.0f - 17.0f * (float)line; }
float previewCaptionRight()     { return L.previewX + L.previewW - 30.0f; }

cake::Frame heroFrame(float cx, float cy, float radius) {
    return cake::makeFrame(Vec2(cx, cy), radius, g_design.layers);
}

/* ==========================================================================
 *  Stage table
 * ========================================================================*/
const StageDef& currentStage() {
    switch (g_stage) {
        case 0: return stageShape();
        case 1: return stageFlavor();
        case 2: return stageToppings();
        default: return stageWrap();
    }
}

void markDirty() { glutPostRedisplay(); }

void rebuildStage() {
    if (currentStage().build) currentStage().build();
}

/* ==========================================================================
 *  Navigation buttons
 * ========================================================================*/
static ui::Button navButton(int id, const std::string& label, ui::ButtonStyle st,
                            float x, float y, float w, float h) {
    ui::Button b;
    b.id = id; b.label = label; b.style = st;
    b.x = x; b.y = y; b.w = w; b.h = h;
    return b;
}

static void toolIcon(Vec2 c, float size, float time, int arg) {
    switch (arg) {
        case 0:   /* reset: a circular arrow */
            arcStroke(c, size, 30.0f, 310.0f, ui::T.textDim, 2.0f, 22);
            fillTri(Vec2(c.x + size * 0.62f, c.y + size * 0.78f),
                    Vec2(c.x + size * 1.14f, c.y + size * 0.36f),
                    Vec2(c.x + size * 0.52f, c.y + size * 0.10f), ui::T.textDim);
            break;
        case 1:   /* surprise: dice pips */
            strokeRoundRect(c.x - size, c.y - size, size * 2.0f, size * 2.0f,
                            size * 0.32f, ui::T.textDim, 1.8f);
            fillCircle(Vec2(c.x - size * 0.42f, c.y + size * 0.42f), size * 0.18f, ui::T.accent2, 10);
            fillCircle(c, size * 0.18f, ui::T.accent2, 10);
            fillCircle(Vec2(c.x + size * 0.42f, c.y - size * 0.42f), size * 0.18f, ui::T.accent2, 10);
            break;
        case 2: { /* algorithm view: a staircase of pixels */
            Color on = g_algorithmView ? ui::T.ok : ui::T.textDim;
            for (int i = 0; i < 4; ++i)
                fillRect(c.x - size + (float)i * size * 0.5f,
                         c.y - size + (float)i * size * 0.5f,
                         size * 0.42f, size * 0.42f, on);
            break;
        }
        case 3:   /* camera */
            strokeRoundRect(c.x - size * 1.1f, c.y - size * 0.78f, size * 2.2f, size * 1.56f,
                            size * 0.26f, ui::T.textDim, 1.8f);
            strokeCircle(c, size * 0.52f, ui::T.textDim, 1.8f, 20);
            fillRect(c.x - size * 0.30f, c.y + size * 0.72f, size * 0.60f, size * 0.22f, ui::T.textDim);
            break;
        case 4:   /* question mark */
            arcStroke(Vec2(c.x, c.y + size * 0.34f), size * 0.52f, 200.0f, -30.0f,
                      ui::T.textDim, 2.0f, 20);
            line(Vec2(c.x + size * 0.06f, c.y + size * 0.10f),
                 Vec2(c.x + size * 0.06f, c.y - size * 0.34f), ui::T.textDim, 2.0f);
            fillCircle(Vec2(c.x + size * 0.06f, c.y - size * 0.72f), size * 0.16f, ui::T.textDim, 10);
            break;
        default: break;
    }
    (void)time;
}

static void buildNav() {
    g_nav.clear();
    float cy = L.footerY + L.footerH * 0.5f;

    if (g_screen == SCREEN_WELCOME) {
        float bw = 210.0f, bh = 50.0f;
        g_nav.push_back(navButton(NAV_START, "Start designing", ui::BTN_PRIMARY,
                                  L.W * 0.5f - bw - 10.0f, cy - bh * 0.5f, bw, bh));
        g_nav.push_back(navButton(NAV_DEMO, "Surprise me", ui::BTN_GHOST,
                                  L.W * 0.5f + 10.0f, cy - bh * 0.5f, 170.0f, bh));
        return;
    }

    if (g_screen == SCREEN_FINISH) {
        float bh = 48.0f;
        g_nav.push_back(navButton(NAV_EDIT, "Back to editing", ui::BTN_GHOST,
                                  L.W * 0.5f - 300.0f, cy - bh * 0.5f, 190.0f, bh));
        g_nav.push_back(navButton(NAV_SAVE, "Save picture", ui::BTN_PRIMARY,
                                  L.W * 0.5f - 95.0f, cy - bh * 0.5f, 190.0f, bh));
        g_nav.push_back(navButton(NAV_NEW, "Design another", ui::BTN_GHOST,
                                  L.W * 0.5f + 110.0f, cy - bh * 0.5f, 190.0f, bh));
        return;
    }

    /* stage screen */
    float bh = 42.0f;
    g_nav.push_back(navButton(NAV_BACK, "Back", ui::BTN_GHOST, 20.0f, cy - bh * 0.5f, 104.0f, bh));

    float tx = 136.0f;
    const char* tips[5] = { "Reset", "Surprise", "Algorithm view", "Save picture", "Help" };
    int  ids[5] = { NAV_RESET, NAV_RANDOM, NAV_ALGO, NAV_SHOT, NAV_HELP };
    for (int i = 0; i < 5; ++i) {
        ui::Button b = navButton(ids[i], tips[i], ui::BTN_ICON, tx, cy - 19.0f, 38.0f, 38.0f);
        b.icon = toolIcon;
        b.iconArg = i;
        b.selected = (ids[i] == NAV_ALGO) ? g_algorithmView : false;
        g_nav.push_back(b);
        tx += 44.0f;
    }

    float nw = 218.0f, nh = 46.0f;
    bool last = (g_stage == STAGE_COUNT - 1);
    ui::Button nb = navButton(NAV_NEXT, last ? "Finish the cake" : "Next stage",
                              ui::BTN_PRIMARY, L.W - 20.0f - nw, cy - nh * 0.5f, nw, nh);
    nb.enabled = currentStage().canAdvance ? currentStage().canAdvance() : true;
    g_nav.push_back(nb);
}

/* ==========================================================================
 *  Confetti for the finish screen
 * ========================================================================*/
struct Fleck {
    Vec2  p, v;
    Color c;
    float rot, spin, life, size;
};
static std::vector<Fleck> g_confetti;

static void spawnConfetti() {
    g_confetti.clear();
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    Color palette[5] = { ui::T.accent, ui::T.accent2, ui::T.ok, fl.cream, fl.accent };
    for (int i = 0; i < 150; ++i) {
        Fleck f;
        float hx = hash11((float)i * 1.7f);
        float hy = hash11((float)i * 3.1f + 0.5f);
        f.p    = Vec2(hx * L.W, L.H + hy * 320.0f);
        f.v    = Vec2((hash11((float)i * 5.3f) - 0.5f) * 60.0f, -(90.0f + hy * 200.0f));
        f.c    = palette[i % 5];
        f.rot  = hash11((float)i * 7.7f) * 360.0f;
        f.spin = (hash11((float)i * 9.1f) - 0.5f) * 320.0f;
        f.life = 1.0f;
        f.size = 5.0f + hash11((float)i * 11.3f) * 7.0f;
        g_confetti.push_back(f);
    }
}

static void updateConfetti(float dt) {
    for (size_t i = 0; i < g_confetti.size(); ++i) {
        Fleck& f = g_confetti[i];
        f.v.y -= 120.0f * dt;
        f.p    = f.p + f.v * dt;
        f.rot += f.spin * dt;
        if (f.p.y < -30.0f) {
            f.p.y = L.H + 20.0f + hash11(f.p.x * 0.37f) * 120.0f;
            f.v.y = -(90.0f + hash11(f.p.x * 0.11f) * 180.0f);
        }
    }
}

static void drawConfetti() {
    for (size_t i = 0; i < g_confetti.size(); ++i) {
        const Fleck& f = g_confetti[i];
        pushTransform(f.p, f.rot, 1.0f, 1.0f);
        fillRoundRect(-f.size * 0.5f, -f.size * 0.28f, f.size, f.size * 0.56f,
                      f.size * 0.16f, withAlpha(f.c, 0.9f));
        popTransform();
    }
}

/* ==========================================================================
 *  Header and footer
 * ========================================================================*/
static void drawLogo(float x, float y, float scale) {
    /* a miniature cake, drawn with the same primitives as the real one */
    Color body = rgb(255, 196, 212);
    Color top  = rgb(255, 236, 244);
    fillEllipse(Vec2(x + 16.0f * scale, y + 4.0f * scale), 18.0f * scale, 6.0f * scale,
                withAlpha(rgb(0, 0, 0), 0.25f), 24);
    fillRect(x, y + 4.0f * scale, 32.0f * scale, 15.0f * scale, body);
    fillEllipse(Vec2(x + 16.0f * scale, y + 4.0f * scale), 16.0f * scale, 5.0f * scale,
                shade(body, 0.85f), 24);
    fillEllipse(Vec2(x + 16.0f * scale, y + 19.0f * scale), 16.0f * scale, 5.5f * scale, top, 24);
    for (int i = 0; i < 4; ++i)
        fillCircle(Vec2(x + (5.0f + 7.0f * (float)i) * scale, y + 19.0f * scale),
                   3.0f * scale, top, 10);
    float flick = std::sin(g_time * 9.0f) * 3.0f;
    fillRect(x + 14.0f * scale, y + 20.0f * scale, 4.0f * scale, 11.0f * scale, rgb(255, 250, 240));
    pushTransform(Vec2(x + 16.0f * scale, y + 31.0f * scale), flick, 1.0f, 1.0f);
    fillEllipse(Vec2(0.0f, 3.0f * scale), 3.0f * scale, 5.0f * scale, rgb(255, 178, 60), 16);
    fillEllipse(Vec2(0.0f, 2.4f * scale), 1.5f * scale, 3.0f * scale, rgb(255, 240, 170), 14);
    popTransform();
}

static void drawHeader() {
    ui::drawPanel(L.panelX, L.headerY, L.W - L.panelX * 2.0f, L.headerH, 18.0f);

    drawLogo(L.panelX + 22.0f, L.headerY + 18.0f, 1.0f);
    strokeText(L.panelX + 68.0f, L.headerY + 38.0f, "CakeLab", ui::T.text, 27.0f, 2.2f);
    text(L.panelX + 70.0f, L.headerY + 18.0f,
         "CSC 3224 Computer Graphics  -  Group E", ui::T.textFaint, FONT_XS);

    if (g_screen == SCREEN_STAGE) {
        std::vector<std::string> names;
        names.push_back("Shape");
        names.push_back("Flavour");
        names.push_back("Toppings");
        names.push_back("Wrap");
        float sw = std::min(520.0f, L.W * 0.44f);
        ui::drawStepper(L.W - L.panelX - 24.0f - sw, L.headerY + 14.0f, sw, 46.0f,
                        names, g_stage, g_furthest, g_time);
    } else {
        const char* note = (g_screen == SCREEN_WELCOME)
            ? "An interactive 2D cake customisation game"
            : "Your cake is ready";
        textRight(L.W - L.panelX - 24.0f, L.headerY + 30.0f, note, ui::T.textDim, FONT_S);
    }
}

static void drawFooterHints() {
    if (g_screen != SCREEN_STAGE) return;
    float y = L.footerY + L.footerH * 0.5f - 6.0f;
    float x = 372.0f;
    if (x + 300.0f > L.W - 260.0f) return;      /* not enough room, skip */
    text(x, y, currentStage().hint, ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Preview panel
 * ========================================================================*/
static void drawPreviewBackdrop() {
    ui::drawPanelTinted(L.previewX, L.previewY, L.previewW, L.previewH, 18.0f,
                        ui::T.stageOuter, ui::T.panelEdge);
    pushScissor(L.previewX + 2.0f, L.previewY + 2.0f, L.previewW - 4.0f, L.previewH - 4.0f);
    fillEllipseGrad(Vec2(L.previewX + L.previewW * 0.5f, L.previewY + L.previewH * 0.46f),
                    L.previewW * 0.62f, L.previewH * 0.62f,
                    withAlpha(ui::T.stageInner, 0.85f), withAlpha(ui::T.stageInner, 0.0f), 56);
    /* a faint table line so the cake is standing on something */
    float ty = L.previewY + L.previewH * 0.30f;
    fillRectGradV(L.previewX, ty - 90.0f, L.previewW, 90.0f,
                  withAlpha(rgb(0, 0, 0), 0.18f), withAlpha(rgb(0, 0, 0), 0.0f));
    popScissor();
}

/*  A bar along the bottom of the preview: the design on the left, whatever
 *  the current stage wants to say on the right.                            */
static void drawInfoBar() {
    float x = L.previewX + 14.0f;
    float w = L.previewW - 28.0f;
    float h = 46.0f;
    float y = L.previewY + 12.0f;

    fillRoundRect(x, y, w, h, 12.0f, withAlpha(rgb(20, 12, 22), 0.50f));
    strokeRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelEdge, 0.7f), 1.2f);
    text(x + 18.0f, y + h - 19.0f, "CURRENT DESIGN", ui::T.textFaint, FONT_XS);
    text(x + 18.0f, y + 11.0f, cake::describe(g_design), ui::T.text, FONT_S);
}

static void drawStageScreen() {
    /* ---------------------------------------------------------- panel */
    float slideX = g_slide * 26.0f * g_slideDir;
    ui::drawPanel(L.panelX, L.panelY, L.panelW, L.panelH, 18.0f);

    glPushMatrix();
    glTranslatef(-slideX, 0.0f, 0.0f);

    const StageDef& st = currentStage();
    text(L.panelX + 20.0f, L.panelY + L.panelH - 34.0f, st.subtitle, ui::T.accent, FONT_XS);
    text(L.panelX + 20.0f, L.panelY + L.panelH - 62.0f, st.title, ui::T.text, FONT_L);
    ui::drawDivider(L.panelX + 20.0f, L.panelY + L.panelH - 78.0f, L.panelW - 40.0f);

    ui::drawButtons(g_options, g_time);
    if (st.drawPanelExtra) st.drawPanelExtra();
    ui::drawButtons(g_extras, g_time);

    glPopMatrix();

    /* -------------------------------------------------------- preview */
    drawPreviewBackdrop();
    pushScissor(L.previewX + 2.0f, L.previewY + 2.0f, L.previewW - 4.0f, L.previewH - 4.0f);

    cake::Frame f = previewFrame();
    cake::RenderOpts o;
    o.time             = g_time;
    o.highlightSurface = (g_stage == 2);
    o.algorithmView    = g_algorithmView;
    if (g_stage == 2) {
        o.ghostTopping    = toppingsGhostValid() ? toppingsSelected() : -1;
        o.ghostUV         = toppingsGhostUV();
        o.ghostValid      = toppingsGhostValid();
        o.selectedTopping = toppingsHoverIndex();
    }
    cake::drawCake(g_design, f, o);

    drawInfoBar();
    if (st.drawPreviewOverlay) st.drawPreviewOverlay();
    popScissor();
}

/* ==========================================================================
 *  Welcome screen
 * ========================================================================*/
/*  Four small cards summarising which parts of the course the project uses. */
static void drawTechCard(float x, float y, float w, float h,
                         const char* title, const char* body, int glyph) {
    fillRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelHi, 0.45f));
    strokeRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelEdge, 0.85f), 1.1f);

    Vec2 g(x + 28.0f, y + h * 0.5f);
    switch (glyph) {
        case 0:                                  /* rasterised staircase */
            for (int i = 0; i < 4; ++i)
                fillRect(g.x - 13.0f + (float)i * 6.5f, g.y - 13.0f + (float)i * 6.5f,
                         5.5f, 5.5f, ui::T.accent2);
            break;
        case 1:                                  /* three colour channels */
            fillCircle(Vec2(g.x - 7.0f, g.y + 5.0f), 7.0f, withAlpha(rgb(236,  86,  86), 0.9f), 14);
            fillCircle(Vec2(g.x + 4.0f, g.y + 6.0f), 7.0f, withAlpha(rgb( 96, 214, 126), 0.9f), 14);
            fillCircle(Vec2(g.x - 1.0f, g.y - 6.0f), 7.0f, withAlpha(rgb( 96, 156, 236), 0.9f), 14);
            break;
        case 2:                                  /* a square and its copy  */
            strokeRect(g.x - 13.0f, g.y - 13.0f, 15.0f, 15.0f,
                       withAlpha(ui::T.accent, 0.55f), 1.4f);
            pushTransform(Vec2(g.x + 4.0f, g.y + 3.0f), 26.0f, 1.0f, 1.0f);
            strokeRect(-8.0f, -8.0f, 16.0f, 16.0f, ui::T.accent, 1.7f);
            popTransform();
            break;
        default:                                 /* pointer and a key cap  */
            fillTri(Vec2(g.x - 9.0f, g.y + 11.0f), Vec2(g.x - 9.0f, g.y - 8.0f),
                    Vec2(g.x + 3.0f, g.y + 1.0f), ui::T.ok);
            fillRoundRect(g.x + 2.0f, g.y - 12.0f, 13.0f, 10.0f, 2.5f,
                          withAlpha(ui::T.ok, 0.65f));
            break;
    }
    text(x + 54.0f, y + h * 0.5f + 2.0f, title, ui::T.text, FONT_S);
    text(x + 54.0f, y + h * 0.5f - 14.0f, body, ui::T.textFaint, FONT_XS);
}

static void drawWelcome() {
    ui::drawPanel(L.panelX, L.panelY, L.W - L.panelX * 2.0f, L.panelH, 18.0f);

    float leftX = L.panelX + 54.0f;
    float colW  = (L.W - L.panelX * 2.0f) * 0.48f;
    float top   = L.panelY + L.panelH - 62.0f;

    strokeTextCentered(leftX + strokeTextWidth("CakeLab", 62.0f) * 0.5f, top - 44.0f,
                       "CakeLab", ui::T.text, 62.0f, 3.0f);
    text(leftX, top - 74.0f, "An interactive 2D cake customisation game",
         ui::T.accent, FONT_M);

    float y = top - 118.0f;
    y -= ui::drawWrapped(leftX, y, colW - 40.0f,
        "Design a cake in four stages: choose the base shape, pick a flavour and "
        "its colour scheme, decorate the top with ingredients, then wrap it for "
        "delivery. Everything on screen is built from points, lines and polygons "
        "using OpenGL and GLUT.",
        ui::T.textDim, FONT_S);

    y -= 16.0f;
    ui::drawSectionLabel(leftX, y, "GROUP E");
    y -= 22.0f;
    for (int i = 0; i < 4; ++i) {
        fillCircle(Vec2(leftX + 5.0f, y + 5.0f), 3.0f, ui::T.accent, 10);
        text(leftX + 18.0f, y, kMembers[i], ui::T.text, FONT_S);
        y -= 21.0f;
    }
    y -= 10.0f;
    ui::drawSectionLabel(leftX, y, "SUPERVISOR");
    text(leftX, y - 22.0f, "Dr. Mohammad Nazmul Alam", ui::T.text, FONT_S);
    text(leftX, y - 46.0f,
         "Department of Computer Science, Faculty of Science and Technology, AIUB",
         ui::T.textFaint, FONT_XS);

    /* what the project demonstrates, filling the space under the credits */
    float cardH = 48.0f, cardGap = 10.0f;
    float cardW = (colW - 40.0f - cardGap) * 0.5f;
    float row2Y = L.panelY + 24.0f;
    float row1Y = row2Y + cardH + cardGap;
    ui::drawSectionLabel(leftX, row1Y + cardH + 14.0f, "TECHNIQUES DEMONSTRATED");

    struct Tech { const char* t; const char* b; };
    Tech techs[4] = {
        { "Scan conversion", "DDA, Bresenham, midpoint circle" },
        { "Colour models",   "RGB palettes and HSV mixing"     },
        { "Transformations", "translate, rotate, scale"        },
        { "Interaction",     "mouse, keyboard and timer"       }
    };
    for (int i = 0; i < 4; ++i) {
        float x = leftX + (float)(i % 2) * (cardW + cardGap);
        float y = (i < 2) ? row1Y : row2Y;
        drawTechCard(x, y, cardW, cardH, techs[i].t, techs[i].b, i);
    }

    /* the showcase cake on the right, bobbing gently on its plate */
    float cx = L.panelX + (L.W - L.panelX * 2.0f) * 0.74f;
    float r  = std::min(L.panelH * 0.30f, (L.W - L.panelX * 2.0f) * 0.18f);

    cake::Frame f = fitFrame(g_demo, cx, L.panelY, L.panelH, r, 0.52f);
    f.centre.y += std::sin(g_time * 0.9f) * 5.0f;
    cake::RenderOpts o;
    o.time = g_time;
    cake::drawCake(g_demo, f, o);

    for (int i = 0; i < 5; ++i) {
        float a  = g_time * 0.6f + (float)i * 1.257f;
        float rr = f.radius * (1.35f + 0.12f * std::sin(g_time * 1.4f + (float)i));
        Vec2  p(cx + std::cos(a) * rr,
                f.centre.y + f.radius * 0.9f + std::sin(a * 1.3f) * rr * 0.34f);
        ui::drawSparkle(p, 5.0f + 2.5f * std::sin(g_time * 2.0f + (float)i),
                        withAlpha(i % 2 ? ui::T.accent2 : ui::T.accent, 0.75f));
    }
}

/* ==========================================================================
 *  Finish screen
 * ========================================================================*/
static void drawFinish() {
    drawConfetti();

    float panelW = L.W - L.panelX * 2.0f;
    ui::drawPanel(L.panelX, L.panelY, panelW, L.panelH, 18.0f);

    float ease = smoothstep(0.0f, 1.0f, clampf(g_finishAnim, 0.0f, 1.0f));
    cake::Frame f = fitFrame(g_design, L.panelX + panelW * 0.31f,
                             L.panelY, L.panelH, panelW * 0.24f * (0.84f + 0.16f * ease),
                             0.54f);
    f.centre.y += std::sin(g_time * 1.1f) * 4.0f;
    cake::RenderOpts o;
    o.time = g_time;
    o.algorithmView = g_algorithmView;
    cake::drawCake(g_design, f, o);

    /* ------------------------------------------------------- summary */
    float bx = L.panelX + panelW * 0.62f;
    float by = L.panelY + 20.0f;
    float bw = panelW * 0.34f;
    float bh = L.panelH - 40.0f;
    ui::drawPanelTinted(bx, by, bw, bh, 16.0f, ui::T.panelHi, ui::T.panelEdge);

    float y = by + bh - 44.0f;
    text(bx + 24.0f, y, "YOUR CAKE IS READY", ui::T.accent, FONT_XS);
    y -= 34.0f;
    text(bx + 24.0f, y, "Design summary", ui::T.text, FONT_L);
    y -= 20.0f;
    ui::drawDivider(bx + 24.0f, y, bw - 48.0f);
    y -= 30.0f;

    struct Row { const char* k; std::string v; };
    char toppingBuf[64];
    std::sprintf(toppingBuf, "%d piece%s", (int)g_design.toppings.size(),
                 g_design.toppings.size() == 1 ? "" : "s");
    char shapeBuf[64];
    if (g_design.shape == cake::SHAPE_POLYGON)
        std::sprintf(shapeBuf, "%s, %d sides", cake::shapeDef(g_design.shape).name,
                     g_design.polySides);
    else
        std::sprintf(shapeBuf, "%s", cake::shapeDef(g_design.shape).name);
    char tierBuf[32];
    std::sprintf(tierBuf, "%d", g_design.layers);
    std::string wrapStr = cake::wrapDef(g_design.wrap).name;
    if (g_design.wrap != cake::WRAP_NONE)
        wrapStr += std::string(", ") + cake::wrapPaletteName(g_design.wrapColor);

    Row rows[5] = {
        { "Base shape", shapeBuf },
        { "Tiers",      tierBuf },
        { "Flavour",    cake::flavorDef(g_design.flavor).name },
        { "Toppings",   toppingBuf },
        { "Packaging",  wrapStr }
    };
    for (int i = 0; i < 5; ++i) {
        text(bx + 24.0f, y, rows[i].k, ui::T.textFaint, FONT_XS);
        text(bx + 150.0f, y, rows[i].v, ui::T.text, FONT_S);
        y -= 30.0f;
    }

    y -= 6.0f;
    ui::drawDivider(bx + 24.0f, y, bw - 48.0f);
    y -= 26.0f;
    ui::drawSectionLabel(bx + 24.0f, y, "INGREDIENT BREAKDOWN");
    y -= 24.0f;
    int shown = 0;
    for (int i = 0; i < cake::TOP_COUNT; ++i) {
        int n = g_design.countOf(i);
        if (n == 0) continue;
        cake::drawTopping(i, Vec2(bx + 36.0f, y + 5.0f), 11.0f, 0.0f, 2, g_time, 1.0f);
        char line[64];
        std::sprintf(line, "%-10s x %d", cake::toppingDef(i).name, n);
        text(bx + 58.0f, y, line, ui::T.textDim, FONT_XS);
        y -= 22.0f;
        ++shown;
    }
    if (shown == 0)
        text(bx + 36.0f, y, "no ingredients, a plain cake", ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Help overlay
 * ========================================================================*/
static void drawHelp() {
    fillRect(0.0f, 0.0f, L.W, L.H, withAlpha(rgb(12, 6, 14), 0.72f));

    float w = 560.0f, h = 430.0f;
    float x = L.W * 0.5f - w * 0.5f;
    float y = L.H * 0.5f - h * 0.5f;
    ui::drawPanelTinted(x, y, w, h, 18.0f, ui::T.panel, ui::T.accent);

    text(x + 28.0f, y + h - 44.0f, "Controls", ui::T.text, FONT_L);
    text(x + 28.0f, y + h - 66.0f, "everything is also reachable with the mouse",
         ui::T.textFaint, FONT_XS);

    struct KeyRow { const char* key; const char* what; };
    KeyRow rows[13] = {
        { "Enter / N",   "go to the next stage"                   },
        { "Backspace / B","go back one stage"                     },
        { "1 - 8",       "choose an option in the current stage"  },
        { "Left click",  "place the selected ingredient"          },
        { "Drag",        "place a trail of ingredients"           },
        { "Right click", "remove the ingredient under the cursor" },
        { "U",           "undo the last ingredient"               },
        { "C",           "clear all ingredients"                  },
        { "X",           "scatter eight of the selected piece"    },
        { "A",           "toggle the scan conversion view"        },
        { "P",           "save the window as a BMP picture"       },
        { "R",           "reset the whole design"                 },
        { "Z",           "surprise me with a random cake"         }
    };
    float ry = y + h - 100.0f;
    for (int i = 0; i < 13; ++i) {
        ui::drawKeyCap(x + 28.0f, ry - 4.0f, rows[i].key, ui::T.text);
        text(x + 170.0f, ry, rows[i].what, ui::T.textDim, FONT_S);
        ry -= 25.0f;
    }
    textCentered(x + w * 0.5f, y + 18.0f, "press H or Escape to close",
                 ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Lifecycle
 * ========================================================================*/
void init() {
    ui::initTheme();
    g_design.reset();

    /* the cake used on the welcome page */
    g_demo.reset();
    g_demo.shape  = cake::SHAPE_CIRCLE;
    g_demo.layers = 2;
    g_demo.flavor = cake::FLV_STRAWBERRY;
    g_demo.wrap   = cake::WRAP_RIBBON;
    g_demo.wrapColor = 0;
    const float pts[7][2] = {
        { 0.00f,  0.10f }, { -0.46f,  0.30f }, { 0.44f,  0.26f },
        { -0.30f, -0.36f }, { 0.34f, -0.34f }, { -0.62f, -0.06f }, { 0.62f, -0.02f }
    };
    const int types[7] = { cake::TOP_CANDLE, cake::TOP_CHERRY, cake::TOP_BERRY,
                           cake::TOP_GEM, cake::TOP_FRUIT, cake::TOP_CHOCOLATE,
                           cake::TOP_BISCUIT };
    for (int i = 0; i < 7; ++i) {
        cake::Placed p;
        p.type = types[i];
        p.u = pts[i][0];
        p.v = pts[i][1];
        p.variant = i;
        p.rot = (hash11((float)i) - 0.5f) * 20.0f;
        p.scale = (types[i] == cake::TOP_CANDLE) ? 1.45f : 0.95f;
        p.born = -10.0f;
        g_demo.toppings.push_back(p);
    }

    rebuildStage();
    buildNav();
}

void update(float dt) {
    g_time += dt;
    ui::toastUpdate(dt);

    ui::animateButtons(g_options, g_mouseX, g_mouseY, dt);
    ui::animateButtons(g_extras,  g_mouseX, g_mouseY, dt);
    ui::animateButtons(g_nav,     g_mouseX, g_mouseY, dt);

    if (g_slide > 0.0f) g_slide = std::max(0.0f, g_slide - dt * 4.2f);
    if (g_screen == SCREEN_FINISH) {
        g_finishAnim = std::min(1.0f, g_finishAnim + dt * 1.6f);
        updateConfetti(dt);
    }

    /* keep the Next button in step with the stage */
    for (size_t i = 0; i < g_nav.size(); ++i)
        if (g_nav[i].id == NAV_NEXT && currentStage().canAdvance)
            g_nav[i].enabled = currentStage().canAdvance();
}

void draw() {
    ui::drawBackdrop(L.W, L.H, g_time);
    drawHeader();

    switch (g_screen) {
        case SCREEN_WELCOME: drawWelcome();     break;
        case SCREEN_STAGE:   drawStageScreen(); break;
        default:             drawFinish();      break;
    }

    ui::drawButtons(g_nav, g_time);
    drawFooterHints();
    ui::toastDraw(L.W, L.footerY + L.footerH + 16.0f);

    if (g_help) drawHelp();
}

/* ==========================================================================
 *  Navigation
 * ========================================================================*/
void goToStage(int s) {
    if (s < 0) s = 0;
    if (s > STAGE_COUNT - 1) s = STAGE_COUNT - 1;
    g_slideDir = (s >= g_stage) ? 1.0f : -1.0f;
    g_stage    = s;
    g_furthest = std::max(g_furthest, g_stage);
    g_slide    = 1.0f;
    g_screen   = SCREEN_STAGE;
    toppingsResetHover();
    rebuildStage();
    buildNav();
}

void nextStage() {
    if (g_screen == SCREEN_WELCOME) { goToStage(0); return; }
    if (g_screen == SCREEN_FINISH)  return;
    if (g_stage >= STAGE_COUNT - 1) { finish(); return; }
    goToStage(g_stage + 1);
    ui::toast(currentStage().title);
}

void prevStage() {
    if (g_screen == SCREEN_FINISH) { g_screen = SCREEN_STAGE; buildNav(); return; }
    if (g_screen != SCREEN_STAGE)  return;
    if (g_stage == 0) { g_screen = SCREEN_WELCOME; buildNav(); return; }
    goToStage(g_stage - 1);
}

void finish() {
    g_screen     = SCREEN_FINISH;
    g_finishAnim = 0.0f;
    spawnConfetti();
    buildNav();
    ui::toast("Design complete");
}

void resetDesign() {
    g_design.reset();
    g_furthest = 0;
    toppingsResetHover();
    rebuildStage();
    buildNav();
    ui::toast("Design reset");
}

void randomizeDesign() {
    ++g_randomSeed;
    float s = (float)g_randomSeed;
    g_design.reset();
    g_design.shape     = (int)(hash11(s * 1.1f) * (float)cake::SHAPE_COUNT) % cake::SHAPE_COUNT;
    g_design.polySides = 5 + (int)(hash11(s * 2.3f) * 4.0f) % 4;
    g_design.layers    = 1 + (int)(hash11(s * 3.7f) * 3.0f) % 3;
    g_design.flavor    = (int)(hash11(s * 4.9f) * (float)cake::FLV_COUNT) % cake::FLV_COUNT;
    g_design.wrap      = (int)(hash11(s * 6.1f) * (float)cake::WRAP_COUNT) % cake::WRAP_COUNT;
    g_design.wrapColor = (int)(hash11(s * 7.3f) * (float)cake::wrapPaletteSize()) % cake::wrapPaletteSize();

    int want = 6 + (int)(hash11(s * 8.5f) * 10.0f) % 10;
    int guard = 0;
    while ((int)g_design.toppings.size() < want && guard < 600) {
        ++guard;
        float u = hash21(s * 1.3f + (float)guard, 2.7f) * 2.2f - 1.1f;
        float v = hash21(3.9f, s * 2.1f + (float)guard) * 2.2f - 1.1f;
        Vec2 uv(u, v);
        if (!cake::insideUnitShape(g_design, uv, 0.82f)) continue;
        cake::Placed p;
        p.type    = (int)(hash11((float)guard * 5.7f + s) * (float)cake::TOP_COUNT) % cake::TOP_COUNT;
        p.u       = uv.x;
        p.v       = uv.y;
        p.variant = guard;
        p.rot     = (hash11((float)guard * 3.3f) - 0.5f) * 24.0f;
        p.scale   = 0.86f + 0.3f * hash11((float)guard * 4.1f);
        p.born    = g_time;
        if (p.type == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
        g_design.toppings.push_back(p);
    }
    g_furthest = STAGE_COUNT - 1;
    rebuildStage();
    buildNav();
    ui::toast("Random cake generated");
}

void saveScreenshot() {
    std::string name = shot::nextFilename();
    if (shot::saveBMP(name, 0, 0, (int)L.W, (int)L.H))
        ui::toast("Saved " + name);
    else
        ui::toast("Could not write the picture file");
}

/* ==========================================================================
 *  Input
 * ========================================================================*/
void activateOption(int index) {
    if (index < 0 || index >= (int)g_options.size()) return;
    g_options[(size_t)index].pressAnim = 1.0f;
    if (currentStage().onOption) currentStage().onOption(g_options[(size_t)index].id);
    buildNav();
}

static void handleNav(int id) {
    switch (id) {
        case NAV_BACK:   prevStage();       break;
        case NAV_NEXT:   nextStage();       break;
        case NAV_RESET:  resetDesign();     break;
        case NAV_RANDOM: randomizeDesign(); break;
        case NAV_SHOT:   saveScreenshot();  break;
        case NAV_HELP:   g_help = !g_help;  break;
        case NAV_ALGO:
            g_algorithmView = !g_algorithmView;
            ui::toast(g_algorithmView ? "Scan conversion view on"
                                      : "Scan conversion view off");
            buildNav();
            break;
        case NAV_START:  goToStage(0);      break;
        case NAV_DEMO:   randomizeDesign(); goToStage(0); break;
        case NAV_EDIT:   g_screen = SCREEN_STAGE; buildNav(); break;
        case NAV_NEW:    resetDesign(); goToStage(0); break;
        case NAV_SAVE:   saveScreenshot();  break;
        default: break;
    }
}

void onMouse(int button, int state, int mx, int my) {
    g_mouseX = (float)mx;
    g_mouseY = L.H - (float)my;

    if (g_help) {
        if (state == GLUT_DOWN) g_help = false;
        return;
    }

    if (state == GLUT_DOWN && button == GLUT_LEFT_BUTTON) {
        int n = ui::hitIndex(g_nav, g_mouseX, g_mouseY);
        if (n >= 0) {
            g_nav[(size_t)n].pressAnim = 1.0f;
            handleNav(g_nav[(size_t)n].id);
            return;
        }
    }

    if (g_screen != SCREEN_STAGE) return;

    if (state == GLUT_DOWN && button == GLUT_LEFT_BUTTON) {
        int o = ui::hitIndex(g_options, g_mouseX, g_mouseY);
        if (o >= 0) { activateOption(o); return; }

        int e = ui::hitIndex(g_extras, g_mouseX, g_mouseY);
        if (e >= 0) {
            g_extras[(size_t)e].pressAnim = 1.0f;
            if (currentStage().onExtra) currentStage().onExtra(g_extras[(size_t)e].id);
            buildNav();
            return;
        }
    }

    bool inPreview = g_mouseX >= L.previewX && g_mouseX <= L.previewX + L.previewW &&
                     g_mouseY >= L.previewY && g_mouseY <= L.previewY + L.previewH;
    if (inPreview && currentStage().onPreviewMouse)
        currentStage().onPreviewMouse(g_mouseX, g_mouseY, button, state);
}

void onMotion(int mx, int my) {
    g_mouseX = (float)mx;
    g_mouseY = L.H - (float)my;
    if (g_screen == SCREEN_STAGE && currentStage().onPreviewMotion)
        currentStage().onPreviewMotion(g_mouseX, g_mouseY);
}

void onKey(unsigned char key, int mx, int my) {
    (void)mx; (void)my;
    if (key >= 'A' && key <= 'Z') key = (unsigned char)(key - 'A' + 'a');

    if (g_help) {
        if (key == 'h' || key == 27 || key == '?') g_help = false;
        return;
    }

    switch (key) {
        case 13:  nextStage(); return;              /* Enter     */
        case 'n': nextStage(); return;
        case 8:   prevStage(); return;              /* Backspace */
        case 'b': prevStage(); return;
        case 27:  glutLeaveMainLoop(); return;      /* Escape    */
        case 'h': case '?': g_help = true; return;
        case 'r': resetDesign(); return;
        case 'z': randomizeDesign(); return;
        case 'p': saveScreenshot(); return;
        case 'a':
            g_algorithmView = !g_algorithmView;
            ui::toast(g_algorithmView ? "Scan conversion view on"
                                      : "Scan conversion view off");
            buildNav();
            return;
        case 'u': if (g_screen == SCREEN_STAGE) toppingsUndo();    return;
        case 'c': if (g_screen == SCREEN_STAGE) toppingsClear();   return;
        case 'x': if (g_screen == SCREEN_STAGE) toppingsScatter(); return;
        default: break;
    }

    if (key >= '1' && key <= '9' && g_screen == SCREEN_STAGE)
        activateOption((int)(key - '1'));
}

void onSpecial(int key, int mx, int my) {
    (void)mx; (void)my;
    if (g_help) { g_help = false; return; }
    switch (key) {
        case GLUT_KEY_RIGHT: nextStage(); break;
        case GLUT_KEY_LEFT:  prevStage(); break;
        case GLUT_KEY_F1:    g_help = !g_help; break;
        case GLUT_KEY_F2:    saveScreenshot(); break;
        case GLUT_KEY_HOME:  goToStage(0); break;
        case GLUT_KEY_END:   finish(); break;
        default: break;
    }
}

} /* namespace app */
