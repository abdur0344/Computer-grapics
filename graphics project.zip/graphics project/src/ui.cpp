/* ============================================================================
 *  CakeLab  -  ui.cpp
 *  Implementation of the interface furniture described in ui.h.
 * ==========================================================================*/
#include "ui.h"
#include <algorithm>
#include <cstdio>

namespace ui {

using namespace gfx;

Theme T;

void initTheme() {
    T.bgBottom   = rgb( 22, 14, 26);
    T.bgTop      = rgb( 48, 27, 47);
    T.stageInner = rgb( 78, 45, 72);
    T.stageOuter = rgb( 30, 18, 32);
    T.panel      = rgb( 44, 28, 45);
    T.panelEdge  = rgb( 80, 53, 78);
    T.panelHi    = rgb( 60, 39, 60);
    T.text       = rgb(255, 241, 248);
    T.textDim    = rgb(196, 165, 190);
    T.textFaint  = rgb(140, 112, 136);
    T.accent     = rgb(255, 116, 163);
    T.accentDark = rgb(196,  62, 108);
    T.accent2    = rgb(255, 205, 110);
    T.ok         = rgb(126, 222, 170);
    T.danger     = rgb(255, 110, 110);
    T.plate      = rgb(238, 232, 240);
    T.plateEdge  = rgb(190, 180, 196);
}

/* ==========================================================================
 *  Buttons
 * ========================================================================*/
Button::Button()
    : x(0), y(0), w(0), h(0), id(-1), style(BTN_OPTION),
      tint(rgb(255, 255, 255)), icon(0), iconArg(0), enabled(true), selected(false),
      visible(true), hoverAnim(0.0f), pressAnim(0.0f) {}

Button makeButton(float x, float y, float w, float h, int id,
                  const std::string& label, ButtonStyle style) {
    Button b;
    b.x = x; b.y = y; b.w = w; b.h = h;
    b.id = id;
    b.label = label;
    b.style = style;
    return b;
}

bool hitTest(const Button& b, float mx, float my) {
    if (!b.enabled || !b.visible) return false;
    return mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h;
}

int hitIndex(const std::vector<Button>& list, float mx, float my) {
    for (size_t i = 0; i < list.size(); ++i)
        if (hitTest(list[i], mx, my)) return (int)i;
    return -1;
}

void animateButtons(std::vector<Button>& list, float mx, float my, float dt) {
    for (size_t i = 0; i < list.size(); ++i) {
        Button& b = list[i];
        float target = hitTest(b, mx, my) ? 1.0f : 0.0f;
        float rate = 12.0f * dt;
        b.hoverAnim += (target - b.hoverAnim) * clampf(rate, 0.0f, 1.0f);
        b.pressAnim += (0.0f - b.pressAnim) * clampf(9.0f * dt, 0.0f, 1.0f);
    }
}

static void drawSelectionGlow(float x, float y, float w, float h, float r,
                              const Color& c, float strength) {
    if (strength <= 0.01f) return;
    for (int i = 3; i >= 1; --i) {
        float pad = (float)i * 2.4f;
        fillRoundRect(x - pad, y - pad, w + pad * 2.0f, h + pad * 2.0f, r + pad,
                      withAlpha(c, 0.10f * strength));
    }
}

static void drawOptionLike(const Button& b, float time, bool swatch) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = 13.0f;

    float sel = b.selected ? 1.0f : 0.0f;
    Color fill = mix(T.panel, T.panelHi, b.hoverAnim * 0.9f);
    if (b.selected) fill = mix(fill, T.accentDark, 0.55f);
    if (!b.enabled) fill = mix(T.panel, T.bgBottom, 0.5f);

    drawSelectionGlow(x, y, w, h, r, T.accent, sel);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? T.accent : mix(T.panelEdge, T.accent, b.hoverAnim * 0.6f),
                    b.selected ? 2.0f : 1.4f);

    /* left accent bar marks the current choice at a glance */
    if (sel > 0.0f) fillRoundRect(x + 4.0f, y + 8.0f, 4.0f, h - 16.0f, 2.0f, T.accent);

    float iconSlot = h - 14.0f;
    Vec2  iconMid(x + 16.0f + iconSlot * 0.5f, y + h * 0.5f);

    if (swatch) {
        fillRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                      iconSlot, iconSlot, 9.0f, b.tint);
        strokeRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                        iconSlot, iconSlot, 9.0f, withAlpha(rgb(0, 0, 0), 0.25f), 1.2f);
        if (b.icon) b.icon(iconMid, iconSlot * 0.62f, time, b.iconArg);
    } else if (b.icon) {
        fillRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                      iconSlot, iconSlot, 9.0f,
                      withAlpha(b.selected ? T.accent : T.panelHi, b.selected ? 0.22f : 0.85f));
        b.icon(iconMid, iconSlot * 0.60f, time, b.iconArg);
    }

    float textX = x + 16.0f + iconSlot + 14.0f;
    Color titleCol = b.enabled ? (b.selected ? T.text : mix(T.text, T.textDim, 0.25f))
                               : T.textFaint;
    if (b.sub.empty()) {
        text(textX, y + h * 0.5f - 6.0f, b.label, titleCol, FONT_M);
    } else {
        text(textX, y + h * 0.5f + 2.0f, b.label, titleCol, FONT_M);
        text(textX, y + h * 0.5f - 15.0f, b.sub, b.selected ? mix(T.text, T.accent, 0.5f) : T.textFaint, FONT_XS);
    }

    if (b.selected) {
        Vec2 c(x + w - 22.0f, y + h * 0.5f);
        fillCircle(c, 10.0f, T.accent, 20);
        drawCheck(c, 10.0f, rgb(40, 16, 28), 2.6f);
    }
}

static void drawPrimary(const Button& b, float time) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = h * 0.5f;

    Color a = b.enabled ? mix(T.accent, rgb(255, 160, 190), b.hoverAnim * 0.7f)
                        : mix(T.panel, T.panelEdge, 0.4f);
    Color bcol = b.enabled ? mix(T.accentDark, T.accent, b.hoverAnim * 0.7f)
                           : mix(T.panel, T.panelEdge, 0.2f);

    if (b.enabled) {
        float pulse = 0.5f + 0.5f * std::sin(time * 2.4f);
        drawSelectionGlow(x, y, w, h, r, T.accent, 0.55f + 0.45f * pulse);
    }
    fillRoundRectGradV(x, y, w, h, r, bcol, a);
    strokeRoundRect(x, y, w, h, r, withAlpha(rgb(255, 255, 255), b.enabled ? 0.30f : 0.08f), 1.2f);

    Color lc = b.enabled ? rgb(48, 14, 30) : T.textFaint;
    float tw = textWidth(b.label, FONT_M);
    float chev = b.enabled ? 16.0f : 0.0f;
    float startX = x + (w - tw - chev) * 0.5f;
    text(startX, y + h * 0.5f - 6.0f, b.label, lc, FONT_M);
    if (b.enabled)
        drawChevron(Vec2(startX + tw + 11.0f, y + h * 0.5f), 6.0f, 0.0f, lc, 2.6f);
}

static void drawGhost(const Button& b) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = h * 0.5f;

    Color edge = b.enabled ? mix(T.panelEdge, T.accent, b.hoverAnim) : mix(T.panelEdge, T.bgTop, 0.6f);
    fillRoundRect(x, y, w, h, r, withAlpha(T.panelHi, 0.25f + 0.55f * b.hoverAnim));
    strokeRoundRect(x, y, w, h, r, edge, 1.4f);
    Color lc = b.enabled ? mix(T.textDim, T.text, b.hoverAnim) : T.textFaint;
    textCentered(x + w * 0.5f, y + h * 0.5f - 6.0f, b.label, lc, FONT_S);
}

static void drawChip(const Button& b, float time) {
    float x = b.x, y = b.y, w = b.w, h = b.h, r = h * 0.5f;
    Color fill = b.selected ? T.accent : mix(T.panel, T.panelHi, 0.4f + 0.6f * b.hoverAnim);
    if (b.tint.a > 0.0f && b.style == BTN_CHIP && b.icon == 0 && b.label.empty()) fill = b.tint;

    if (b.selected) drawSelectionGlow(x, y, w, h, r, T.accent, 1.0f);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? rgb(255, 255, 255) : mix(T.panelEdge, T.accent, b.hoverAnim),
                    b.selected ? 2.0f : 1.2f);
    /*  Icon and label share the pill: icon on the left, label in what is
     *  left over. Either one on its own is centred.                        */
    bool hasIcon  = (b.icon != 0);
    bool hasLabel = !b.label.empty();
    Color lc = b.selected ? rgb(48, 14, 30) : mix(T.textDim, T.text, b.hoverAnim);

    if (hasIcon && hasLabel) {
        b.icon(Vec2(x + h * 0.60f, y + h * 0.5f), h * 0.28f, time, b.iconArg);
        float textLeft = x + h * 1.06f;
        textCentered(textLeft + (x + w - 8.0f - textLeft) * 0.5f,
                     y + h * 0.5f - 5.0f, b.label, lc, FONT_XS);
    } else if (hasIcon) {
        b.icon(Vec2(x + w * 0.5f, y + h * 0.5f), h * 0.34f, time, b.iconArg);
    } else if (hasLabel) {
        textCentered(x + w * 0.5f, y + h * 0.5f - 5.0f, b.label, lc, FONT_S);
    }
}

static void drawIconButton(const Button& b, float time) {
    float x = b.x, y = b.y, w = b.w, h = b.h, r = 11.0f;
    Color fill = mix(T.panel, T.panelHi, 0.35f + 0.65f * b.hoverAnim);
    if (b.selected) fill = mix(fill, T.accentDark, 0.6f);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? T.accent : mix(T.panelEdge, T.accent, b.hoverAnim), 1.3f);
    if (b.icon) b.icon(Vec2(x + w * 0.5f, y + h * 0.5f), std::min(w, h) * 0.32f, time, b.iconArg);
    else        textCentered(x + w * 0.5f, y + h * 0.5f - 5.0f, b.label, T.textDim, FONT_S);
}

void drawButton(const Button& b, float time) {
    if (!b.visible) return;
    switch (b.style) {
        case BTN_OPTION:  drawOptionLike(b, time, false); break;
        case BTN_SWATCH:  drawOptionLike(b, time, true);  break;
        case BTN_PRIMARY: drawPrimary(b, time);           break;
        case BTN_GHOST:   drawGhost(b);                   break;
        case BTN_CHIP:    drawChip(b, time);              break;
        case BTN_ICON:    drawIconButton(b, time);        break;
    }
}

void drawButtons(const std::vector<Button>& list, float time) {
    for (size_t i = 0; i < list.size(); ++i) drawButton(list[i], time);
}

/* ==========================================================================
 *  Panels and backdrop
 * ========================================================================*/
void drawBackdrop(float w, float h, float time) {
    fillRectGradV(0.0f, 0.0f, w, h, T.bgBottom, T.bgTop);

    /* Two very soft drifting blobs stop the flat background looking dead. */
    for (int i = 0; i < 2; ++i) {
        float ph = time * 0.13f + (float)i * 2.1f;
        float cx = w * (0.30f + 0.42f * (float)i) + std::cos(ph) * 70.0f;
        float cy = h * (0.62f - 0.22f * (float)i) + std::sin(ph * 1.3f) * 45.0f;
        Color glow = (i == 0) ? withAlpha(T.accent, 0.055f) : withAlpha(T.accent2, 0.045f);
        fillCircleGrad(Vec2(cx, cy), 300.0f, glow, withAlpha(glow, 0.0f), 48);
    }
}

void drawPanel(float x, float y, float w, float h, float radius) {
    drawPanelTinted(x, y, w, h, radius, T.panel, T.panelEdge);
}

void drawPanelTinted(float x, float y, float w, float h, float radius,
                     const Color& fill, const Color& edge) {
    fillRoundRect(x + 2.0f, y - 3.0f, w, h, radius, withAlpha(rgb(0, 0, 0), 0.28f));
    fillRoundRectGradV(x, y, w, h, radius, shade(fill, 0.86f), shade(fill, 1.06f));
    strokeRoundRect(x, y, w, h, radius, edge, 1.3f);
}

void drawSectionLabel(float x, float y, const std::string& s) {
    text(x, y, s, T.textFaint, FONT_XS);
}

void drawDivider(float x, float y, float w) {
    fillRect(x, y, w, 1.0f, withAlpha(T.panelEdge, 0.7f));
}

/* ==========================================================================
 *  Stage stepper
 * ========================================================================*/
void drawStepper(float x, float y, float w, float h,
                 const std::vector<std::string>& names, int current,
                 int furthestReached, float time) {
    int n = (int)names.size();
    if (n <= 0) return;

    float nodeR   = 12.0f;
    float nodeY   = y + h - nodeR - 2.0f;
    float slot    = w / (float)n;
    float firstX  = x + slot * 0.5f;

    /* connector track */
    fillRoundRect(firstX, nodeY - 1.5f, slot * (float)(n - 1), 3.0f, 1.5f,
                  withAlpha(T.panelEdge, 0.9f));
    float doneFrac = (float)current / (float)(n - 1 > 0 ? n - 1 : 1);
    fillRoundRect(firstX, nodeY - 1.5f, slot * (float)(n - 1) * doneFrac, 3.0f, 1.5f, T.accent);

    for (int i = 0; i < n; ++i) {
        float cx = firstX + slot * (float)i;
        bool done    = i < current;
        bool active  = i == current;
        bool reached = i <= furthestReached;

        Color fill = active ? T.accent : (done ? T.accentDark : mix(T.panel, T.panelEdge, 0.5f));
        if (active) {
            float pulse = 0.5f + 0.5f * std::sin(time * 3.0f);
            fillCircle(Vec2(cx, nodeY), nodeR + 4.0f + pulse * 2.0f, withAlpha(T.accent, 0.18f), 24);
        }
        fillCircle(Vec2(cx, nodeY), nodeR, fill, 26);
        strokeCircle(Vec2(cx, nodeY), nodeR, withAlpha(rgb(255, 255, 255), active ? 0.55f : 0.18f), 1.3f, 26);

        if (done) {
            drawCheck(Vec2(cx, nodeY), nodeR * 0.95f, rgb(255, 255, 255), 2.2f);
        } else {
            char num[8];
            std::sprintf(num, "%d", i + 1);
            textCentered(cx, nodeY - 4.0f, num,
                         active ? rgb(48, 14, 30) : (reached ? T.textDim : T.textFaint), FONT_S);
        }

        Color lc = active ? T.text : (reached ? T.textDim : T.textFaint);
        textCentered(cx, y + 1.0f, names[(size_t)i], lc, FONT_XS);
    }
}

/* ==========================================================================
 *  Small decorations
 * ========================================================================*/
void drawCheck(Vec2 centre, float size, const Color& c, float weight) {
    Vec2 a(centre.x - size * 0.42f, centre.y + size * 0.04f);
    Vec2 b(centre.x - size * 0.10f, centre.y - size * 0.32f);
    Vec2 d(centre.x + size * 0.44f, centre.y + size * 0.36f);
    line(a, b, c, weight);
    line(b, d, c, weight);
    fillCircle(b, weight * 0.5f, c, 8);
}

void drawChevron(Vec2 centre, float size, float dirDeg, const Color& c, float weight) {
    Vec2 a = rotated(Vec2(-size * 0.5f,  size), dirDeg);
    Vec2 b = rotated(Vec2( size * 0.5f,  0.0f), dirDeg);
    Vec2 d = rotated(Vec2(-size * 0.5f, -size), dirDeg);
    line(centre + a, centre + b, c, weight);
    line(centre + b, centre + d, c, weight);
}

void drawSparkle(Vec2 centre, float size, const Color& c) {
    fillStar(centre, size, size * 0.28f, 4, 0.0f, c);
    fillCircle(centre, size * 0.16f, withAlpha(rgb(255, 255, 255), c.a), 10);
}

void drawKeyCap(float x, float y, const std::string& key, const Color& c) {
    float w = std::max(22.0f, textWidth(key, FONT_XS) + 14.0f);
    float h = 19.0f;
    fillRoundRect(x, y, w, h, 5.0f, withAlpha(T.panelHi, 0.9f));
    strokeRoundRect(x, y, w, h, 5.0f, T.panelEdge, 1.1f);
    textCentered(x + w * 0.5f, y + 6.0f, key, c, FONT_XS);
}

/* ==========================================================================
 *  Toasts
 * ========================================================================*/
struct Toast {
    std::string msg;
    float life;
};
static std::vector<Toast> g_toasts;

void toast(const std::string& msg) {
    if (!g_toasts.empty() && g_toasts.back().msg == msg && g_toasts.back().life > 1.6f) {
        g_toasts.back().life = 2.4f;
        return;
    }
    Toast t;
    t.msg = msg;
    t.life = 2.4f;
    g_toasts.push_back(t);
    if (g_toasts.size() > 3) g_toasts.erase(g_toasts.begin());
}

void toastUpdate(float dt) {
    for (size_t i = 0; i < g_toasts.size(); ++i) g_toasts[i].life -= dt;
    while (!g_toasts.empty() && g_toasts.front().life <= 0.0f)
        g_toasts.erase(g_toasts.begin());
}

void toastDraw(float screenW, float baseY) {
    for (size_t i = 0; i < g_toasts.size(); ++i) {
        const Toast& t = g_toasts[i];
        float fade = clampf(t.life / 0.45f, 0.0f, 1.0f) *
                     clampf((2.4f - t.life) / 0.18f, 0.0f, 1.0f);
        float w = textWidth(t.msg, FONT_S) + 34.0f;
        float h = 32.0f;
        float x = screenW * 0.5f - w * 0.5f;
        float y = baseY + (float)(g_toasts.size() - 1 - i) * (h + 8.0f) + (1.0f - fade) * -8.0f;

        fillRoundRect(x, y, w, h, h * 0.5f, withAlpha(rgb(24, 14, 26), 0.94f * fade));
        strokeRoundRect(x, y, w, h, h * 0.5f, withAlpha(T.accent, 0.65f * fade), 1.3f);
        fillCircle(Vec2(x + 16.0f, y + h * 0.5f), 4.0f, withAlpha(T.accent, fade), 12);
        text(x + 27.0f, y + h * 0.5f - 4.0f, t.msg, withAlpha(T.text, fade), FONT_S);
    }
}

/* ==========================================================================
 *  Wrapped text
 * ========================================================================*/
float drawWrapped(float x, float y, float maxWidth, const std::string& s,
                  const Color& c, FontId f, float lineGap) {
    std::string word, lineBuf;
    float lineH = textHeight(f) + lineGap;
    float cursorY = y;

    size_t i = 0;
    while (i <= s.size()) {
        char ch = (i < s.size()) ? s[i] : ' ';
        if (ch == ' ' || ch == '\n' || i == s.size()) {
            std::string candidate = lineBuf.empty() ? word : lineBuf + " " + word;
            if (textWidth(candidate, f) > maxWidth && !lineBuf.empty()) {
                text(x, cursorY, lineBuf, c, f);
                cursorY -= lineH;
                lineBuf = word;
            } else {
                lineBuf = candidate;
            }
            word.clear();
            if (ch == '\n') {
                text(x, cursorY, lineBuf, c, f);
                cursorY -= lineH;
                lineBuf.clear();
            }
        } else {
            word.push_back(ch);
        }
        ++i;
    }
    if (!lineBuf.empty()) {
        text(x, cursorY, lineBuf, c, f);
        cursorY -= lineH;
    }
    return y - cursorY;   /* total height consumed */
}

} /* namespace ui */
