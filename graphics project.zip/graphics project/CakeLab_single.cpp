


#include <GL/freeglut.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

/* ===== gfx.h ========================================================= */
/* ============================================================================
 *  CakeLab  -  gfx.h
 *  Course     : CSC 3224, Computer Graphics
 *  Purpose    : Reusable 2D drawing toolkit built on OpenGL / freeGLUT.
 *
 *  Everything CakeLab draws goes through this file. It provides three things:
 *
 *    1. Scan conversion  - DDA line, Bresenham midpoint line, midpoint circle
 *                          and midpoint ellipse. These rasterise into GL_POINTS
 *                          one pixel at a time, exactly as taught in class,
 *                          instead of relying on GL_LINES.
 *    2. Composite shapes - filled circles, ellipses, polygons, rounded rects,
 *                          arcs, stars and capsules, all generated from a
 *                          parametric point loop (no built-in circle call).
 *    3. Colour and text  - RGB / HSV colour model helpers and GLUT font output.
 *
 *  Coordinate system: origin at the bottom-left of the window, y increasing
 *  upwards, one unit == one pixel (set up by begin2D).
 * ==========================================================================*/
#ifndef CAKELAB_GFX_H
#define CAKELAB_GFX_H


namespace gfx {

const float PI = 3.14159265358979323846f;

/* ---------------------------------------------------------------- vectors */
struct Vec2 {
    float x, y;
    Vec2() : x(0.0f), y(0.0f) {}
    Vec2(float ax, float ay) : x(ax), y(ay) {}
};

inline Vec2 operator+(const Vec2& a, const Vec2& b) { return Vec2(a.x + b.x, a.y + b.y); }
inline Vec2 operator-(const Vec2& a, const Vec2& b) { return Vec2(a.x - b.x, a.y - b.y); }
inline Vec2 operator*(const Vec2& a, float s)       { return Vec2(a.x * s, a.y * s); }
inline Vec2 operator*(float s, const Vec2& a)       { return Vec2(a.x * s, a.y * s); }
inline float dot(const Vec2& a, const Vec2& b)      { return a.x * b.x + a.y * b.y; }
inline float length(const Vec2& a)                  { return std::sqrt(a.x * a.x + a.y * a.y); }
Vec2  normalize(const Vec2& a);
Vec2  perp(const Vec2& a);                 /* rotate 90 degrees counter-clockwise */
Vec2  rotated(const Vec2& a, float deg);   /* rotation about the origin          */

/* ----------------------------------------------------------------- colour */
/*  The RGB colour model from the Image Representation chapter. Components are
 *  kept in the 0..1 range that OpenGL expects; rgb() converts from the 0..255
 *  byte form that is easier to read when picking a palette.                  */
struct Color {
    float r, g, b, a;
    Color() : r(0.0f), g(0.0f), b(0.0f), a(1.0f) {}
    Color(float R, float G, float B, float A = 1.0f) : r(R), g(G), b(B), a(A) {}
};

Color rgb(int r, int g, int b);
Color rgba(int r, int g, int b, float a);
Color mix(const Color& a, const Color& b, float t);   /* linear interpolation   */
Color shade(const Color& c, float factor);            /* darken / lighten       */
Color withAlpha(const Color& c, float a);
Color hsv(float h, float s, float v, float a = 1.0f); /* HSV -> RGB conversion  */
void  useColor(const Color& c);

/* -------------------------------------------------------- scan conversion */
/*  Each of these walks the shape one pixel at a time and emits a GL_POINTS
 *  vertex, which is what the rasteriser in the course notes does. They are
 *  slower than the GL primitives but they are the honest implementation, and
 *  the application can switch to them at run time (the "algorithm view").    */
void lineDDA(Vec2 a, Vec2 b, const Color& c, float pointSize = 1.0f);
void lineBresenham(Vec2 a, Vec2 b, const Color& c, float pointSize = 1.0f);
void circleMidpoint(Vec2 centre, float r, const Color& c, float pointSize = 1.0f);
void ellipseMidpoint(Vec2 centre, float rx, float ry, const Color& c, float pointSize = 1.0f);
void circleParametric(Vec2 centre, float r, const Color& c, int steps = 180, float pointSize = 1.0f);
void polylineBresenham(const std::vector<Vec2>& pts, const Color& c, bool closed, float pointSize = 1.0f);

/* ------------------------------------------------------ outline generators */
/*  A circle is built from a parametric point loop, never from a library call.
 *  Every other rounded shape in CakeLab reuses this loop.                    */
void makeCircle(std::vector<Vec2>& out, Vec2 centre, float r, int steps = 64);
void makeEllipse(std::vector<Vec2>& out, Vec2 centre, float rx, float ry, int steps = 64);
void makeRegularPolygon(std::vector<Vec2>& out, Vec2 centre, float r, int sides, float rotDeg = 0.0f);
void makeRoundRect(std::vector<Vec2>& out, float x, float y, float w, float h, float r, int cornerSteps = 6);
void makeStar(std::vector<Vec2>& out, Vec2 centre, float rOuter, float rInner, int points, float rotDeg = 0.0f);
void makeBezier(std::vector<Vec2>& out, Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, int steps = 24);

/* ------------------------------------------------------------ filled work */
void line(Vec2 a, Vec2 b, const Color& c, float width = 1.0f);
void polyline(const std::vector<Vec2>& pts, const Color& c, float width = 1.0f, bool closed = false);
void fillPoly(const std::vector<Vec2>& pts, const Color& c);
void fillPolyGrad(const std::vector<Vec2>& pts, Vec2 centre, const Color& inner, const Color& outer);
void fillPolyGradV(const std::vector<Vec2>& pts, const Color& bottom, const Color& top);
void strokePoly(const std::vector<Vec2>& pts, const Color& c, float width = 1.0f);

void fillCircle(Vec2 centre, float r, const Color& c, int steps = 48);
void fillCircleGrad(Vec2 centre, float r, const Color& inner, const Color& outer, int steps = 48);
void fillEllipse(Vec2 centre, float rx, float ry, const Color& c, int steps = 48);
void fillEllipseGrad(Vec2 centre, float rx, float ry, const Color& inner, const Color& outer, int steps = 48);
void strokeCircle(Vec2 centre, float r, const Color& c, float width = 1.0f, int steps = 48);
void ring(Vec2 centre, float rInner, float rOuter, const Color& c, int steps = 48);
void fillArc(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, int steps = 32);
void arcStroke(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, float width = 1.0f, int steps = 32);

void fillRect(float x, float y, float w, float h, const Color& c);
void fillRectGradV(float x, float y, float w, float h, const Color& bottom, const Color& top);
void fillRectGradH(float x, float y, float w, float h, const Color& left, const Color& right);
void strokeRect(float x, float y, float w, float h, const Color& c, float width = 1.0f);
void fillRoundRect(float x, float y, float w, float h, float r, const Color& c);
void fillRoundRectGradV(float x, float y, float w, float h, float r, const Color& bottom, const Color& top);
void strokeRoundRect(float x, float y, float w, float h, float r, const Color& c, float width = 1.0f);

void fillTri(Vec2 a, Vec2 b, Vec2 c, const Color& col);
void fillRegularPolygon(Vec2 centre, float r, int sides, float rotDeg, const Color& c);
void fillStar(Vec2 centre, float rOuter, float rInner, int points, float rotDeg, const Color& c);
void fillCapsule(Vec2 a, Vec2 b, float r, const Color& c);
void softShadow(Vec2 centre, float rx, float ry, float alpha, int steps = 40);

/* ------------------------------------------------------------------- text */
enum FontId { FONT_XS, FONT_S, FONT_M, FONT_L };

float textWidth(const std::string& s, FontId f);
float textHeight(FontId f);
void  text(float x, float y, const std::string& s, const Color& c, FontId f = FONT_M);
void  textCentered(float cx, float y, const std::string& s, const Color& c, FontId f = FONT_M);
void  textRight(float rx, float y, const std::string& s, const Color& c, FontId f = FONT_M);

/*  Stroke fonts are real geometry, so they scale and rotate with the matrix
 *  stack. CakeLab uses them for headings.                                    */
float strokeTextWidth(const std::string& s, float size);
void  strokeText(float x, float y, const std::string& s, const Color& c, float size, float weight = 1.5f);
void  strokeTextCentered(float cx, float y, const std::string& s, const Color& c, float size, float weight = 1.5f);

/* ------------------------------------------------- transforms and clipping */
/*  Geometric transformation, applied through the OpenGL matrix stack:
 *  translate to place an object, rotate to orient it, scale to size it.      */
void pushTransform(Vec2 translate, float rotDeg = 0.0f, float scaleX = 1.0f, float scaleY = 1.0f);
void popTransform();
void pushScissor(float x, float y, float w, float h);
void popScissor();

/* ----------------------------------------------------------- setup / math */
void  begin2D(int w, int h);
void  enableBlend();

float clampf(float v, float lo, float hi);
float lerpf(float a, float b, float t);
float smoothstep(float edge0, float edge1, float x);
float deg2rad(float d);
float rad2deg(float r);
bool  pointInPoly(const std::vector<Vec2>& poly, Vec2 p);

/*  Deterministic pseudo-random helpers. A cake must look identical from one
 *  frame to the next, so std::rand is never used inside a draw call.         */
float hash11(float x);
float hash21(float x, float y);
float valueNoise(float x);

} /* namespace gfx */

#endif /* CAKELAB_GFX_H */

/* ===== ui.h ========================================================== */
/* ============================================================================
 *  CakeLab  -  ui.h
 *  The interface furniture: colour theme, clickable buttons, panels, the stage
 *  stepper and the toast messages.
 *
 *  A button is nothing more than a rectangle with a label and an identifier.
 *  Hit testing compares the mouse position from glutMouseFunc against that
 *  rectangle, which is the "clickable region" approach used in the moving
 *  object exercises earlier in the course.
 * ==========================================================================*/
#ifndef CAKELAB_UI_H
#define CAKELAB_UI_H


namespace ui {

using gfx::Color;
using gfx::Vec2;

/* ------------------------------------------------------------------ theme */
struct Theme {
    Color bgBottom, bgTop;          /* window backdrop gradient          */
    Color stageInner, stageOuter;   /* preview area vignette             */
    Color panel, panelEdge, panelHi;
    Color text, textDim, textFaint;
    Color accent, accentDark, accent2;
    Color ok, danger;
    Color plate, plateEdge;
};
extern Theme T;
void initTheme();

/* ------------------------------------------------------------------ icons */
/*  A button may draw a small pictogram in its icon slot. The stage modules
 *  supply the function, so ui.cpp never needs to know what a cherry is.     */
typedef void (*IconFn)(Vec2 centre, float size, float time, int arg);

/* ---------------------------------------------------------------- buttons */
enum ButtonStyle {
    BTN_OPTION,    /* tall list row with icon, title and subtitle */
    BTN_SWATCH,    /* list row whose icon slot is a colour chip   */
    BTN_PRIMARY,   /* filled call-to-action                       */
    BTN_GHOST,     /* outlined secondary action                   */
    BTN_CHIP,      /* small pill                                  */
    BTN_ICON       /* square icon-only button                     */
};

struct Button {
    float x, y, w, h;
    int   id;
    std::string label;
    std::string sub;
    ButtonStyle style;
    Color  tint;
    IconFn icon;
    int    iconArg;
    bool   enabled;
    bool   selected;
    bool   visible;
    float  hoverAnim;   /* 0..1, eased towards the hover state each frame */
    float  pressAnim;   /* 0..1, decays after a click                     */

    Button();
};

Button makeButton(float x, float y, float w, float h, int id,
                  const std::string& label, ButtonStyle style = BTN_OPTION);

bool hitTest(const Button& b, float mx, float my);
int  hitIndex(const std::vector<Button>& list, float mx, float my);
void animateButtons(std::vector<Button>& list, float mx, float my, float dt);
void drawButton(const Button& b, float time);
void drawButtons(const std::vector<Button>& list, float time);

/* ----------------------------------------------------------------- panels */
void drawBackdrop(float w, float h, float time);
void drawPanel(float x, float y, float w, float h, float radius = 16.0f);
void drawPanelTinted(float x, float y, float w, float h, float radius,
                     const Color& fill, const Color& edge);
void drawSectionLabel(float x, float y, const std::string& s);
void drawDivider(float x, float y, float w);

/* ---------------------------------------------------------------- stepper */
void drawStepper(float x, float y, float w, float h,
                 const std::vector<std::string>& names, int current,
                 int furthestReached, float time);

/* ------------------------------------------------------------- decoration */
void drawCheck(Vec2 centre, float size, const Color& c, float weight = 2.5f);
void drawChevron(Vec2 centre, float size, float dirDeg, const Color& c, float weight = 2.5f);
void drawSparkle(Vec2 centre, float size, const Color& c);
void drawKeyCap(float x, float y, const std::string& key, const Color& c);

/* ----------------------------------------------------------------- toasts */
void toast(const std::string& msg);
void toastUpdate(float dt);
void toastDraw(float screenW, float baseY);

/* ------------------------------------------------------------ text layout */
/*  Wraps a paragraph to a pixel width and draws it downwards from y.        */
float drawWrapped(float x, float y, float maxWidth, const std::string& s,
                  const Color& c, gfx::FontId f, float lineGap = 5.0f);

} /* namespace ui */

#endif /* CAKELAB_UI_H */

/* ===== cake.h ======================================================== */
/* ============================================================================
 *  CakeLab  -  cake.h
 *  The design the user is building, and the renderer that turns it into a
 *  picture.
 *
 *  A cake is described entirely by data: a base shape, a flavour, a list of
 *  toppings and a wrapping style. Nothing about the drawing is stored, so the
 *  same Design can be redrawn at any size, in the preview panel or on the
 *  finish screen.
 *
 *  The renderer builds a shallow pseudo-3D look out of flat 2D primitives:
 *    - the base shape is generated as an outline in unit coordinates,
 *    - that outline is squashed vertically to suggest a surface seen from
 *      slightly above,
 *    - edges whose outward normal points towards the viewer are extruded
 *      downwards into the side of the cake,
 *    - frosting, drips and toppings are layered on top.
 * ==========================================================================*/
#ifndef CAKELAB_CAKE_H
#define CAKELAB_CAKE_H


namespace cake {

using gfx::Vec2;
using gfx::Color;

/* ------------------------------------------------------------ catalogues */
enum ShapeType {
    SHAPE_CIRCLE = 0, SHAPE_SQUARE, SHAPE_TRIANGLE, SHAPE_RECT, SHAPE_POLYGON,
    SHAPE_COUNT
};

enum FlavorId {
    FLV_STRAWBERRY = 0, FLV_GREEN, FLV_BLACKFOREST, FLV_REDVELVET,
    FLV_MANGO, FLV_CHOCOLATE, FLV_VANILLA, FLV_BUTTERSCOTCH,
    FLV_COUNT
};

enum ToppingId {
    TOP_BERRY = 0, TOP_BISCUIT, TOP_PEANUT, TOP_CHERRY,
    TOP_FRUIT, TOP_CHOCOLATE, TOP_GEM, TOP_CANDLE,
    TOP_COUNT
};

enum WrapId {
    WRAP_NONE = 0, WRAP_ROPE, WRAP_BOX, WRAP_SHEET, WRAP_RIBBON,
    WRAP_COUNT
};

struct ShapeDef   { const char* name; const char* note; };
struct FlavorDef  {
    const char* name;
    const char* note;
    Color sponge, spongeDark, filling;   /* the body of the cake      */
    Color cream, creamDeep, drip;        /* the frosting on top       */
    Color accent;                        /* piping and small details  */
};
struct ToppingDef { const char* name; const char* note; };
struct WrapDef    { const char* name; const char* note; };

const ShapeDef&   shapeDef(int id);
const FlavorDef&  flavorDef(int id);
const ToppingDef& toppingDef(int id);
const WrapDef&    wrapDef(int id);

int          wrapPaletteSize();
Color        wrapPaletteColor(int i);
const char*  wrapPaletteName(int i);

/* --------------------------------------------------------------- design */
struct Placed {
    int   type;
    float u, v;     /* position on the top surface, in unit shape coordinates */
    float rot;      /* orientation in degrees                                 */
    float scale;    /* relative size                                          */
    int   variant;  /* seed for the small deterministic details               */
    float born;     /* time of placement, used for the pop-in animation       */
    Placed() : type(0), u(0), v(0), rot(0), scale(1.0f), variant(0), born(0) {}
};

struct Design {
    int shape;
    int polySides;      /* used when shape == SHAPE_POLYGON, 5..8 */
    int layers;         /* 1..3 stacked tiers                     */
    int flavor;
    std::vector<Placed> toppings;
    int wrap;
    int wrapColor;

    Design();
    void reset();
    bool hasCandle() const;
    int  countOf(int toppingType) const;
};

/* ------------------------------------------------------------- geometry */
/*  Unit outline: a closed loop of points describing the chosen base shape,
 *  roughly inscribed in a circle of radius 1 about the origin.             */
void shapeOutlineUnit(std::vector<Vec2>& out, const Design& d, int steps = 72);
bool insideUnitShape(const Design& d, Vec2 uv, float margin = 0.90f);

/*  Where the cake is drawn and how big it is.                              */
struct Frame {
    Vec2  centre;        /* centre of the bottom tier, at plate height */
    float radius;        /* pixels per unit in x                       */
    float squash;        /* vertical foreshortening of a top face      */
    float layerHeight;   /* height in pixels of one tier               */
};
Frame makeFrame(Vec2 centre, float radius, int layers);

float layerScale(const Design& d, int layerIndex);
float topElevation(const Design& d, const Frame& f);
Vec2  topCentre(const Design& d, const Frame& f);
Vec2  uvToScreen(const Design& d, const Frame& f, Vec2 uv);
bool  screenToUV(const Design& d, const Frame& f, Vec2 screen, Vec2& uvOut);
float toppingPixelSize(const Design& d, const Frame& f);

/* ------------------------------------------------------------ rendering */
struct RenderOpts {
    float time;
    bool  showToppings;
    bool  showWrap;
    bool  showPlate;
    bool  highlightSurface;   /* pulse the top face while placing toppings   */
    bool  algorithmView;      /* redraw outlines with the scan converters    */
    int   ghostTopping;       /* -1, or a topping drawn faintly at the mouse */
    Vec2  ghostUV;
    bool  ghostValid;
    int   selectedTopping;    /* index into Design::toppings, or -1          */
    RenderOpts();
};

void drawCake(const Design& d, const Frame& f, const RenderOpts& o);

/*  Individual pieces, also used to draw the little previews on the buttons. */
void drawTopping(int type, Vec2 centre, float size, float rotDeg, int variant,
                 float time, float alpha = 1.0f);
void drawShapeIcon(int shapeId, int polySides, Vec2 centre, float size, const Color& c);
void drawWrapBehind(const Design& d, const Frame& f, float time);
void drawWrapFront(const Design& d, const Frame& f, float time);
void drawWrapIcon(int wrapId, Vec2 centre, float size, const Color& tint, float time);

/*  A compact one-line description such as "Round, red velvet, 6 toppings".  */
std::string describe(const Design& d);

} /* namespace cake */

#endif /* CAKELAB_CAKE_H */

/* ===== screenshot.h ================================================== */
/* ============================================================================
 *  CakeLab  -  screenshot.h
 *  Reads the colour buffer back with glReadPixels and writes it out as an
 *  uncompressed 24 bit BMP, so a finished cake can be handed in with the
 *  report. No image library is involved; the header is written by hand.
 * ==========================================================================*/
#ifndef CAKELAB_SCREENSHOT_H
#define CAKELAB_SCREENSHOT_H


namespace shot {

/*  Grabs the given rectangle of the window and writes it to path.
 *  Returns false if the file could not be opened.                           */
bool saveBMP(const std::string& path, int x, int y, int w, int h);

/*  Picks the next unused name of the form cakelab_001.bmp in the working
 *  directory.                                                               */
std::string nextFilename();

} /* namespace shot */

#endif /* CAKELAB_SCREENSHOT_H */

/* ===== app.h ========================================================= */
/* ============================================================================
 *  CakeLab  -  app.h
 *  The application shell: window layout, the stage machine and the shared
 *  state that the four stage modules read and write.
 *
 *  The program is one window with four sequential stages. Each stage owns a
 *  panel of option buttons on the left and shares the live preview on the
 *  right. A stage is described by a StageDef, which is nothing more than a
 *  title and a set of callbacks, so adding or reordering stages does not
 *  touch the shell.
 * ==========================================================================*/
#ifndef CAKELAB_APP_H
#define CAKELAB_APP_H


namespace app {

enum Screen { SCREEN_WELCOME = 0, SCREEN_STAGE, SCREEN_FINISH };

const int STAGE_COUNT = 4;

/* ----------------------------------------------------------------- layout */
struct Layout {
    float W, H;
    float headerY, headerH;
    float footerY, footerH;
    float panelX, panelY, panelW, panelH;
    float previewX, previewY, previewW, previewH;
};
extern Layout L;
void computeLayout(int w, int h);

/* ----------------------------------------------------------- stage plumbing */
struct StageDef {
    const char* key;
    const char* title;
    const char* subtitle;
    const char* hint;

    void (*build)();                 /* fill g_options / g_extras            */
    void (*onOption)(int id);        /* an option row was clicked            */
    void (*onExtra)(int id);         /* a chip in the extras row was clicked */
    void (*drawPanelExtra)();        /* anything below the option list       */
    void (*drawPreviewOverlay)();    /* stage specific marks in the preview  */
    void (*onPreviewMouse)(float x, float y, int button, int state);
    void (*onPreviewMotion)(float x, float y);
    bool (*canAdvance)();            /* is the Next button enabled           */
};

const StageDef& stageShape();
const StageDef& stageFlavor();
const StageDef& stageToppings();
const StageDef& stageWrap();
const StageDef& currentStage();

/* ------------------------------------------------------------ shared state */
extern cake::Design           g_design;
extern std::vector<ui::Button> g_options;
extern std::vector<ui::Button> g_extras;
extern float g_time;
extern float g_mouseX, g_mouseY;
extern int   g_stage;
extern int   g_screen;
extern int   g_furthest;
extern bool  g_algorithmView;

/*  Where the cake is drawn in the preview panel.                            */
cake::Frame previewFrame();
float previewCaptionY(int line);
float previewCaptionRight();
cake::Frame heroFrame(float cx, float cy, float radius);

/* ------------------------------------------------- helpers for the stages */
float panelListTop();
float panelListBottom();
void  layoutRows(std::vector<ui::Button>& list, float rowH, float gap, float topEdge);
void  layoutChips(std::vector<ui::Button>& list, float x, float y, float chipW,
                  float chipH, float gap, int perRow);
void  rebuildStage();
void  markDirty();

/* --------------------------------------------------------------- lifecycle */
void init();
void update(float dt);
void draw();

void onMouse(int button, int state, int mx, int my);
void onMotion(int mx, int my);
void onKey(unsigned char key, int mx, int my);
void onSpecial(int key, int mx, int my);

void activateOption(int index);
void toppingsUndo();
void toppingsClear();
void toppingsScatter();
int  toppingsSelected();
bool toppingsGhostValid();
cake::Vec2 toppingsGhostUV();
int  toppingsHoverIndex();
void toppingsResetHover();

void goToStage(int s);
void nextStage();
void prevStage();
void resetDesign();
void randomizeDesign();
void finish();
void saveScreenshot();

} /* namespace app */

#endif /* CAKELAB_APP_H */

/* ===== gfx.cpp ======================================================= */
/* ============================================================================
 *  CakeLab  -  gfx.cpp
 *  Implementation of the 2D drawing toolkit. See gfx.h for the overview.
 * ==========================================================================*/

namespace gfx {

/* ==========================================================================
 *  Vectors and scalar maths
 * ========================================================================*/
Vec2 normalize(const Vec2& a) {
    float len = length(a);
    if (len < 1e-6f) return Vec2(0.0f, 0.0f);
    return Vec2(a.x / len, a.y / len);
}

Vec2 perp(const Vec2& a) { return Vec2(-a.y, a.x); }

Vec2 rotated(const Vec2& a, float deg) {
    float r = deg2rad(deg);
    float c = std::cos(r), s = std::sin(r);
    return Vec2(a.x * c - a.y * s, a.x * s + a.y * c);
}

float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
float lerpf(float a, float b, float t)    { return a + (b - a) * t; }
float deg2rad(float d)                    { return d * PI / 180.0f; }
float rad2deg(float r)                    { return r * 180.0f / PI; }

float smoothstep(float edge0, float edge1, float x) {
    if (edge1 - edge0 == 0.0f) return x < edge0 ? 0.0f : 1.0f;
    float t = clampf((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

/*  A hash instead of rand(): the same input always gives the same output, so
 *  scattered detail such as sprinkles stays put between frames.              */
float hash11(float x) {
    float s = std::sin(x * 127.1f) * 43758.5453f;
    return s - std::floor(s);
}

float hash21(float x, float y) {
    float s = std::sin(x * 127.1f + y * 311.7f) * 43758.5453f;
    return s - std::floor(s);
}

float valueNoise(float x) {
    float i = std::floor(x);
    float f = x - i;
    float u = f * f * (3.0f - 2.0f * f);
    return lerpf(hash11(i), hash11(i + 1.0f), u);
}

bool pointInPoly(const std::vector<Vec2>& poly, Vec2 p) {
    /* Even-odd rule: count how many edges a ray to the right crosses. */
    bool inside = false;
    size_t n = poly.size();
    if (n < 3) return false;
    for (size_t i = 0, j = n - 1; i < n; j = i++) {
        bool straddles = (poly[i].y > p.y) != (poly[j].y > p.y);
        if (straddles) {
            float t = (p.y - poly[i].y) / (poly[j].y - poly[i].y);
            float xCross = poly[i].x + t * (poly[j].x - poly[i].x);
            if (p.x < xCross) inside = !inside;
        }
    }
    return inside;
}

/* ==========================================================================
 *  Colour model
 * ========================================================================*/
Color rgb(int r, int g, int b) {
    return Color(r / 255.0f, g / 255.0f, b / 255.0f, 1.0f);
}

Color rgba(int r, int g, int b, float a) {
    return Color(r / 255.0f, g / 255.0f, b / 255.0f, a);
}

Color mix(const Color& a, const Color& b, float t) {
    t = clampf(t, 0.0f, 1.0f);
    return Color(lerpf(a.r, b.r, t), lerpf(a.g, b.g, t),
                 lerpf(a.b, b.b, t), lerpf(a.a, b.a, t));
}

Color shade(const Color& c, float factor) {
    return Color(clampf(c.r * factor, 0.0f, 1.0f),
                 clampf(c.g * factor, 0.0f, 1.0f),
                 clampf(c.b * factor, 0.0f, 1.0f), c.a);
}

Color withAlpha(const Color& c, float a) { return Color(c.r, c.g, c.b, a); }

/*  HSV to RGB. Hue is in degrees, saturation and value in 0..1.             */
Color hsv(float h, float s, float v, float a) {
    h = std::fmod(h, 360.0f);
    if (h < 0.0f) h += 360.0f;
    float c = v * s;
    float x = c * (1.0f - std::fabs(std::fmod(h / 60.0f, 2.0f) - 1.0f));
    float m = v - c;
    float r = 0.0f, g = 0.0f, b = 0.0f;
    if      (h <  60.0f) { r = c; g = x; }
    else if (h < 120.0f) { r = x; g = c; }
    else if (h < 180.0f) { g = c; b = x; }
    else if (h < 240.0f) { g = x; b = c; }
    else if (h < 300.0f) { r = x; b = c; }
    else                 { r = c; b = x; }
    return Color(r + m, g + m, b + m, a);
}

void useColor(const Color& c) { glColor4f(c.r, c.g, c.b, c.a); }

/* ==========================================================================
 *  Scan conversion
 *
 *  These follow the incremental algorithms from the course notes. Each one
 *  produces integer pixel positions and emits them as GL_POINTS.
 * ========================================================================*/

/*  Digital Differential Analyser.
 *  Step along the dominant axis in unit increments and advance the other axis
 *  by its constant slope increment, rounding to the nearest pixel.           */
void lineDDA(Vec2 a, Vec2 b, const Color& c, float pointSize) {
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    int steps = (int)(std::max(std::fabs(dx), std::fabs(dy)) + 0.5f);
    if (steps <= 0) steps = 1;

    float xInc = dx / (float)steps;
    float yInc = dy / (float)steps;
    float x = a.x, y = a.y;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; ++i) {
        glVertex2f(std::floor(x + 0.5f), std::floor(y + 0.5f));
        x += xInc;
        y += yInc;
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Bresenham midpoint line, integer arithmetic only, valid in all octants.
 *  The decision variable err tracks which side of the ideal line the midpoint
 *  between the two candidate pixels falls on.                                */
void lineBresenham(Vec2 a, Vec2 b, const Color& c, float pointSize) {
    int x0 = (int)std::floor(a.x + 0.5f), y0 = (int)std::floor(a.y + 0.5f);
    int x1 = (int)std::floor(b.x + 0.5f), y1 = (int)std::floor(b.y + 0.5f);

    int dx =  std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (;;) {
        glVertex2i(x0, y0);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Midpoint circle algorithm. One octant is generated and the remaining seven
 *  are obtained by symmetry, which is why only x and y are stepped.          */
void circleMidpoint(Vec2 centre, float r, const Color& c, float pointSize) {
    int cx = (int)std::floor(centre.x + 0.5f);
    int cy = (int)std::floor(centre.y + 0.5f);
    int radius = (int)std::floor(r + 0.5f);
    if (radius <= 0) return;

    int x = 0, y = radius;
    int d = 1 - radius;             /* decision variable */

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    while (x <= y) {
        glVertex2i(cx + x, cy + y);  glVertex2i(cx - x, cy + y);
        glVertex2i(cx + x, cy - y);  glVertex2i(cx - x, cy - y);
        glVertex2i(cx + y, cy + x);  glVertex2i(cx - y, cy + x);
        glVertex2i(cx + y, cy - x);  glVertex2i(cx - y, cy - x);
        if (d < 0) {
            d += 2 * x + 3;
        } else {
            d += 2 * (x - y) + 5;
            --y;
        }
        ++x;
    }
    glEnd();
    glPointSize(1.0f);
}

/*  Midpoint ellipse algorithm, in two regions split where the tangent slope
 *  passes through -1. Four-way symmetry.                                     */
void ellipseMidpoint(Vec2 centre, float rx, float ry, const Color& c, float pointSize) {
    long a = (long)std::floor(rx + 0.5f);
    long b = (long)std::floor(ry + 0.5f);
    if (a <= 0 || b <= 0) return;
    int cx = (int)std::floor(centre.x + 0.5f);
    int cy = (int)std::floor(centre.y + 0.5f);

    long aa = a * a, bb = b * b;
    long x = 0, y = b;
    long d1 = bb - aa * b + aa / 4;
    long dx = 2 * bb * x, dy = 2 * aa * y;

    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);

    while (dx < dy) {                            /* region 1 */
        glVertex2i(cx + (int)x, cy + (int)y); glVertex2i(cx - (int)x, cy + (int)y);
        glVertex2i(cx + (int)x, cy - (int)y); glVertex2i(cx - (int)x, cy - (int)y);
        if (d1 < 0) {
            ++x; dx += 2 * bb; d1 += dx + bb;
        } else {
            ++x; --y; dx += 2 * bb; dy -= 2 * aa; d1 += dx - dy + bb;
        }
    }

    long d2 = bb * (x * x + x) + aa * (y - 1) * (y - 1) - aa * bb;
    /* the term above is the region-2 decision variable evaluated at the
       midpoint of the first candidate pair                                   */
    while (y >= 0) {                             /* region 2 */
        glVertex2i(cx + (int)x, cy + (int)y); glVertex2i(cx - (int)x, cy + (int)y);
        glVertex2i(cx + (int)x, cy - (int)y); glVertex2i(cx - (int)x, cy - (int)y);
        if (d2 > 0) {
            --y; dy -= 2 * aa; d2 += aa - dy;
        } else {
            ++x; --y; dy -= 2 * aa; dx += 2 * bb; d2 += dx - dy + aa;
        }
    }
    glEnd();
    glPointSize(1.0f);
}

/*  The parametric point loop: x = cx + r cos t, y = cy + r sin t.
 *  This is the form used for every filled round shape in CakeLab.            */
void circleParametric(Vec2 centre, float r, const Color& c, int steps, float pointSize) {
    if (steps < 3) steps = 3;
    glPointSize(pointSize);
    useColor(c);
    glBegin(GL_POINTS);
    for (int i = 0; i < steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + r * std::cos(t), centre.y + r * std::sin(t));
    }
    glEnd();
    glPointSize(1.0f);
}

void polylineBresenham(const std::vector<Vec2>& pts, const Color& c, bool closed, float pointSize) {
    if (pts.size() < 2) return;
    for (size_t i = 0; i + 1 < pts.size(); ++i)
        lineBresenham(pts[i], pts[i + 1], c, pointSize);
    if (closed) lineBresenham(pts.back(), pts.front(), c, pointSize);
}

/* ==========================================================================
 *  Outline generators (all parametric point loops)
 * ========================================================================*/
void makeCircle(std::vector<Vec2>& out, Vec2 centre, float r, int steps) {
    makeEllipse(out, centre, r, r, steps);
}

void makeEllipse(std::vector<Vec2>& out, Vec2 centre, float rx, float ry, int steps) {
    if (steps < 3) steps = 3;
    out.clear();
    out.reserve((size_t)steps);
    for (int i = 0; i < steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        out.push_back(Vec2(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t)));
    }
}

void makeRegularPolygon(std::vector<Vec2>& out, Vec2 centre, float r, int sides, float rotDeg) {
    if (sides < 3) sides = 3;
    out.clear();
    out.reserve((size_t)sides);
    float phase = deg2rad(rotDeg);
    for (int i = 0; i < sides; ++i) {
        float t = phase + 2.0f * PI * (float)i / (float)sides;
        out.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
}

void makeRoundRect(std::vector<Vec2>& out, float x, float y, float w, float h, float r, int cornerSteps) {
    out.clear();
    r = clampf(r, 0.0f, std::min(w, h) * 0.5f);
    if (cornerSteps < 1) cornerSteps = 1;

    struct Corner { float cx, cy, a0; };
    Corner corners[4] = {
        { x + w - r, y + r,     270.0f },   /* bottom right */
        { x + w - r, y + h - r,   0.0f },   /* top right    */
        { x + r,     y + h - r,  90.0f },   /* top left     */
        { x + r,     y + r,     180.0f }    /* bottom left  */
    };
    for (int k = 0; k < 4; ++k) {
        for (int i = 0; i <= cornerSteps; ++i) {
            float a = deg2rad(corners[k].a0 + 90.0f * (float)i / (float)cornerSteps);
            out.push_back(Vec2(corners[k].cx + r * std::cos(a),
                               corners[k].cy + r * std::sin(a)));
        }
    }
}

void makeStar(std::vector<Vec2>& out, Vec2 centre, float rOuter, float rInner, int points, float rotDeg) {
    if (points < 2) points = 2;
    out.clear();
    out.reserve((size_t)points * 2);
    float phase = deg2rad(rotDeg);
    for (int i = 0; i < points * 2; ++i) {
        float t = phase + PI * (float)i / (float)points;
        float r = (i % 2 == 0) ? rOuter : rInner;
        out.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
}

void makeBezier(std::vector<Vec2>& out, Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, int steps) {
    if (steps < 1) steps = 1;
    out.clear();
    out.reserve((size_t)steps + 1);
    for (int i = 0; i <= steps; ++i) {
        float t  = (float)i / (float)steps;
        float u  = 1.0f - t;
        float b0 = u * u * u;
        float b1 = 3.0f * u * u * t;
        float b2 = 3.0f * u * t * t;
        float b3 = t * t * t;
        out.push_back(Vec2(b0 * p0.x + b1 * p1.x + b2 * p2.x + b3 * p3.x,
                           b0 * p0.y + b1 * p1.y + b2 * p2.y + b3 * p3.y));
    }
}

/* ==========================================================================
 *  Filled and stroked drawing
 * ========================================================================*/
static Vec2 centroidOf(const std::vector<Vec2>& pts) {
    Vec2 c(0.0f, 0.0f);
    if (pts.empty()) return c;
    for (size_t i = 0; i < pts.size(); ++i) { c.x += pts[i].x; c.y += pts[i].y; }
    c.x /= (float)pts.size();
    c.y /= (float)pts.size();
    return c;
}

void line(Vec2 a, Vec2 b, const Color& c, float width) {
    if (width <= 1.25f) {
        useColor(c);
        glBegin(GL_LINES);
        glVertex2f(a.x, a.y);
        glVertex2f(b.x, b.y);
        glEnd();
        return;
    }
    Vec2 d = b - a;
    float len = length(d);
    if (len < 1e-4f) { fillCircle(a, width * 0.5f, c, 10); return; }
    Vec2 n = perp(Vec2(d.x / len, d.y / len)) * (width * 0.5f);
    useColor(c);
    glBegin(GL_QUADS);
    glVertex2f(a.x + n.x, a.y + n.y);
    glVertex2f(b.x + n.x, b.y + n.y);
    glVertex2f(b.x - n.x, b.y - n.y);
    glVertex2f(a.x - n.x, a.y - n.y);
    glEnd();
}

void polyline(const std::vector<Vec2>& pts, const Color& c, float width, bool closed) {
    if (pts.size() < 2) return;
    for (size_t i = 0; i + 1 < pts.size(); ++i) line(pts[i], pts[i + 1], c, width);
    if (closed) line(pts.back(), pts.front(), c, width);
    if (width > 2.5f) {                       /* round off the joints */
        for (size_t i = closed ? 0 : 1; i + (closed ? 0 : 1) < pts.size(); ++i)
            fillCircle(pts[i], width * 0.5f, c, 10);
    }
}

void fillPoly(const std::vector<Vec2>& pts, const Color& c) {
    if (pts.size() < 3) return;
    Vec2 mid = centroidOf(pts);
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(mid.x, mid.y);
    for (size_t i = 0; i < pts.size(); ++i) glVertex2f(pts[i].x, pts[i].y);
    glVertex2f(pts[0].x, pts[0].y);
    glEnd();
}

void fillPolyGrad(const std::vector<Vec2>& pts, Vec2 centre, const Color& inner, const Color& outer) {
    if (pts.size() < 3) return;
    glBegin(GL_TRIANGLE_FAN);
    useColor(inner);
    glVertex2f(centre.x, centre.y);
    useColor(outer);
    for (size_t i = 0; i < pts.size(); ++i) glVertex2f(pts[i].x, pts[i].y);
    glVertex2f(pts[0].x, pts[0].y);
    glEnd();
}

void fillPolyGradV(const std::vector<Vec2>& pts, const Color& bottom, const Color& top) {
    if (pts.size() < 3) return;
    float lo = pts[0].y, hi = pts[0].y;
    for (size_t i = 1; i < pts.size(); ++i) {
        lo = std::min(lo, pts[i].y);
        hi = std::max(hi, pts[i].y);
    }
    float span = (hi - lo) > 1e-4f ? (hi - lo) : 1.0f;
    Vec2 mid = centroidOf(pts);

    glBegin(GL_TRIANGLE_FAN);
    useColor(mix(bottom, top, (mid.y - lo) / span));
    glVertex2f(mid.x, mid.y);
    for (size_t i = 0; i <= pts.size(); ++i) {
        const Vec2& p = pts[i % pts.size()];
        useColor(mix(bottom, top, (p.y - lo) / span));
        glVertex2f(p.x, p.y);
    }
    glEnd();
}

void strokePoly(const std::vector<Vec2>& pts, const Color& c, float width) {
    polyline(pts, c, width, true);
}

void fillCircle(Vec2 centre, float r, const Color& c, int steps) {
    fillEllipse(centre, r, r, c, steps);
}

void fillEllipse(Vec2 centre, float rx, float ry, const Color& c, int steps) {
    if (steps < 3) steps = 3;
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centre.x, centre.y);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t));
    }
    glEnd();
}

void fillCircleGrad(Vec2 centre, float r, const Color& inner, const Color& outer, int steps) {
    fillEllipseGrad(centre, r, r, inner, outer, steps);
}

void fillEllipseGrad(Vec2 centre, float rx, float ry, const Color& inner, const Color& outer, int steps) {
    if (steps < 3) steps = 3;
    glBegin(GL_TRIANGLE_FAN);
    useColor(inner);
    glVertex2f(centre.x, centre.y);
    useColor(outer);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        glVertex2f(centre.x + rx * std::cos(t), centre.y + ry * std::sin(t));
    }
    glEnd();
}

void strokeCircle(Vec2 centre, float r, const Color& c, float width, int steps) {
    std::vector<Vec2> pts;
    makeCircle(pts, centre, r, steps);
    polyline(pts, c, width, true);
}

void ring(Vec2 centre, float rInner, float rOuter, const Color& c, int steps) {
    if (steps < 3) steps = 3;
    useColor(c);
    glBegin(GL_TRIANGLE_STRIP);
    for (int i = 0; i <= steps; ++i) {
        float t = 2.0f * PI * (float)i / (float)steps;
        float cs = std::cos(t), sn = std::sin(t);
        glVertex2f(centre.x + rInner * cs, centre.y + rInner * sn);
        glVertex2f(centre.x + rOuter * cs, centre.y + rOuter * sn);
    }
    glEnd();
}

void fillArc(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, int steps) {
    if (steps < 2) steps = 2;
    useColor(c);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centre.x, centre.y);
    for (int i = 0; i <= steps; ++i) {
        float t = deg2rad(lerpf(startDeg, endDeg, (float)i / (float)steps));
        glVertex2f(centre.x + r * std::cos(t), centre.y + r * std::sin(t));
    }
    glEnd();
}

void arcStroke(Vec2 centre, float r, float startDeg, float endDeg, const Color& c, float width, int steps) {
    if (steps < 2) steps = 2;
    std::vector<Vec2> pts;
    pts.reserve((size_t)steps + 1);
    for (int i = 0; i <= steps; ++i) {
        float t = deg2rad(lerpf(startDeg, endDeg, (float)i / (float)steps));
        pts.push_back(Vec2(centre.x + r * std::cos(t), centre.y + r * std::sin(t)));
    }
    polyline(pts, c, width, false);
}

void fillRect(float x, float y, float w, float h, const Color& c) {
    useColor(c);
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
}

void fillRectGradV(float x, float y, float w, float h, const Color& bottom, const Color& top) {
    glBegin(GL_QUADS);
    useColor(bottom); glVertex2f(x, y);     glVertex2f(x + w, y);
    useColor(top);    glVertex2f(x + w, y + h); glVertex2f(x, y + h);
    glEnd();
}

void fillRectGradH(float x, float y, float w, float h, const Color& left, const Color& right) {
    glBegin(GL_QUADS);
    useColor(left);  glVertex2f(x, y);         glVertex2f(x, y + h);
    useColor(right); glVertex2f(x + w, y + h); glVertex2f(x + w, y);
    glEnd();
}

void strokeRect(float x, float y, float w, float h, const Color& c, float width) {
    std::vector<Vec2> pts;
    pts.push_back(Vec2(x, y));
    pts.push_back(Vec2(x + w, y));
    pts.push_back(Vec2(x + w, y + h));
    pts.push_back(Vec2(x, y + h));
    polyline(pts, c, width, true);
}

void fillRoundRect(float x, float y, float w, float h, float r, const Color& c) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    fillPoly(pts, c);
}

void fillRoundRectGradV(float x, float y, float w, float h, float r, const Color& bottom, const Color& top) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    fillPolyGradV(pts, bottom, top);
}

void strokeRoundRect(float x, float y, float w, float h, float r, const Color& c, float width) {
    std::vector<Vec2> pts;
    makeRoundRect(pts, x, y, w, h, r);
    polyline(pts, c, width, true);
}

void fillTri(Vec2 a, Vec2 b, Vec2 c, const Color& col) {
    useColor(col);
    glBegin(GL_TRIANGLES);
    glVertex2f(a.x, a.y);
    glVertex2f(b.x, b.y);
    glVertex2f(c.x, c.y);
    glEnd();
}

void fillRegularPolygon(Vec2 centre, float r, int sides, float rotDeg, const Color& c) {
    std::vector<Vec2> pts;
    makeRegularPolygon(pts, centre, r, sides, rotDeg);
    fillPoly(pts, c);
}

void fillStar(Vec2 centre, float rOuter, float rInner, int points, float rotDeg, const Color& c) {
    std::vector<Vec2> pts;
    makeStar(pts, centre, rOuter, rInner, points, rotDeg);
    fillPoly(pts, c);
}

void fillCapsule(Vec2 a, Vec2 b, float r, const Color& c) {
    line(a, b, c, r * 2.0f);
    fillCircle(a, r, c, 16);
    fillCircle(b, r, c, 16);
}

void softShadow(Vec2 centre, float rx, float ry, float alpha, int steps) {
    /* Three stacked translucent ellipses approximate a soft falloff. */
    for (int i = 3; i >= 1; --i) {
        float k = (float)i / 3.0f;
        fillEllipse(centre, rx * (0.6f + 0.4f * k), ry * (0.6f + 0.4f * k),
                    Color(0.0f, 0.0f, 0.0f, alpha * 0.34f), steps);
    }
}

/* ==========================================================================
 *  Text
 * ========================================================================*/
static void* bitmapFont(FontId f) {
    switch (f) {
        case FONT_XS: return GLUT_BITMAP_HELVETICA_10;
        case FONT_S:  return GLUT_BITMAP_HELVETICA_12;
        case FONT_M:  return GLUT_BITMAP_HELVETICA_18;
        case FONT_L:  return GLUT_BITMAP_TIMES_ROMAN_24;
    }
    return GLUT_BITMAP_HELVETICA_18;
}

float textWidth(const std::string& s, FontId f) {
    return (float)glutBitmapLength((void*)bitmapFont(f), (const unsigned char*)s.c_str());
}

float textHeight(FontId f) {
    switch (f) {
        case FONT_XS: return 10.0f;
        case FONT_S:  return 12.0f;
        case FONT_M:  return 18.0f;
        case FONT_L:  return 24.0f;
    }
    return 18.0f;
}

void text(float x, float y, const std::string& s, const Color& c, FontId f) {
    useColor(c);
    glRasterPos2f(std::floor(x), std::floor(y));
    void* font = bitmapFont(f);
    for (size_t i = 0; i < s.size(); ++i)
        glutBitmapCharacter(font, (int)(unsigned char)s[i]);
}

void textCentered(float cx, float y, const std::string& s, const Color& c, FontId f) {
    text(cx - textWidth(s, f) * 0.5f, y, s, c, f);
}

void textRight(float rx, float y, const std::string& s, const Color& c, FontId f) {
    text(rx - textWidth(s, f), y, s, c, f);
}

/*  GLUT stroke fonts are drawn in a 119.05 unit em box.                      */
static const float kStrokeEm = 119.05f;

float strokeTextWidth(const std::string& s, float size) {
    float w = (float)glutStrokeLength(GLUT_STROKE_ROMAN, (const unsigned char*)s.c_str());
    return w * (size / kStrokeEm);
}

void strokeText(float x, float y, const std::string& s, const Color& c, float size, float weight) {
    float scale = size / kStrokeEm;
    useColor(c);
    glLineWidth(weight);
    glPushMatrix();
    glTranslatef(x, y, 0.0f);
    glScalef(scale, scale, 1.0f);
    for (size_t i = 0; i < s.size(); ++i)
        glutStrokeCharacter(GLUT_STROKE_ROMAN, (int)(unsigned char)s[i]);
    glPopMatrix();
    glLineWidth(1.0f);
}

void strokeTextCentered(float cx, float y, const std::string& s, const Color& c, float size, float weight) {
    strokeText(cx - strokeTextWidth(s, size) * 0.5f, y, s, c, size, weight);
}

/* ==========================================================================
 *  Transforms, clipping and set-up
 * ========================================================================*/
void pushTransform(Vec2 translate, float rotDeg, float scaleX, float scaleY) {
    glPushMatrix();
    glTranslatef(translate.x, translate.y, 0.0f);   /* translation */
    if (rotDeg != 0.0f) glRotatef(rotDeg, 0.0f, 0.0f, 1.0f);  /* rotation */
    if (scaleX != 1.0f || scaleY != 1.0f) glScalef(scaleX, scaleY, 1.0f); /* scaling */
}

void popTransform() { glPopMatrix(); }

void pushScissor(float x, float y, float w, float h) {
    glEnable(GL_SCISSOR_TEST);
    glScissor((GLint)x, (GLint)y, (GLsizei)std::max(0.0f, w), (GLsizei)std::max(0.0f, h));
}

void popScissor() { glDisable(GL_SCISSOR_TEST); }

void begin2D(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, (GLdouble)w, 0.0, (GLdouble)h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void enableBlend() {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
}

} /* namespace gfx */

/* ===== ui.cpp ======================================================== */
/* ============================================================================
 *  CakeLab  -  ui.cpp
 *  Implementation of the interface furniture described in ui.h.
 * ==========================================================================*/

namespace ui {

using namespace gfx;

Theme T;

void initTheme() {
    T.bgBottom   = rgb( 22, 14, 26);
    T.bgTop      = rgb( 48, 27, 47);
    T.stageInner = rgb( 78, 45, 72);
    T.stageOuter = rgb( 30, 18, 32);
    T.panel      = rgb( 44, 28, 45);
    T.panelEdge  = rgb( 80, 53, 78);
    T.panelHi    = rgb( 60, 39, 60);
    T.text       = rgb(255, 241, 248);
    T.textDim    = rgb(196, 165, 190);
    T.textFaint  = rgb(140, 112, 136);
    T.accent     = rgb(255, 116, 163);
    T.accentDark = rgb(196,  62, 108);
    T.accent2    = rgb(255, 205, 110);
    T.ok         = rgb(126, 222, 170);
    T.danger     = rgb(255, 110, 110);
    T.plate      = rgb(238, 232, 240);
    T.plateEdge  = rgb(190, 180, 196);
}

/* ==========================================================================
 *  Buttons
 * ========================================================================*/
Button::Button()
    : x(0), y(0), w(0), h(0), id(-1), style(BTN_OPTION),
      tint(rgb(255, 255, 255)), icon(0), iconArg(0), enabled(true), selected(false),
      visible(true), hoverAnim(0.0f), pressAnim(0.0f) {}

Button makeButton(float x, float y, float w, float h, int id,
                  const std::string& label, ButtonStyle style) {
    Button b;
    b.x = x; b.y = y; b.w = w; b.h = h;
    b.id = id;
    b.label = label;
    b.style = style;
    return b;
}

bool hitTest(const Button& b, float mx, float my) {
    if (!b.enabled || !b.visible) return false;
    return mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h;
}

int hitIndex(const std::vector<Button>& list, float mx, float my) {
    for (size_t i = 0; i < list.size(); ++i)
        if (hitTest(list[i], mx, my)) return (int)i;
    return -1;
}

void animateButtons(std::vector<Button>& list, float mx, float my, float dt) {
    for (size_t i = 0; i < list.size(); ++i) {
        Button& b = list[i];
        float target = hitTest(b, mx, my) ? 1.0f : 0.0f;
        float rate = 12.0f * dt;
        b.hoverAnim += (target - b.hoverAnim) * clampf(rate, 0.0f, 1.0f);
        b.pressAnim += (0.0f - b.pressAnim) * clampf(9.0f * dt, 0.0f, 1.0f);
    }
}

static void drawSelectionGlow(float x, float y, float w, float h, float r,
                              const Color& c, float strength) {
    if (strength <= 0.01f) return;
    for (int i = 3; i >= 1; --i) {
        float pad = (float)i * 2.4f;
        fillRoundRect(x - pad, y - pad, w + pad * 2.0f, h + pad * 2.0f, r + pad,
                      withAlpha(c, 0.10f * strength));
    }
}

static void drawOptionLike(const Button& b, float time, bool swatch) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = 13.0f;

    float sel = b.selected ? 1.0f : 0.0f;
    Color fill = mix(T.panel, T.panelHi, b.hoverAnim * 0.9f);
    if (b.selected) fill = mix(fill, T.accentDark, 0.55f);
    if (!b.enabled) fill = mix(T.panel, T.bgBottom, 0.5f);

    drawSelectionGlow(x, y, w, h, r, T.accent, sel);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? T.accent : mix(T.panelEdge, T.accent, b.hoverAnim * 0.6f),
                    b.selected ? 2.0f : 1.4f);

    /* left accent bar marks the current choice at a glance */
    if (sel > 0.0f) fillRoundRect(x + 4.0f, y + 8.0f, 4.0f, h - 16.0f, 2.0f, T.accent);

    float iconSlot = h - 14.0f;
    Vec2  iconMid(x + 16.0f + iconSlot * 0.5f, y + h * 0.5f);

    if (swatch) {
        fillRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                      iconSlot, iconSlot, 9.0f, b.tint);
        strokeRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                        iconSlot, iconSlot, 9.0f, withAlpha(rgb(0, 0, 0), 0.25f), 1.2f);
        if (b.icon) b.icon(iconMid, iconSlot * 0.62f, time, b.iconArg);
    } else if (b.icon) {
        fillRoundRect(iconMid.x - iconSlot * 0.5f, iconMid.y - iconSlot * 0.5f,
                      iconSlot, iconSlot, 9.0f,
                      withAlpha(b.selected ? T.accent : T.panelHi, b.selected ? 0.22f : 0.85f));
        b.icon(iconMid, iconSlot * 0.60f, time, b.iconArg);
    }

    float textX = x + 16.0f + iconSlot + 14.0f;
    Color titleCol = b.enabled ? (b.selected ? T.text : mix(T.text, T.textDim, 0.25f))
                               : T.textFaint;
    if (b.sub.empty()) {
        text(textX, y + h * 0.5f - 6.0f, b.label, titleCol, FONT_M);
    } else {
        text(textX, y + h * 0.5f + 2.0f, b.label, titleCol, FONT_M);
        text(textX, y + h * 0.5f - 15.0f, b.sub, b.selected ? mix(T.text, T.accent, 0.5f) : T.textFaint, FONT_XS);
    }

    if (b.selected) {
        Vec2 c(x + w - 22.0f, y + h * 0.5f);
        fillCircle(c, 10.0f, T.accent, 20);
        drawCheck(c, 10.0f, rgb(40, 16, 28), 2.6f);
    }
}

static void drawPrimary(const Button& b, float time) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = h * 0.5f;

    Color a = b.enabled ? mix(T.accent, rgb(255, 160, 190), b.hoverAnim * 0.7f)
                        : mix(T.panel, T.panelEdge, 0.4f);
    Color bcol = b.enabled ? mix(T.accentDark, T.accent, b.hoverAnim * 0.7f)
                           : mix(T.panel, T.panelEdge, 0.2f);

    if (b.enabled) {
        float pulse = 0.5f + 0.5f * std::sin(time * 2.4f);
        drawSelectionGlow(x, y, w, h, r, T.accent, 0.55f + 0.45f * pulse);
    }
    fillRoundRectGradV(x, y, w, h, r, bcol, a);
    strokeRoundRect(x, y, w, h, r, withAlpha(rgb(255, 255, 255), b.enabled ? 0.30f : 0.08f), 1.2f);

    Color lc = b.enabled ? rgb(48, 14, 30) : T.textFaint;
    float tw = textWidth(b.label, FONT_M);
    float chev = b.enabled ? 16.0f : 0.0f;
    float startX = x + (w - tw - chev) * 0.5f;
    text(startX, y + h * 0.5f - 6.0f, b.label, lc, FONT_M);
    if (b.enabled)
        drawChevron(Vec2(startX + tw + 11.0f, y + h * 0.5f), 6.0f, 0.0f, lc, 2.6f);
}

static void drawGhost(const Button& b) {
    float press = b.pressAnim * 2.0f;
    float x = b.x + press, y = b.y + press;
    float w = b.w - press * 2.0f, h = b.h - press * 2.0f;
    float r = h * 0.5f;

    Color edge = b.enabled ? mix(T.panelEdge, T.accent, b.hoverAnim) : mix(T.panelEdge, T.bgTop, 0.6f);
    fillRoundRect(x, y, w, h, r, withAlpha(T.panelHi, 0.25f + 0.55f * b.hoverAnim));
    strokeRoundRect(x, y, w, h, r, edge, 1.4f);
    Color lc = b.enabled ? mix(T.textDim, T.text, b.hoverAnim) : T.textFaint;
    textCentered(x + w * 0.5f, y + h * 0.5f - 6.0f, b.label, lc, FONT_S);
}

static void drawChip(const Button& b, float time) {
    float x = b.x, y = b.y, w = b.w, h = b.h, r = h * 0.5f;
    Color fill = b.selected ? T.accent : mix(T.panel, T.panelHi, 0.4f + 0.6f * b.hoverAnim);
    if (b.tint.a > 0.0f && b.style == BTN_CHIP && b.icon == 0 && b.label.empty()) fill = b.tint;

    if (b.selected) drawSelectionGlow(x, y, w, h, r, T.accent, 1.0f);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? rgb(255, 255, 255) : mix(T.panelEdge, T.accent, b.hoverAnim),
                    b.selected ? 2.0f : 1.2f);
    /*  Icon and label share the pill: icon on the left, label in what is
     *  left over. Either one on its own is centred.                        */
    bool hasIcon  = (b.icon != 0);
    bool hasLabel = !b.label.empty();
    Color lc = b.selected ? rgb(48, 14, 30) : mix(T.textDim, T.text, b.hoverAnim);

    if (hasIcon && hasLabel) {
        b.icon(Vec2(x + h * 0.60f, y + h * 0.5f), h * 0.28f, time, b.iconArg);
        float textLeft = x + h * 1.06f;
        textCentered(textLeft + (x + w - 8.0f - textLeft) * 0.5f,
                     y + h * 0.5f - 5.0f, b.label, lc, FONT_XS);
    } else if (hasIcon) {
        b.icon(Vec2(x + w * 0.5f, y + h * 0.5f), h * 0.34f, time, b.iconArg);
    } else if (hasLabel) {
        textCentered(x + w * 0.5f, y + h * 0.5f - 5.0f, b.label, lc, FONT_S);
    }
}

static void drawIconButton(const Button& b, float time) {
    float x = b.x, y = b.y, w = b.w, h = b.h, r = 11.0f;
    Color fill = mix(T.panel, T.panelHi, 0.35f + 0.65f * b.hoverAnim);
    if (b.selected) fill = mix(fill, T.accentDark, 0.6f);
    fillRoundRect(x, y, w, h, r, fill);
    strokeRoundRect(x, y, w, h, r,
                    b.selected ? T.accent : mix(T.panelEdge, T.accent, b.hoverAnim), 1.3f);
    if (b.icon) b.icon(Vec2(x + w * 0.5f, y + h * 0.5f), std::min(w, h) * 0.32f, time, b.iconArg);
    else        textCentered(x + w * 0.5f, y + h * 0.5f - 5.0f, b.label, T.textDim, FONT_S);
}

void drawButton(const Button& b, float time) {
    if (!b.visible) return;
    switch (b.style) {
        case BTN_OPTION:  drawOptionLike(b, time, false); break;
        case BTN_SWATCH:  drawOptionLike(b, time, true);  break;
        case BTN_PRIMARY: drawPrimary(b, time);           break;
        case BTN_GHOST:   drawGhost(b);                   break;
        case BTN_CHIP:    drawChip(b, time);              break;
        case BTN_ICON:    drawIconButton(b, time);        break;
    }
}

void drawButtons(const std::vector<Button>& list, float time) {
    for (size_t i = 0; i < list.size(); ++i) drawButton(list[i], time);
}

/* ==========================================================================
 *  Panels and backdrop
 * ========================================================================*/
void drawBackdrop(float w, float h, float time) {
    fillRectGradV(0.0f, 0.0f, w, h, T.bgBottom, T.bgTop);

    /* Two very soft drifting blobs stop the flat background looking dead. */
    for (int i = 0; i < 2; ++i) {
        float ph = time * 0.13f + (float)i * 2.1f;
        float cx = w * (0.30f + 0.42f * (float)i) + std::cos(ph) * 70.0f;
        float cy = h * (0.62f - 0.22f * (float)i) + std::sin(ph * 1.3f) * 45.0f;
        Color glow = (i == 0) ? withAlpha(T.accent, 0.055f) : withAlpha(T.accent2, 0.045f);
        fillCircleGrad(Vec2(cx, cy), 300.0f, glow, withAlpha(glow, 0.0f), 48);
    }
}

void drawPanel(float x, float y, float w, float h, float radius) {
    drawPanelTinted(x, y, w, h, radius, T.panel, T.panelEdge);
}

void drawPanelTinted(float x, float y, float w, float h, float radius,
                     const Color& fill, const Color& edge) {
    fillRoundRect(x + 2.0f, y - 3.0f, w, h, radius, withAlpha(rgb(0, 0, 0), 0.28f));
    fillRoundRectGradV(x, y, w, h, radius, shade(fill, 0.86f), shade(fill, 1.06f));
    strokeRoundRect(x, y, w, h, radius, edge, 1.3f);
}

void drawSectionLabel(float x, float y, const std::string& s) {
    text(x, y, s, T.textFaint, FONT_XS);
}

void drawDivider(float x, float y, float w) {
    fillRect(x, y, w, 1.0f, withAlpha(T.panelEdge, 0.7f));
}

/* ==========================================================================
 *  Stage stepper
 * ========================================================================*/
void drawStepper(float x, float y, float w, float h,
                 const std::vector<std::string>& names, int current,
                 int furthestReached, float time) {
    int n = (int)names.size();
    if (n <= 0) return;

    float nodeR   = 12.0f;
    float nodeY   = y + h - nodeR - 2.0f;
    float slot    = w / (float)n;
    float firstX  = x + slot * 0.5f;

    /* connector track */
    fillRoundRect(firstX, nodeY - 1.5f, slot * (float)(n - 1), 3.0f, 1.5f,
                  withAlpha(T.panelEdge, 0.9f));
    float doneFrac = (float)current / (float)(n - 1 > 0 ? n - 1 : 1);
    fillRoundRect(firstX, nodeY - 1.5f, slot * (float)(n - 1) * doneFrac, 3.0f, 1.5f, T.accent);

    for (int i = 0; i < n; ++i) {
        float cx = firstX + slot * (float)i;
        bool done    = i < current;
        bool active  = i == current;
        bool reached = i <= furthestReached;

        Color fill = active ? T.accent : (done ? T.accentDark : mix(T.panel, T.panelEdge, 0.5f));
        if (active) {
            float pulse = 0.5f + 0.5f * std::sin(time * 3.0f);
            fillCircle(Vec2(cx, nodeY), nodeR + 4.0f + pulse * 2.0f, withAlpha(T.accent, 0.18f), 24);
        }
        fillCircle(Vec2(cx, nodeY), nodeR, fill, 26);
        strokeCircle(Vec2(cx, nodeY), nodeR, withAlpha(rgb(255, 255, 255), active ? 0.55f : 0.18f), 1.3f, 26);

        if (done) {
            drawCheck(Vec2(cx, nodeY), nodeR * 0.95f, rgb(255, 255, 255), 2.2f);
        } else {
            char num[8];
            std::sprintf(num, "%d", i + 1);
            textCentered(cx, nodeY - 4.0f, num,
                         active ? rgb(48, 14, 30) : (reached ? T.textDim : T.textFaint), FONT_S);
        }

        Color lc = active ? T.text : (reached ? T.textDim : T.textFaint);
        textCentered(cx, y + 1.0f, names[(size_t)i], lc, FONT_XS);
    }
}

/* ==========================================================================
 *  Small decorations
 * ========================================================================*/
void drawCheck(Vec2 centre, float size, const Color& c, float weight) {
    Vec2 a(centre.x - size * 0.42f, centre.y + size * 0.04f);
    Vec2 b(centre.x - size * 0.10f, centre.y - size * 0.32f);
    Vec2 d(centre.x + size * 0.44f, centre.y + size * 0.36f);
    line(a, b, c, weight);
    line(b, d, c, weight);
    fillCircle(b, weight * 0.5f, c, 8);
}

void drawChevron(Vec2 centre, float size, float dirDeg, const Color& c, float weight) {
    Vec2 a = rotated(Vec2(-size * 0.5f,  size), dirDeg);
    Vec2 b = rotated(Vec2( size * 0.5f,  0.0f), dirDeg);
    Vec2 d = rotated(Vec2(-size * 0.5f, -size), dirDeg);
    line(centre + a, centre + b, c, weight);
    line(centre + b, centre + d, c, weight);
}

void drawSparkle(Vec2 centre, float size, const Color& c) {
    fillStar(centre, size, size * 0.28f, 4, 0.0f, c);
    fillCircle(centre, size * 0.16f, withAlpha(rgb(255, 255, 255), c.a), 10);
}

void drawKeyCap(float x, float y, const std::string& key, const Color& c) {
    float w = std::max(22.0f, textWidth(key, FONT_XS) + 14.0f);
    float h = 19.0f;
    fillRoundRect(x, y, w, h, 5.0f, withAlpha(T.panelHi, 0.9f));
    strokeRoundRect(x, y, w, h, 5.0f, T.panelEdge, 1.1f);
    textCentered(x + w * 0.5f, y + 6.0f, key, c, FONT_XS);
}

/* ==========================================================================
 *  Toasts
 * ========================================================================*/
struct Toast {
    std::string msg;
    float life;
};
static std::vector<Toast> g_toasts;

void toast(const std::string& msg) {
    if (!g_toasts.empty() && g_toasts.back().msg == msg && g_toasts.back().life > 1.6f) {
        g_toasts.back().life = 2.4f;
        return;
    }
    Toast t;
    t.msg = msg;
    t.life = 2.4f;
    g_toasts.push_back(t);
    if (g_toasts.size() > 3) g_toasts.erase(g_toasts.begin());
}

void toastUpdate(float dt) {
    for (size_t i = 0; i < g_toasts.size(); ++i) g_toasts[i].life -= dt;
    while (!g_toasts.empty() && g_toasts.front().life <= 0.0f)
        g_toasts.erase(g_toasts.begin());
}

void toastDraw(float screenW, float baseY) {
    for (size_t i = 0; i < g_toasts.size(); ++i) {
        const Toast& t = g_toasts[i];
        float fade = clampf(t.life / 0.45f, 0.0f, 1.0f) *
                     clampf((2.4f - t.life) / 0.18f, 0.0f, 1.0f);
        float w = textWidth(t.msg, FONT_S) + 34.0f;
        float h = 32.0f;
        float x = screenW * 0.5f - w * 0.5f;
        float y = baseY + (float)(g_toasts.size() - 1 - i) * (h + 8.0f) + (1.0f - fade) * -8.0f;

        fillRoundRect(x, y, w, h, h * 0.5f, withAlpha(rgb(24, 14, 26), 0.94f * fade));
        strokeRoundRect(x, y, w, h, h * 0.5f, withAlpha(T.accent, 0.65f * fade), 1.3f);
        fillCircle(Vec2(x + 16.0f, y + h * 0.5f), 4.0f, withAlpha(T.accent, fade), 12);
        text(x + 27.0f, y + h * 0.5f - 4.0f, t.msg, withAlpha(T.text, fade), FONT_S);
    }
}

/* ==========================================================================
 *  Wrapped text
 * ========================================================================*/
float drawWrapped(float x, float y, float maxWidth, const std::string& s,
                  const Color& c, FontId f, float lineGap) {
    std::string word, lineBuf;
    float lineH = textHeight(f) + lineGap;
    float cursorY = y;

    size_t i = 0;
    while (i <= s.size()) {
        char ch = (i < s.size()) ? s[i] : ' ';
        if (ch == ' ' || ch == '\n' || i == s.size()) {
            std::string candidate = lineBuf.empty() ? word : lineBuf + " " + word;
            if (textWidth(candidate, f) > maxWidth && !lineBuf.empty()) {
                text(x, cursorY, lineBuf, c, f);
                cursorY -= lineH;
                lineBuf = word;
            } else {
                lineBuf = candidate;
            }
            word.clear();
            if (ch == '\n') {
                text(x, cursorY, lineBuf, c, f);
                cursorY -= lineH;
                lineBuf.clear();
            }
        } else {
            word.push_back(ch);
        }
        ++i;
    }
    if (!lineBuf.empty()) {
        text(x, cursorY, lineBuf, c, f);
        cursorY -= lineH;
    }
    return y - cursorY;   /* total height consumed */
}

} /* namespace ui */

/* ===== cake.cpp ====================================================== */
/* ============================================================================
 *  CakeLab  -  cake.cpp
 *  The design data, the geometry that positions it on screen, and the renderer
 *  that draws the cake itself. Toppings live in toppings.cpp and packaging in
 *  wrapping.cpp; everything else about the cake is here.
 * ==========================================================================*/

namespace cake {

using namespace gfx;

/* ==========================================================================
 *  Catalogues
 * ========================================================================*/
static const ShapeDef kShapes[SHAPE_COUNT] = {
    { "Round",     "classic circle, drawn point by point" },
    { "Square",    "four equal sides, sharp corners"      },
    { "Triangle",  "three sides, a slice of a cake"       },
    { "Rectangle", "wide sheet cake"                      },
    { "Polygon",   "regular n-gon, five to eight sides"   }
};

struct FlavorNote { const char* name; const char* note; };
static const FlavorNote kFlavorNames[FLV_COUNT] = {
    { "Strawberry",   "pink sponge, berry cream"      },
    { "Green Tea",    "matcha sponge, pistachio cream"},
    { "Black Forest", "cocoa sponge, white cream"     },
    { "Red Velvet",   "crimson crumb, cheese icing"   },
    { "Mango",        "golden sponge, mango cream"    },
    { "Chocolate",    "dark sponge, fudge frosting"   },
    { "Vanilla",      "butter sponge, plain cream"    },
    { "Butterscotch", "caramel sponge and glaze"      }
};

/*  The colour tables are filled once at start-up so that rgb() can be used
 *  (the 0..255 form is far easier to read than 0..1 literals).              */
static FlavorDef g_flavors[FLV_COUNT];
static bool      g_flavorsReady = false;

static void buildFlavors() {
    if (g_flavorsReady) return;
    for (int i = 0; i < FLV_COUNT; ++i) {
        g_flavors[i].name = kFlavorNames[i].name;
        g_flavors[i].note = kFlavorNames[i].note;
    }
    FlavorDef* f;

    f = &g_flavors[FLV_STRAWBERRY];
    f->sponge = rgb(248,214,222); f->spongeDark = rgb(224,170,186); f->filling = rgb(234, 92,126);
    f->cream  = rgb(255,190,207); f->creamDeep  = rgb(230,140,168); f->drip    = rgb(255,164,190);
    f->accent = rgb(214, 52, 96);

    f = &g_flavors[FLV_GREEN];
    f->sponge = rgb(216,232,190); f->spongeDark = rgb(176,202,146); f->filling = rgb(126,178, 96);
    f->cream  = rgb(198,228,168); f->creamDeep  = rgb(148,190,118); f->drip    = rgb(176,214,140);
    f->accent = rgb( 86,148, 68);

    f = &g_flavors[FLV_BLACKFOREST];
    f->sponge = rgb( 88, 54, 47); f->spongeDark = rgb( 54, 32, 28); f->filling = rgb(250,246,240);
    f->cream  = rgb(250,247,242); f->creamDeep  = rgb(212,202,194); f->drip    = rgb( 66, 39, 33);
    f->accent = rgb(178, 26, 42);

    f = &g_flavors[FLV_REDVELVET];
    f->sponge = rgb(170, 42, 54); f->spongeDark = rgb(118, 26, 36); f->filling = rgb(252,248,242);
    f->cream  = rgb(252,249,244); f->creamDeep  = rgb(218,206,196); f->drip    = rgb(206, 72, 86);
    f->accent = rgb(140, 28, 42);

    f = &g_flavors[FLV_MANGO];
    f->sponge = rgb(255,226,160); f->spongeDark = rgb(230,190,108); f->filling = rgb(255,182, 66);
    f->cream  = rgb(255,208,110); f->creamDeep  = rgb(230,168, 68); f->drip    = rgb(255,190, 80);
    f->accent = rgb(226,132, 26);

    f = &g_flavors[FLV_CHOCOLATE];
    f->sponge = rgb( 98, 61, 45); f->spongeDark = rgb( 60, 36, 25); f->filling = rgb(146, 94, 62);
    f->cream  = rgb( 86, 51, 37); f->creamDeep  = rgb( 54, 31, 21); f->drip    = rgb( 70, 40, 28);
    f->accent = rgb(208,152, 98);

    f = &g_flavors[FLV_VANILLA];
    f->sponge = rgb(250,235,206); f->spongeDark = rgb(226,206,170); f->filling = rgb(255,248,228);
    f->cream  = rgb(255,247,232); f->creamDeep  = rgb(226,212,186); f->drip    = rgb(246,232,200);
    f->accent = rgb(214,180,120);

    f = &g_flavors[FLV_BUTTERSCOTCH];
    f->sponge = rgb(238,196,132); f->spongeDark = rgb(204,158, 94); f->filling = rgb(198,124, 52);
    f->cream  = rgb(228,168, 92); f->creamDeep  = rgb(188,128, 60); f->drip    = rgb(214,146, 70);
    f->accent = rgb(150, 88, 32);

    g_flavorsReady = true;
}

static const ToppingDef kToppings[TOP_COUNT] = {
    { "Berries",   "blueberry cluster"       },
    { "Biscuit",   "round wafer biscuit"     },
    { "Peanuts",   "roasted peanut halves"   },
    { "Cherry",    "glace cherry with stem"  },
    { "Fruit",     "orange slice"            },
    { "Chocolate", "chocolate chunk"         },
    { "Gems",      "candy gem, faceted"      },
    { "Candle",    "lit candle, animated"    }
};

static const WrapDef kWraps[WRAP_COUNT] = {
    { "Open",          "no packaging, serve as is"    },
    { "Rope Tie",      "two bands crossed with a bow" },
    { "Gift Box",      "open box with a window front"  },
    { "Wrapping Sheet","patterned sheet, folded"      },
    { "Ribbon & Tag",  "waist ribbon and a name tag"  }
};

const ShapeDef&   shapeDef(int id)   { return kShapes[(id >= 0 && id < SHAPE_COUNT) ? id : 0]; }
const ToppingDef& toppingDef(int id) { return kToppings[(id >= 0 && id < TOP_COUNT) ? id : 0]; }
const WrapDef&    wrapDef(int id)    { return kWraps[(id >= 0 && id < WRAP_COUNT) ? id : 0]; }

const FlavorDef& flavorDef(int id) {
    buildFlavors();
    return g_flavors[(id >= 0 && id < FLV_COUNT) ? id : 0];
}

/* --------------------------------------------------------- wrap palette */
static const int kWrapPaletteN = 6;
static Color g_wrapPalette[kWrapPaletteN];
static bool  g_wrapPaletteReady = false;
static const char* kWrapPaletteNames[kWrapPaletteN] = {
    "Rose", "Gold", "Mint", "Sky", "Lilac", "Cocoa"
};

static void buildWrapPalette() {
    if (g_wrapPaletteReady) return;
    g_wrapPalette[0] = rgb(238, 104, 140);
    g_wrapPalette[1] = rgb(246, 190,  80);
    g_wrapPalette[2] = rgb(114, 208, 168);
    g_wrapPalette[3] = rgb(112, 176, 232);
    g_wrapPalette[4] = rgb(186, 148, 232);
    g_wrapPalette[5] = rgb(150, 104,  74);
    g_wrapPaletteReady = true;
}

int wrapPaletteSize() { return kWrapPaletteN; }

Color wrapPaletteColor(int i) {
    buildWrapPalette();
    if (i < 0) i = 0;
    if (i >= kWrapPaletteN) i = kWrapPaletteN - 1;
    return g_wrapPalette[i];
}

const char* wrapPaletteName(int i) {
    if (i < 0) i = 0;
    if (i >= kWrapPaletteN) i = kWrapPaletteN - 1;
    return kWrapPaletteNames[i];
}

/* ==========================================================================
 *  Design
 * ========================================================================*/
Design::Design() { reset(); }

void Design::reset() {
    shape     = SHAPE_CIRCLE;
    polySides = 6;
    layers    = 1;
    flavor    = FLV_STRAWBERRY;
    toppings.clear();
    wrap      = WRAP_NONE;
    wrapColor = 0;
}

bool Design::hasCandle() const {
    for (size_t i = 0; i < toppings.size(); ++i)
        if (toppings[i].type == TOP_CANDLE) return true;
    return false;
}

int Design::countOf(int toppingType) const {
    int n = 0;
    for (size_t i = 0; i < toppings.size(); ++i)
        if (toppings[i].type == toppingType) ++n;
    return n;
}

std::string describe(const Design& d) {
    char buf[192];
    std::sprintf(buf, "%s, %s, %d topping%s, %s",
                 shapeDef(d.shape).name,
                 flavorDef(d.flavor).name,
                 (int)d.toppings.size(),
                 d.toppings.size() == 1 ? "" : "s",
                 wrapDef(d.wrap).name);
    return std::string(buf);
}

/* ==========================================================================
 *  Geometry
 * ========================================================================*/
/*  Corners are preserved exactly and long edges are subdivided, so that the
 *  same code can shade a circle and a triangle without special cases.       */
static void densify(const std::vector<Vec2>& base, int targetSteps, std::vector<Vec2>& out) {
    out.clear();
    size_t n = base.size();
    if (n < 3) { out = base; return; }

    float perimeter = 0.0f;
    for (size_t i = 0; i < n; ++i)
        perimeter += length(base[(i + 1) % n] - base[i]);
    if (perimeter < 1e-5f) { out = base; return; }

    float target = perimeter / (float)targetSteps;
    for (size_t i = 0; i < n; ++i) {
        Vec2 a = base[i];
        Vec2 b = base[(i + 1) % n];
        float len = length(b - a);
        int cuts = (int)(len / target + 0.5f);
        if (cuts < 1) cuts = 1;
        for (int k = 0; k < cuts; ++k) {
            float t = (float)k / (float)cuts;
            out.push_back(Vec2(lerpf(a.x, b.x, t), lerpf(a.y, b.y, t)));
        }
    }
}

void shapeOutlineUnit(std::vector<Vec2>& out, const Design& d, int steps) {
    std::vector<Vec2> base;
    switch (d.shape) {
        case SHAPE_CIRCLE:
            makeCircle(base, Vec2(0.0f, 0.0f), 1.0f, steps);
            out = base;
            return;
        case SHAPE_SQUARE: {
            /*  The square is turned a little before it is squashed. Without
             *  that turn its top face and its front face are both axis
             *  aligned rectangles and the cake reads as a flat wall; turned,
             *  two side faces meet at a front corner and the solid is
             *  immediately legible.                                          */
            float s = 0.78f;
            base.push_back(Vec2( s, -s)); base.push_back(Vec2( s,  s));
            base.push_back(Vec2(-s,  s)); base.push_back(Vec2(-s, -s));
            for (size_t i = 0; i < base.size(); ++i) base[i] = rotated(base[i], 26.0f);
            break;
        }
        case SHAPE_RECT: {
            float w = 1.02f, h = 0.58f;
            base.push_back(Vec2( w, -h)); base.push_back(Vec2( w,  h));
            base.push_back(Vec2(-w,  h)); base.push_back(Vec2(-w, -h));
            for (size_t i = 0; i < base.size(); ++i) base[i] = rotated(base[i], 16.0f);
            break;
        }
        case SHAPE_TRIANGLE: {
            /* counter-clockwise, flat side towards the viewer */
            makeRegularPolygon(base, Vec2(0.0f, -0.08f), 1.12f, 3, 90.0f);
            break;
        }
        case SHAPE_POLYGON: {
            int sides = d.polySides;
            if (sides < 5) sides = 5;
            if (sides > 8) sides = 8;
            makeRegularPolygon(base, Vec2(0.0f, 0.0f), 1.02f, sides,
                               -90.0f + 180.0f / (float)sides);
            break;
        }
        default:
            makeCircle(base, Vec2(0.0f, 0.0f), 1.0f, steps);
            out = base;
            return;
    }
    densify(base, steps, out);
}

bool insideUnitShape(const Design& d, Vec2 uv, float margin) {
    std::vector<Vec2> poly;
    shapeOutlineUnit(poly, d, 48);
    for (size_t i = 0; i < poly.size(); ++i) poly[i] = poly[i] * margin;
    return pointInPoly(poly, uv);
}

Frame makeFrame(Vec2 centre, float radius, int layers) {
    Frame f;
    f.centre      = centre;
    f.radius      = radius;
    f.squash      = 0.40f;
    /*  A single tier is roughly half as tall as it is wide; stacked tiers are
     *  shorter each so that a three tier cake still fits the preview.        */
    f.layerHeight = radius * (layers >= 3 ? 0.36f : (layers == 2 ? 0.44f : 0.52f));
    return f;
}

float layerScale(const Design& d, int layerIndex) {
    if (d.layers <= 1) return 1.0f;
    return std::pow(0.78f, (float)layerIndex);
}

float topElevation(const Design& d, const Frame& f) {
    return f.layerHeight * (float)d.layers;
}

Vec2 topCentre(const Design& d, const Frame& f) {
    return Vec2(f.centre.x, f.centre.y + topElevation(d, f));
}

Vec2 uvToScreen(const Design& d, const Frame& f, Vec2 uv) {
    float s = layerScale(d, d.layers - 1);
    return Vec2(f.centre.x + uv.x * f.radius * s,
                f.centre.y + uv.y * f.radius * f.squash * s + topElevation(d, f));
}

bool screenToUV(const Design& d, const Frame& f, Vec2 screen, Vec2& uvOut) {
    float s = layerScale(d, d.layers - 1);
    if (f.radius < 1e-3f || s < 1e-3f) return false;
    uvOut.x = (screen.x - f.centre.x) / (f.radius * s);
    uvOut.y = (screen.y - f.centre.y - topElevation(d, f)) / (f.radius * f.squash * s);
    return insideUnitShape(d, uvOut);
}

float toppingPixelSize(const Design& d, const Frame& f) {
    return f.radius * 0.105f * layerScale(d, d.layers - 1);
}

/* ==========================================================================
 *  Render options
 * ========================================================================*/
RenderOpts::RenderOpts()
    : time(0.0f), showToppings(true), showWrap(true), showPlate(true),
      highlightSurface(false), algorithmView(false), ghostTopping(-1),
      ghostUV(0.0f, 0.0f), ghostValid(false), selectedTopping(-1) {}

/* ==========================================================================
 *  Cake rendering
 * ========================================================================*/
static const Vec2 kLightDir(-0.62f, 0.78f);   /* light from the upper left */

static void outlineAt(const std::vector<Vec2>& unit, const Frame& f,
                      float scale, float elevation, std::vector<Vec2>& out) {
    out.resize(unit.size());
    for (size_t i = 0; i < unit.size(); ++i) {
        out[i] = Vec2(f.centre.x + unit[i].x * f.radius * scale,
                      f.centre.y + unit[i].y * f.radius * f.squash * scale + elevation);
    }
}

/*  Outward normal of the edge starting at index i, in unit space, assuming a
 *  counter-clockwise loop.                                                  */
static Vec2 edgeNormal(const std::vector<Vec2>& unit, size_t i) {
    const Vec2& a = unit[i];
    const Vec2& b = unit[(i + 1) % unit.size()];
    return normalize(Vec2(b.y - a.y, -(b.x - a.x)));
}

static void drawPlate(const Design& d, const Frame& f, const Color& plate, const Color& edge) {
    float s = 1.0f;
    for (int i = 0; i < d.layers; ++i) s = std::max(s, layerScale(d, i));
    float rx = f.radius * s * 1.30f;
    float ry = f.radius * f.squash * s * 1.30f;

    softShadow(Vec2(f.centre.x, f.centre.y - ry * 0.30f), rx * 1.05f, ry * 0.80f, 0.30f);
    fillEllipse(Vec2(f.centre.x, f.centre.y - 7.0f), rx, ry, shade(edge, 0.86f), 64);
    fillEllipseGrad(Vec2(f.centre.x, f.centre.y - 2.0f), rx, ry,
                    mix(plate, rgb(255, 255, 255), 0.35f), shade(plate, 0.88f), 64);
    {
        std::vector<Vec2> rim;
        makeEllipse(rim, Vec2(f.centre.x, f.centre.y - 2.0f), rx, ry, 64);
        polyline(rim, withAlpha(edge, 0.85f), 1.6f, true);
        makeEllipse(rim, Vec2(f.centre.x, f.centre.y - 2.0f), rx * 0.86f, ry * 0.86f, 64);
        polyline(rim, withAlpha(edge, 0.45f), 1.1f, true);
    }
    /* a soft sheen sweeping across the plate */
    fillEllipse(Vec2(f.centre.x - rx * 0.34f, f.centre.y + ry * 0.20f),
                rx * 0.34f, ry * 0.30f, withAlpha(rgb(255, 255, 255), 0.22f), 32);
}

/*  One tier: the extruded sides, the filling stripe, the frosting collar,
 *  the drips and the frosted top face.                                      */
static void drawTier(const Design& d, const Frame& f, const std::vector<Vec2>& unit,
                     int layer, const RenderOpts& o) {
    const FlavorDef& fl = flavorDef(d.flavor);
    float scale = layerScale(d, layer);
    float eBot  = f.layerHeight * (float)layer;
    float eTop  = f.layerHeight * (float)(layer + 1);

    std::vector<Vec2> top, bot;
    outlineAt(unit, f, scale, eTop, top);
    outlineAt(unit, f, scale, eBot, bot);

    size_t n = unit.size();
    float  h = f.layerHeight;

    /* ---- 1. the sides of the tier ------------------------------------- */
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;                    /* facing away    */

        size_t j = (i + 1) % n;
        float k = clampf(0.88f + 0.30f * (-nrm.x * kLightDir.x + 0.0f), 0.56f, 1.16f);

        Color spTop = shade(fl.sponge,     k);
        Color spBot = shade(fl.spongeDark, k * 0.94f);

        glBegin(GL_QUADS);
        useColor(spTop); glVertex2f(top[i].x, top[i].y); glVertex2f(top[j].x, top[j].y);
        useColor(spBot); glVertex2f(bot[j].x, bot[j].y); glVertex2f(bot[i].x, bot[i].y);
        glEnd();

        /* the cream filling that runs through the middle of the sponge */
        float f0 = 0.40f, f1 = 0.55f;
        Color fillCol = shade(fl.filling, k);
        glBegin(GL_QUADS);
        useColor(fillCol);
        glVertex2f(top[i].x, top[i].y - h * f0); glVertex2f(top[j].x, top[j].y - h * f0);
        glVertex2f(top[j].x, top[j].y - h * f1); glVertex2f(top[i].x, top[i].y - h * f1);
        glEnd();

        /* crumb speckle, deterministic so it never crawls between frames */
        for (int s = 0; s < 3; ++s) {
            float ta = hash21((float)(i * 7 + s), (float)layer * 3.0f + 1.0f);
            float tb = 0.10f + 0.78f * hash21((float)(i * 13 + s), (float)layer * 5.0f + 2.0f);
            if (tb > f0 - 0.04f && tb < f1 + 0.04f) continue;
            Vec2 p(lerpf(top[i].x, top[j].x, ta), lerpf(top[i].y, top[j].y, ta) - h * tb);
            fillCircle(p, h * 0.022f, withAlpha(shade(fl.spongeDark, 0.82f), 0.55f), 8);
        }
    }

    /* ---- 2. drips of frosting running down the front ------------------ */
    float dripSpacing = std::max(30.0f, f.radius * 0.185f);
    float travelled   = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) { travelled = 0.0f; continue; }
        size_t j = (i + 1) % n;
        float segLen = length(top[j] - top[i]);
        float pos = dripSpacing - travelled;
        while (pos < segLen) {
            float t = pos / std::max(segLen, 1e-4f);
            Vec2 p(lerpf(top[i].x, top[j].x, t), lerpf(top[i].y, top[j].y, t));
            float seed = hash21(p.x * 0.11f, (float)layer * 4.0f + 0.5f);
            float len  = h * (0.10f + 0.30f * seed);
            float rad  = h * (0.048f + 0.030f * hash11(p.x * 0.07f + (float)layer));
            Color c    = mix(fl.cream, fl.drip, 0.55f);
            fillCapsule(Vec2(p.x, p.y - rad * 0.2f), Vec2(p.x, p.y - len), rad, c);
            fillCircle(Vec2(p.x - rad * 0.30f, p.y - len + rad * 0.25f), rad * 0.30f,
                       withAlpha(rgb(255, 255, 255), 0.28f), 10);
            pos += dripSpacing;
        }
        travelled = std::fmod(travelled + segLen, dripSpacing);
    }

    /* ---- 3. the frosting collar sitting on the rim -------------------- */
    float collar = h * 0.20f;
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;
        size_t j = (i + 1) % n;
        float k = clampf(0.90f + 0.26f * (-nrm.x * kLightDir.x), 0.60f, 1.18f);
        glBegin(GL_QUADS);
        useColor(shade(fl.cream, k));
        glVertex2f(top[i].x, top[i].y);
        glVertex2f(top[j].x, top[j].y);
        useColor(shade(fl.creamDeep, k * 0.95f));
        glVertex2f(top[j].x, top[j].y - collar);
        glVertex2f(top[i].x, top[i].y - collar);
        glEnd();
    }

    /* ---- 4. the frosted top face -------------------------------------- */
    Vec2 c = Vec2(f.centre.x, f.centre.y + eTop);
    fillPolyGrad(top, Vec2(c.x - f.radius * scale * 0.16f, c.y + f.radius * f.squash * scale * 0.20f),
                 mix(fl.cream, rgb(255, 255, 255), 0.30f), fl.creamDeep);

    /* a soft sheen towards the light */
    fillEllipse(Vec2(c.x - f.radius * scale * 0.34f, c.y + f.radius * f.squash * scale * 0.30f),
                f.radius * scale * 0.30f, f.radius * f.squash * scale * 0.26f,
                withAlpha(rgb(255, 255, 255), 0.16f), 32);

    polyline(top, withAlpha(shade(fl.creamDeep, 0.80f), 0.55f), 1.4f, true);

    /* ---- 5. piped dollops around the rim ------------------------------ */
    float pipeSpacing = std::max(20.0f, f.radius * scale * 0.16f);
    float acc = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        size_t j = (i + 1) % n;
        float segLen = length(top[j] - top[i]);
        float pos = pipeSpacing - acc;
        while (pos < segLen) {
            float t = pos / std::max(segLen, 1e-4f);
            Vec2 p(lerpf(top[i].x, top[j].x, t), lerpf(top[i].y, top[j].y, t));
            Vec2 inward = normalize(Vec2(c.x - p.x, c.y - p.y));
            Vec2 q = p + inward * (f.radius * scale * 0.045f);
            float r = f.radius * scale * 0.048f;
            fillCircle(q, r, mix(fl.cream, rgb(255, 255, 255), 0.16f), 14);
            fillCircle(Vec2(q.x - r * 0.28f, q.y + r * 0.26f), r * 0.40f,
                       withAlpha(rgb(255, 255, 255), 0.40f), 10);
            fillCircle(Vec2(q.x + r * 0.10f, q.y - r * 0.42f), r * 0.55f,
                       withAlpha(shade(fl.creamDeep, 0.90f), 0.30f), 10);
            pos += pipeSpacing;
        }
        acc = std::fmod(acc + segLen, pipeSpacing);
    }

    /* ---- 6. optional highlight of the placement surface --------------- */
    if (o.highlightSurface && layer == d.layers - 1) {
        float pulse = 0.5f + 0.5f * std::sin(o.time * 2.6f);
        std::vector<Vec2> inner(top.size());
        for (size_t i = 0; i < top.size(); ++i) {
            inner[i] = Vec2(c.x + (top[i].x - c.x) * 0.90f,
                            c.y + (top[i].y - c.y) * 0.90f);
        }
        polyline(inner, withAlpha(rgb(255, 255, 255), 0.18f + 0.22f * pulse), 2.0f, true);
    }
}

/*  Toppings are painted from the back of the cake towards the front so that
 *  the ones nearer the viewer correctly overlap the ones behind.            */
static void drawToppings(const Design& d, const Frame& f, const RenderOpts& o) {
    std::vector<int> order;
    order.reserve(d.toppings.size());
    for (size_t i = 0; i < d.toppings.size(); ++i) order.push_back((int)i);

    const std::vector<Placed>& tp = d.toppings;
    for (size_t a = 1; a < order.size(); ++a) {          /* insertion sort by v */
        int key = order[a];
        size_t b = a;
        while (b > 0 && tp[(size_t)order[b - 1]].v < tp[(size_t)key].v) {
            order[b] = order[b - 1];
            --b;
        }
        order[b] = key;
    }

    float base = toppingPixelSize(d, f);
    for (size_t k = 0; k < order.size(); ++k) {
        int idx = order[k];
        const Placed& p = tp[(size_t)idx];
        Vec2 pos = uvToScreen(d, f, Vec2(p.u, p.v));

        /* pop-in: a short scale overshoot when the piece is first placed */
        float age  = clampf((o.time - p.born) / 0.28f, 0.0f, 1.0f);
        float pop  = age < 1.0f ? (1.0f + 0.35f * std::sin(age * PI)) * age : 1.0f;
        float size = base * p.scale * pop;

        fillEllipse(Vec2(pos.x + size * 0.10f, pos.y - size * 0.42f),
                    size * 0.66f, size * 0.26f, withAlpha(rgb(60, 30, 45), 0.22f), 20);

        drawTopping(p.type, pos, size, p.rot, p.variant, o.time, 1.0f);

        if (o.selectedTopping == idx) {
            float pulse = 0.5f + 0.5f * std::sin(o.time * 6.0f);
            strokeCircle(pos, size * 1.25f, withAlpha(rgb(255, 120, 120), 0.55f + 0.35f * pulse),
                         2.0f, 24);
        }
    }

    if (o.ghostTopping >= 0 && o.ghostValid) {
        Vec2 pos = uvToScreen(d, f, o.ghostUV);
        drawTopping(o.ghostTopping, pos, base, 0.0f, 3, o.time, 0.45f);
        strokeCircle(pos, base * 1.30f, withAlpha(rgb(255, 255, 255), 0.35f), 1.4f, 24);
    }
}

/*  The algorithm view redraws the silhouette using the scan converters, so a
 *  viewer can see the actual rasterised pixels of the shapes on screen.      */
static void drawAlgorithmOverlay(const Design& d, const Frame& f, const RenderOpts& o) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 72);

    float scale = layerScale(d, d.layers - 1);
    Vec2  c     = topCentre(d, f);
    Color hot   = rgb(120, 255, 200);
    Color cool  = rgb(140, 190, 255);

    if (d.shape == SHAPE_CIRCLE) {
        ellipseMidpoint(c, f.radius * scale, f.radius * f.squash * scale, hot, 2.0f);
        text(c.x - f.radius * scale, c.y + f.radius * f.squash * scale + 14.0f,
             "midpoint ellipse", hot, FONT_XS);
    } else {
        std::vector<Vec2> top;
        outlineAt(unit, f, scale, topElevation(d, f), top);
        polylineBresenham(top, hot, true, 2.0f);
        text(c.x - f.radius * scale, c.y + f.radius * f.squash * scale + 14.0f,
             "Bresenham line loop", hot, FONT_XS);
    }

    /* the base of the bottom tier, drawn with the DDA */
    std::vector<Vec2> bot;
    outlineAt(unit, f, layerScale(d, 0), 0.0f, bot);
    for (size_t i = 0; i < bot.size(); ++i)
        lineDDA(bot[i], bot[(i + 1) % bot.size()], cool, 2.0f);
    text(f.centre.x - f.radius, f.centre.y - f.radius * f.squash - 22.0f,
         "DDA base outline", cool, FONT_XS);

    /* the vertical extrusion edges that build the sides */
    for (size_t i = 0; i < unit.size(); i += 6) {
        Vec2 nrm = edgeNormal(unit, i);
        if (nrm.y >= -0.02f) continue;
        std::vector<Vec2> t2;
        outlineAt(unit, f, layerScale(d, 0), f.layerHeight, t2);
        lineBresenham(t2[i], bot[i], withAlpha(rgb(255, 220, 120), 0.9f), 1.6f);
    }
    (void)o;
}

void drawCake(const Design& d, const Frame& f, const RenderOpts& o) {
    buildFlavors();
    buildWrapPalette();

    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 72);

    if (o.showWrap && d.wrap != WRAP_NONE) drawWrapBehind(d, f, o.time);
    if (o.showPlate) drawPlate(d, f, rgb(240, 234, 242), rgb(186, 176, 192));

    for (int layer = 0; layer < d.layers; ++layer)
        drawTier(d, f, unit, layer, o);

    if (o.showToppings) drawToppings(d, f, o);
    if (o.showWrap && d.wrap != WRAP_NONE) drawWrapFront(d, f, o.time);
    if (o.algorithmView) drawAlgorithmOverlay(d, f, o);
}

/* ==========================================================================
 *  Shape icon used on the option buttons
 * ========================================================================*/
void drawShapeIcon(int shapeId, int polySides, Vec2 centre, float size, const Color& c) {
    Color edge = shade(c, 0.72f);
    switch (shapeId) {
        case SHAPE_CIRCLE:
            fillCircle(centre, size, c, 40);
            strokeCircle(centre, size, edge, 1.6f, 40);
            break;
        case SHAPE_SQUARE:
            fillRoundRect(centre.x - size * 0.86f, centre.y - size * 0.86f,
                          size * 1.72f, size * 1.72f, size * 0.14f, c);
            strokeRoundRect(centre.x - size * 0.86f, centre.y - size * 0.86f,
                            size * 1.72f, size * 1.72f, size * 0.14f, edge, 1.6f);
            break;
        case SHAPE_RECT:
            fillRoundRect(centre.x - size * 1.05f, centre.y - size * 0.62f,
                          size * 2.10f, size * 1.24f, size * 0.14f, c);
            strokeRoundRect(centre.x - size * 1.05f, centre.y - size * 0.62f,
                            size * 2.10f, size * 1.24f, size * 0.14f, edge, 1.6f);
            break;
        case SHAPE_TRIANGLE: {
            std::vector<Vec2> p;
            makeRegularPolygon(p, Vec2(centre.x, centre.y - size * 0.10f), size * 1.14f, 3, 90.0f);
            fillPoly(p, c);
            polyline(p, edge, 1.6f, true);
            break;
        }
        case SHAPE_POLYGON: {
            int sides = polySides < 5 ? 5 : (polySides > 8 ? 8 : polySides);
            std::vector<Vec2> p;
            makeRegularPolygon(p, centre, size * 1.02f, sides, -90.0f + 180.0f / (float)sides);
            fillPoly(p, c);
            polyline(p, edge, 1.6f, true);
            break;
        }
        default: break;
    }
}

} /* namespace cake */

/* ===== toppings.cpp ================================================== */
/* ============================================================================
 *  CakeLab  -  toppings.cpp
 *  Every decorative ingredient the user can place on the cake.
 *
 *  Each ingredient is a composite object: several primitives grouped together
 *  and drawn in its own local coordinate system, which runs roughly from -1 to
 *  +1. drawTopping() pushes a translation, a rotation and a scale before
 *  calling the piece, so the same code draws a cherry at any position, any
 *  angle and any size. This is the "car and jeep" pattern from the lab work,
 *  applied to cake decorations.
 * ==========================================================================*/

namespace cake {

using namespace gfx;

/*  All colours pass through A() so that a whole ingredient can be drawn
 *  half transparent when it is only a placement preview.                    */
static float g_alpha = 1.0f;
static Color A(const Color& c) { return Color(c.r, c.g, c.b, c.a * g_alpha); }

/* -------------------------------------------------------------- berries */
static void drawBerry(int variant, float time) {
    (void)time;
    Color deep = rgb( 46,  44, 110);
    Color mid  = rgb( 78,  76, 168);
    Color lit  = rgb(126, 128, 216);
    if (variant % 3 == 1) { deep = rgb( 92, 24,  62); mid = rgb(146, 40,  96); lit = rgb(196, 84, 142); }
    if (variant % 3 == 2) { deep = rgb( 24,  62, 46); mid = rgb( 48, 108, 78); lit = rgb( 96, 168, 128); }

    struct B { float x, y, r; };
    B balls[3] = { { -0.36f, 0.28f, 0.44f }, { 0.38f, 0.22f, 0.40f }, { 0.00f, -0.22f, 0.56f } };

    for (int i = 0; i < 3; ++i) {
        Vec2 c(balls[i].x, balls[i].y);
        float r = balls[i].r;
        fillCircleGrad(c, r, A(mid), A(deep), 26);
        fillCircle(Vec2(c.x - r * 0.30f, c.y + r * 0.34f), r * 0.30f, A(withAlpha(lit, 0.85f)), 14);
        /* the little crown at the top of a blueberry */
        fillStar(Vec2(c.x + r * 0.05f, c.y + r * 0.42f), r * 0.30f, r * 0.12f, 5, 18.0f,
                 A(shade(deep, 0.7f)));
    }
}

/* -------------------------------------------------------------- biscuit */
static void drawBiscuit(int variant, float time) {
    (void)time;
    Color edge = rgb(176, 126,  76);
    Color face = rgb(226, 182, 128);
    Color dot  = rgb(126,  84,  48);
    if (variant % 2 == 1) { edge = rgb(104, 68, 44); face = rgb(150, 104, 68); dot = rgb(72, 44, 28); }

    fillCircle(Vec2(0.0f, -0.16f), 0.92f, A(shade(edge, 0.82f)), 32);   /* thickness */
    fillCircle(Vec2(0.0f,  0.00f), 0.92f, A(edge), 32);
    fillCircleGrad(Vec2(0.0f, 0.0f), 0.80f, A(mix(face, rgb(255, 255, 255), 0.18f)), A(face), 32);
    strokeCircle(Vec2(0.0f, 0.0f), 0.80f, A(withAlpha(shade(edge, 0.75f), 0.7f)), 0.05f, 32);

    for (int i = 0; i < 7; ++i) {
        float a = 2.0f * PI * (float)i / 7.0f + 0.4f;
        float rr = (i == 6) ? 0.0f : 0.45f;
        fillCircle(Vec2(std::cos(a) * rr, std::sin(a) * rr), 0.085f, A(dot), 10);
    }
    /* scalloped rim, drawn with the parametric loop */
    for (int i = 0; i < 16; ++i) {
        float a = 2.0f * PI * (float)i / 16.0f;
        fillCircle(Vec2(std::cos(a) * 0.92f, std::sin(a) * 0.92f), 0.085f, A(edge), 8);
    }
}

/* -------------------------------------------------------------- peanuts */
static void drawPeanut(int variant, float time) {
    (void)time;
    (void)variant;
    Color shell     = rgb(214, 168, 104);
    Color shellDark = rgb(168, 122,  66);
    Color shellLite = rgb(240, 208, 150);

    fillEllipse(Vec2(-0.34f, -0.06f), 0.50f, 0.44f, A(shellDark), 26);
    fillEllipse(Vec2( 0.34f, -0.06f), 0.46f, 0.40f, A(shellDark), 26);
    fillEllipse(Vec2(-0.34f,  0.02f), 0.48f, 0.42f, A(shell), 26);
    fillEllipse(Vec2( 0.34f,  0.02f), 0.44f, 0.38f, A(shell), 26);
    fillRect(-0.34f, -0.20f, 0.68f, 0.44f, A(shell));

    fillEllipse(Vec2(-0.44f, 0.18f), 0.18f, 0.12f, A(withAlpha(shellLite, 0.8f)), 16);
    fillEllipse(Vec2( 0.26f, 0.20f), 0.14f, 0.09f, A(withAlpha(shellLite, 0.6f)), 16);

    /* the seam that pinches the shell in the middle */
    std::vector<Vec2> seam;
    makeBezier(seam, Vec2(-0.78f, 0.06f), Vec2(-0.20f, 0.26f), Vec2(0.20f, -0.18f), Vec2(0.76f, 0.04f), 18);
    polyline(seam, A(withAlpha(shellDark, 0.75f)), 0.05f, false);
    fillCircle(Vec2(0.0f, 0.05f), 0.07f, A(withAlpha(shellDark, 0.5f)), 10);
}

/* --------------------------------------------------------------- cherry */
static void drawCherry(int variant, float time) {
    Color body     = (variant % 2 == 0) ? rgb(198, 30, 52) : rgb(166, 22, 68);
    Color bodyDeep = shade(body, 0.62f);
    Color stem     = rgb(96, 128, 54);

    float sway = std::sin(time * 1.6f + (float)variant) * 3.0f;

    std::vector<Vec2> curve;
    makeBezier(curve, Vec2(0.04f, 0.55f), Vec2(0.10f, 1.02f),
               Vec2(0.42f + sway * 0.01f, 1.10f), Vec2(0.62f + sway * 0.012f, 1.42f), 16);
    polyline(curve, A(stem), 0.10f, false);

    /* leaf */
    pushTransform(Vec2(0.72f, 1.30f), 24.0f + sway, 1.0f, 1.0f);
    fillEllipse(Vec2(0.16f, 0.06f), 0.26f, 0.12f, A(rgb(112, 158, 62)), 20);
    line(Vec2(-0.06f, 0.02f), Vec2(0.38f, 0.08f), A(shade(rgb(112, 158, 62), 0.7f)), 0.03f);
    popTransform();

    fillCircleGrad(Vec2(0.0f, 0.0f), 0.78f, A(mix(body, rgb(255, 140, 150), 0.25f)), A(bodyDeep), 32);
    fillEllipse(Vec2(-0.26f, 0.30f), 0.22f, 0.15f, A(withAlpha(rgb(255, 255, 255), 0.60f)), 18);
    fillEllipse(Vec2( 0.28f, -0.34f), 0.20f, 0.10f, A(withAlpha(rgb(255, 200, 200), 0.20f)), 18);
    fillCircle(Vec2(0.05f, 0.52f), 0.10f, A(shade(bodyDeep, 0.8f)), 12);
}

/* ---------------------------------------------------------- fruit slice */
static void drawFruitSlice(int variant, float time) {
    (void)time;
    Color rind   = rgb(236, 142,  38);
    Color pith   = rgb(255, 232, 196);
    Color flesh  = rgb(255, 172,  60);
    Color fleshD = rgb(236, 132,  30);
    if (variant % 3 == 1) { rind = rgb(206, 60, 74); flesh = rgb(240, 96, 110); fleshD = rgb(200, 54, 70); }
    if (variant % 3 == 2) { rind = rgb(158, 190, 52); flesh = rgb(206, 232, 118); fleshD = rgb(158, 196, 70); }

    fillCircle(Vec2(0.0f, 0.0f), 0.96f, A(rind), 40);
    fillCircle(Vec2(0.0f, 0.0f), 0.86f, A(pith), 40);

    for (int i = 0; i < 8; ++i) {
        float a0 = 45.0f * (float)i + 3.0f;
        float a1 = 45.0f * (float)(i + 1) - 3.0f;
        fillArc(Vec2(0.0f, 0.0f), 0.78f, a0, a1, A(flesh), 10);
        /* a faint radial crease so the segments read separately */
        float am = deg2rad((a0 + a1) * 0.5f);
        line(Vec2(0.0f, 0.0f), Vec2(std::cos(am) * 0.74f, std::sin(am) * 0.74f),
             A(withAlpha(fleshD, 0.45f)), 0.035f);
    }
    fillCircle(Vec2(0.0f, 0.0f), 0.13f, A(pith), 16);
    fillEllipse(Vec2(-0.30f, 0.34f), 0.26f, 0.16f, A(withAlpha(rgb(255, 255, 255), 0.28f)), 20);
}

/* ------------------------------------------------------ chocolate chunk */
static void drawChocolate(int variant, float time) {
    (void)time;
    Color top   = rgb(120,  76,  48);
    Color front = rgb( 82,  48,  28);
    Color side  = rgb( 62,  35,  20);
    if (variant % 3 == 1) { top = rgb(232, 216, 190); front = rgb(198, 176, 146); side = rgb(168, 146, 116); }
    if (variant % 3 == 2) { top = rgb(196, 128,  72); front = rgb(150,  90,  46); side = rgb(120,  70,  34); }

    float w = 0.72f, dpt = 0.34f, hgt = 0.40f;

    std::vector<Vec2> topFace;
    topFace.push_back(Vec2(-w,  0.10f));
    topFace.push_back(Vec2(-w + dpt,  0.10f + dpt * 0.62f));
    topFace.push_back(Vec2( w,        0.10f + dpt * 0.62f));
    topFace.push_back(Vec2( w - dpt,  0.10f));
    fillPoly(topFace, A(top));

    fillRect(-w, 0.10f - hgt, 2.0f * w - dpt, hgt, A(front));

    std::vector<Vec2> rightFace;
    rightFace.push_back(Vec2(w - dpt, 0.10f));
    rightFace.push_back(Vec2(w,       0.10f + dpt * 0.62f));
    rightFace.push_back(Vec2(w,       0.10f + dpt * 0.62f - hgt));
    rightFace.push_back(Vec2(w - dpt, 0.10f - hgt));
    fillPoly(rightFace, A(side));

    line(Vec2(-w, 0.10f), Vec2(w - dpt, 0.10f), A(withAlpha(shade(top, 1.25f), 0.6f)), 0.045f);
    fillRect(-w + 0.08f, 0.10f - hgt * 0.85f, 0.10f, hgt * 0.62f,
             A(withAlpha(rgb(255, 255, 255), 0.14f)));
}

/* ------------------------------------------------------------ candy gem */
static void drawGem(int variant, float time) {
    float hue = std::fmod(35.0f + (float)(variant % 6) * 58.0f, 360.0f);
    Color bright = hsv(hue, 0.62f, 1.00f);
    Color midC   = hsv(hue, 0.78f, 0.86f);
    Color deep   = hsv(hue, 0.86f, 0.60f);

    std::vector<Vec2> crown;
    makeRegularPolygon(crown, Vec2(0.0f, 0.24f), 0.72f, 6, 0.0f);
    for (size_t i = 0; i < crown.size(); ++i) crown[i].y = 0.24f + (crown[i].y - 0.24f) * 0.62f;
    fillPoly(crown, A(midC));

    /* the pavilion, a fan of triangles meeting at the point */
    for (size_t i = 0; i < crown.size(); ++i) {
        const Vec2& a = crown[i];
        const Vec2& b = crown[(i + 1) % crown.size()];
        if (a.y < 0.24f || b.y < 0.24f) {
            float k = 0.62f + 0.38f * hash11((float)i * 3.7f + (float)variant);
            fillTri(a, b, Vec2(0.0f, -0.86f), A(shade(deep, k)));
        }
    }
    fillPoly(crown, A(withAlpha(bright, 0.35f)));

    std::vector<Vec2> table;
    makeRegularPolygon(table, Vec2(0.0f, 0.26f), 0.34f, 6, 0.0f);
    for (size_t i = 0; i < table.size(); ++i) table[i].y = 0.26f + (table[i].y - 0.26f) * 0.62f;
    fillPoly(table, A(mix(bright, rgb(255, 255, 255), 0.35f)));
    polyline(crown, A(withAlpha(rgb(255, 255, 255), 0.45f)), 0.035f, true);

    float tw = 0.5f + 0.5f * std::sin(time * 3.2f + (float)variant * 1.7f);
    fillStar(Vec2(-0.30f, 0.44f), 0.22f + 0.08f * tw, 0.06f, 4, 0.0f,
             A(withAlpha(rgb(255, 255, 255), 0.55f + 0.35f * tw)));
}

/* --------------------------------------------------------------- candle */
static void drawCandle(int variant, float time) {
    Color waxA = rgb(255, 250, 244);
    Color waxB = rgb(238, 110, 140);
    if (variant % 3 == 1) { waxB = rgb(112, 186, 232); }
    if (variant % 3 == 2) { waxB = rgb(140, 206, 150); }

    float bodyW = 0.30f, bodyBot = -0.86f, bodyTop = 0.60f;

    /* body, with candy stripes drawn as slanted bands clipped to the body */
    fillRoundRect(-bodyW, bodyBot, bodyW * 2.0f, bodyTop - bodyBot, bodyW * 0.35f, A(waxA));
    for (int i = -3; i <= 5; ++i) {
        float y0 = bodyBot + (float)i * 0.30f;
        std::vector<Vec2> band;
        band.push_back(Vec2(-bodyW, clampf(y0,          bodyBot, bodyTop)));
        band.push_back(Vec2(-bodyW, clampf(y0 + 0.14f,  bodyBot, bodyTop)));
        band.push_back(Vec2( bodyW, clampf(y0 + 0.32f,  bodyBot, bodyTop)));
        band.push_back(Vec2( bodyW, clampf(y0 + 0.18f,  bodyBot, bodyTop)));
        fillPoly(band, A(waxB));
    }
    fillRect(-bodyW, bodyBot, bodyW * 0.55f, bodyTop - bodyBot,
             A(withAlpha(rgb(255, 255, 255), 0.22f)));
    fillEllipse(Vec2(0.0f, bodyTop), bodyW, bodyW * 0.34f, A(shade(waxA, 0.94f)), 20);
    strokeRoundRect(-bodyW, bodyBot, bodyW * 2.0f, bodyTop - bodyBot, bodyW * 0.35f,
                    A(withAlpha(rgb(160, 120, 140), 0.45f)), 0.035f);

    /* wick */
    line(Vec2(0.0f, bodyTop), Vec2(0.03f, bodyTop + 0.16f), A(rgb(60, 48, 44)), 0.055f);

    /* flame: two teardrops with a little independent flicker */
    float f1 = std::sin(time * 9.3f + (float)variant * 2.1f);
    float f2 = std::sin(time * 14.7f + (float)variant * 3.7f);
    float flick = 0.6f * f1 + 0.4f * f2;
    float tilt  = flick * 6.0f;
    float sy    = 1.0f + 0.10f * flick;
    Vec2  base(0.03f, bodyTop + 0.14f);

    fillCircleGrad(Vec2(base.x, base.y + 0.30f), 0.62f,
                   A(withAlpha(rgb(255, 190, 90), 0.30f)),
                   A(withAlpha(rgb(255, 160, 60), 0.0f)), 24);

    pushTransform(base, tilt, 1.0f, sy);
    std::vector<Vec2> flame;
    flame.push_back(Vec2( 0.00f, 0.72f));
    flame.push_back(Vec2( 0.17f, 0.34f));
    flame.push_back(Vec2( 0.15f, 0.10f));
    flame.push_back(Vec2( 0.00f, 0.00f));
    flame.push_back(Vec2(-0.15f, 0.10f));
    flame.push_back(Vec2(-0.17f, 0.34f));
    fillPolyGradV(flame, A(rgb(238, 96, 40)), A(rgb(255, 208, 80)));

    std::vector<Vec2> core;
    core.push_back(Vec2( 0.00f, 0.46f));
    core.push_back(Vec2( 0.09f, 0.24f));
    core.push_back(Vec2( 0.00f, 0.06f));
    core.push_back(Vec2(-0.09f, 0.24f));
    fillPolyGradV(core, A(withAlpha(rgb(120, 170, 255), 0.85f)), A(withAlpha(rgb(255, 255, 220), 0.95f)));
    popTransform();
}

/* ==========================================================================
 *  Dispatch
 * ========================================================================*/
void drawTopping(int type, Vec2 centre, float size, float rotDeg, int variant,
                 float time, float alpha) {
    g_alpha = clampf(alpha, 0.0f, 1.0f);
    pushTransform(centre, rotDeg, size, size);
    switch (type) {
        case TOP_BERRY:     drawBerry(variant, time);      break;
        case TOP_BISCUIT:   drawBiscuit(variant, time);    break;
        case TOP_PEANUT:    drawPeanut(variant, time);     break;
        case TOP_CHERRY:    drawCherry(variant, time);     break;
        case TOP_FRUIT:     drawFruitSlice(variant, time); break;
        case TOP_CHOCOLATE: drawChocolate(variant, time);  break;
        case TOP_GEM:       drawGem(variant, time);        break;
        case TOP_CANDLE:    drawCandle(variant, time);     break;
        default: break;
    }
    popTransform();
    g_alpha = 1.0f;
}

} /* namespace cake */

/* ===== wrapping.cpp ================================================== */
/* ============================================================================
 *  CakeLab  -  wrapping.cpp
 *  Stage four: how the finished cake is packaged.
 *
 *  Each style is built from the same primitives as the cake itself, which is
 *  the point of doing this stage last: the shape and colour routines written
 *  for stages one and two are simply called again with different parameters.
 *
 *  Anything that belongs behind the cake is drawn by drawWrapBehind, anything
 *  in front by drawWrapFront, so the packaging correctly surrounds the cake.
 * ==========================================================================*/

namespace cake {

using namespace gfx;

/* ==========================================================================
 *  Measurements taken from the current design
 * ========================================================================*/
struct Metrics {
    float cx;
    float halfW;        /* half width of the bottom tier, in pixels     */
    float halfWTop;     /* half width of the top tier                   */
    float frontY;       /* lowest point of the base outline on screen   */
    float backY;        /* highest point of the base outline on screen  */
    float topY;         /* elevation of the top surface                 */
    float topFrontY;    /* front edge of the top surface                */
    float topBackY;     /* back edge of the top surface                 */
    float height;
};

static Metrics measure(const Design& d, const Frame& f) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 48);

    float maxX = 0.0f, minY = 0.0f, maxY = 0.0f;
    for (size_t i = 0; i < unit.size(); ++i) {
        maxX = std::max(maxX, std::fabs(unit[i].x));
        minY = std::min(minY, unit[i].y);
        maxY = std::max(maxY, unit[i].y);
    }

    float sTop = layerScale(d, d.layers - 1);
    Metrics m;
    m.cx        = f.centre.x;
    m.halfW     = maxX * f.radius;
    m.halfWTop  = maxX * f.radius * sTop;
    m.frontY    = f.centre.y + minY * f.radius * f.squash;
    m.backY     = f.centre.y + maxY * f.radius * f.squash;
    m.topY      = f.centre.y + topElevation(d, f);
    m.topFrontY = m.topY + minY * f.radius * f.squash * sTop;
    m.topBackY  = m.topY + maxY * f.radius * f.squash * sTop;
    m.height    = m.topY - m.frontY;
    return m;
}

/*  Outward normal of edge i of a counter-clockwise unit outline.            */
static Vec2 edgeNormalLocal(const std::vector<Vec2>& unit, size_t i) {
    const Vec2& a = unit[i];
    const Vec2& b = unit[(i + 1) % unit.size()];
    return normalize(Vec2(b.y - a.y, -(b.x - a.x)));
}

/*  A band that hugs the front silhouette of the cake at a chosen height.
 *  Exactly the same extrusion the cake body uses, only much shorter.        */
static void frontBand(const Design& d, const Frame& f, float elevation,
                      float thickness, const Color& c, int layer) {
    std::vector<Vec2> unit;
    shapeOutlineUnit(unit, d, 64);
    float s = layerScale(d, layer);

    size_t n = unit.size();
    for (size_t i = 0; i < n; ++i) {
        Vec2 nrm = edgeNormalLocal(unit, i);
        if (nrm.y >= -0.02f) continue;
        size_t j = (i + 1) % n;

        Vec2 a(f.centre.x + unit[i].x * f.radius * s,
               f.centre.y + unit[i].y * f.radius * f.squash * s + elevation);
        Vec2 b(f.centre.x + unit[j].x * f.radius * s,
               f.centre.y + unit[j].y * f.radius * f.squash * s + elevation);

        float k = clampf(0.86f + 0.30f * (-nrm.x * -0.62f), 0.58f, 1.18f);
        glBegin(GL_QUADS);
        useColor(shade(c, k * 1.06f));
        glVertex2f(a.x, a.y);
        glVertex2f(b.x, b.y);
        useColor(shade(c, k * 0.78f));
        glVertex2f(b.x, b.y - thickness);
        glVertex2f(a.x, a.y - thickness);
        glEnd();
    }
}

/*  A short strip laid on the top surface running back from the front rim,
 *  so that a band coming up the front of the cake looks as though it carries
 *  on over the top instead of stopping dead at the edge.                    */
static void topStripNS(const Metrics& m, float halfWidth, float depth, const Color& c) {
    float yBack = lerpf(m.topFrontY, m.topBackY, depth);
    glBegin(GL_QUADS);
    useColor(shade(c, 0.80f));
    glVertex2f(m.cx - halfWidth, yBack);
    glVertex2f(m.cx + halfWidth, yBack);
    useColor(shade(c, 1.08f));
    glVertex2f(m.cx + halfWidth, m.topFrontY);
    glVertex2f(m.cx - halfWidth, m.topFrontY);
    glEnd();
}

/* ==========================================================================
 *  A ribbon bow, reused by three of the four styles
 * ========================================================================*/
static void drawBow(Vec2 c, float size, const Color& col, float time, float phase) {
    Color lite = mix(col, rgb(255, 255, 255), 0.28f);
    Color dark = shade(col, 0.68f);
    float breathe = 1.0f + 0.02f * std::sin(time * 1.8f + phase);

    /* tails first, so the loops sit on top of them */
    for (int s = -1; s <= 1; s += 2) {
        std::vector<Vec2> tail;
        makeBezier(tail,
                   Vec2(c.x, c.y - size * 0.10f),
                   Vec2(c.x + (float)s * size * 0.30f, c.y - size * 0.70f),
                   Vec2(c.x + (float)s * size * 0.28f, c.y - size * 1.10f),
                   Vec2(c.x + (float)s * size * 0.78f, c.y - size * 1.42f), 16);
        for (size_t i = 0; i + 1 < tail.size(); ++i) {
            float t = (float)i / (float)(tail.size() - 1);
            line(tail[i], tail[i + 1], mix(col, dark, t * 0.8f), size * (0.30f - 0.14f * t));
        }
        /* the notched end of a ribbon tail */
        Vec2 e = tail.back();
        fillTri(Vec2(e.x - (float)s * size * 0.16f, e.y + size * 0.12f),
                Vec2(e.x + (float)s * size * 0.14f, e.y + size * 0.02f),
                Vec2(e.x - (float)s * size * 0.02f, e.y - size * 0.16f), dark);
    }

    for (int s = -1; s <= 1; s += 2) {
        pushTransform(Vec2(c.x + (float)s * size * 0.44f, c.y + size * 0.16f),
                      (float)s * 24.0f, breathe, breathe);
        fillEllipse(Vec2(0.0f, 0.0f), size * 0.48f, size * 0.34f, col, 26);
        fillEllipse(Vec2(0.0f, size * 0.06f), size * 0.36f, size * 0.24f, lite, 24);
        fillEllipse(Vec2((float)-s * size * 0.16f, -size * 0.06f),
                    size * 0.20f, size * 0.14f, withAlpha(dark, 0.55f), 20);
        popTransform();
    }

    fillRoundRect(c.x - size * 0.20f, c.y - size * 0.16f,
                  size * 0.40f, size * 0.36f, size * 0.12f, dark);
    fillRoundRect(c.x - size * 0.14f, c.y - size * 0.10f,
                  size * 0.20f, size * 0.24f, size * 0.08f, withAlpha(lite, 0.65f));
}

/* ==========================================================================
 *  Style 1 : rope tie
 * ========================================================================*/
static void ropeBehind(const Design& d, const Frame& f, const Color& c) {
    Metrics m = measure(d, f);
    /* the part of the vertical band that passes over the top and down the
       back of the cake; almost all of it ends up hidden, which is correct  */
    float bw = std::max(9.0f, m.halfW * 0.085f);
    fillRect(m.cx - bw, m.backY - 6.0f, bw * 2.0f,
             m.topY - m.backY + 10.0f, shade(c, 0.50f));
}

static void ropeFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    float bw = std::max(9.0f, m.halfW * 0.085f);

    /*  One band runs round the waist of the cake, following the silhouette
     *  exactly as the cake body does. The other comes up the front and over
     *  the rim. They cross at the front, where the bow is tied.             */
    float elev  = f.layerHeight * 0.58f;
    float thick = std::max(13.0f, f.layerHeight * 0.24f);
    frontBand(d, f, elev, thick, c, 0);
    frontBand(d, f, elev - thick * 0.26f, thick * 0.13f, shade(c, 0.58f), 0);
    if (d.layers > 1)
        frontBand(d, f, f.layerHeight * (float)(d.layers - 1) + f.layerHeight * 0.58f,
                  thick * 0.70f, c, d.layers - 1);

    /* the vertical band, from the plate up to the top rim and a little over */
    float yTop = m.topFrontY;
    float yBot = m.frontY - 4.0f;
    fillRectGradH(m.cx - bw, yBot, bw * 2.0f, yTop - yBot,
                  shade(c, 0.68f), mix(c, rgb(255, 255, 255), 0.22f));
    topStripNS(m, bw, 0.30f, c);

    /*  The twine texture that makes it read as a rope rather than a ribbon. */
    int turns = (int)((yTop - yBot) / (bw * 0.70f));
    for (int i = 0; i <= turns; ++i) {
        float y = yBot + (float)i * bw * 0.70f;
        line(Vec2(m.cx - bw, y), Vec2(m.cx + bw, y + bw * 0.40f),
             withAlpha(shade(c, 0.58f), 0.50f), 1.6f);
    }

    drawBow(Vec2(m.cx, f.centre.y + elev - thick * 0.28f),
            std::max(18.0f, m.halfW * 0.24f), c, time, 0.0f);
}

/* ==========================================================================
 *  Style 2 : gift box with a window
 * ========================================================================*/
static void boxGeometry(const Metrics& m, float& x0, float& x1,
                        float& yBot, float& frontTop, float& backTop) {
    float pad = m.halfW * 0.22f;
    x0       = m.cx - m.halfW - pad;
    x1       = m.cx + m.halfW + pad;
    yBot     = m.frontY - m.height * 0.12f;
    frontTop = yBot + m.height * 0.60f;
    backTop  = yBot + m.height * 0.78f;
}

static void boxBehind(const Design& d, const Frame& f, const Color& c) {
    Metrics m = measure(d, f);
    float x0, x1, yBot, frontTop, backTop;
    boxGeometry(m, x0, x1, yBot, frontTop, backTop);

    /*  The lid, leaning back from the top edge of the rear wall. It is built
     *  as an explicit quad rather than a rotation, so its far corner cannot
     *  swing away from the hinge however wide the box happens to be.        */
    float lidH  = m.height * 0.50f;
    float lean  = 20.0f;
    Vec2  up(std::sin(deg2rad(lean)) * lidH, std::cos(deg2rad(lean)) * lidH);
    Vec2  hingeA(x0 - 4.0f, backTop);
    Vec2  hingeB(x1 + 4.0f, backTop);

    std::vector<Vec2> lid;
    lid.push_back(hingeA);
    lid.push_back(hingeB);
    lid.push_back(hingeB + up);
    lid.push_back(hingeA + up);
    fillPolyGradV(lid, shade(c, 0.52f), shade(c, 0.80f));

    Vec2 ra = hingeA + (hingeB - hingeA) * 0.44f;
    Vec2 rb = hingeA + (hingeB - hingeA) * 0.56f;
    std::vector<Vec2> stripe;
    stripe.push_back(ra);
    stripe.push_back(rb);
    stripe.push_back(rb + up);
    stripe.push_back(ra + up);
    fillPoly(stripe, shade(c, 1.05f));
    polyline(lid, shade(c, 0.40f), 2.0f, true);

    /* rear wall */
    fillRectGradV(x0, yBot, x1 - x0, backTop - yBot, shade(c, 0.40f), shade(c, 0.60f));
    strokeRect(x0, yBot, x1 - x0, backTop - yBot, shade(c, 0.32f), 1.6f);

    /*  Inner side walls, splayed slightly outwards so the box reads as open. */
    float splay = m.halfW * 0.10f;
    for (int s = -1; s <= 1; s += 2) {
        float xin  = (s < 0) ? x0 : x1;
        float xout = xin + (float)s * splay;
        std::vector<Vec2> wall;
        wall.push_back(Vec2(xin,  yBot));
        wall.push_back(Vec2(xout, yBot - m.height * 0.03f));
        wall.push_back(Vec2(xout, frontTop + m.height * 0.10f));
        wall.push_back(Vec2(xin,  backTop));
        fillPolyGradV(wall, shade(c, 0.46f), shade(c, 0.72f));
        polyline(wall, shade(c, 0.34f), 1.4f, true);
    }

    /* a shadow inside the box so the cake sits in something */
    fillRectGradV(x0, yBot, x1 - x0, (backTop - yBot) * 0.5f,
                  withAlpha(rgb(0, 0, 0), 0.40f), withAlpha(rgb(0, 0, 0), 0.0f));
}

static void boxFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    float x0, x1, yBot, frontTop, backTop;
    boxGeometry(m, x0, x1, yBot, frontTop, backTop);
    (void)backTop;

    float bandH = (frontTop - yBot) * 0.20f;      /* solid strip at the base */
    float wx0 = x0 + (x1 - x0) * 0.07f;
    float wx1 = x1 - (x1 - x0) * 0.07f;
    float wy0 = yBot + bandH + (frontTop - yBot) * 0.06f;
    float wy1 = frontTop - (frontTop - yBot) * 0.10f;

    /*  The front wall is drawn as a frame of four rectangles so that the
     *  window in the middle is left clear and the cake shows through.       */
    fillRectGradV(x0, yBot, x1 - x0, wy0 - yBot, shade(c, 0.70f), shade(c, 0.94f));
    fillRectGradV(x0, wy1, x1 - x0, frontTop - wy1, shade(c, 0.96f), shade(c, 1.06f));
    fillRectGradV(x0, wy0, wx0 - x0, wy1 - wy0, shade(c, 0.76f), shade(c, 0.98f));
    fillRectGradV(wx1, wy0, x1 - wx1, wy1 - wy0, shade(c, 0.76f), shade(c, 0.98f));

    /* a suggestion of glass across the opening */
    fillRectGradV(wx0, wy0, wx1 - wx0, wy1 - wy0,
                  withAlpha(rgb(255, 255, 255), 0.03f),
                  withAlpha(rgb(255, 255, 255), 0.10f));
    for (int i = 0; i < 2; ++i) {
        float gx = wx0 + (wx1 - wx0) * (0.12f + 0.26f * (float)i);
        float sl = (wy1 - wy0) * 0.30f;
        std::vector<Vec2> streak;
        streak.push_back(Vec2(gx, wy0));
        streak.push_back(Vec2(gx + sl, wy1));
        streak.push_back(Vec2(gx + sl + 12.0f, wy1));
        streak.push_back(Vec2(gx + 12.0f, wy0));
        fillPoly(streak, withAlpha(rgb(255, 255, 255), 0.06f));
    }
    strokeRect(wx0, wy0, wx1 - wx0, wy1 - wy0, withAlpha(shade(c, 0.48f), 0.95f), 2.2f);

    /* outer edges, then the ribbon band along the base with its bow */
    strokeRect(x0, yBot, x1 - x0, frontTop - yBot, shade(c, 0.42f), 2.0f);
    fillRectGradV(x0, yBot + bandH * 0.16f, x1 - x0, bandH * 0.68f,
                  shade(c, 0.56f), mix(c, rgb(255, 255, 255), 0.30f));
    drawBow(Vec2(m.cx, yBot + bandH * 0.52f), std::max(16.0f, m.halfW * 0.20f),
            mix(c, rgb(255, 255, 255), 0.22f), time, 1.2f);
}

/* ==========================================================================
 *  Style 3 : wrapping sheet
 * ========================================================================*/
static void sheetPetals(const Design& d, const Frame& f, const Color& c,
                        bool behind, float time) {
    Metrics m = measure(d, f);
    Vec2 knot(m.cx, m.frontY - m.height * 0.16f);
    int  n = 9;

    for (int i = 0; i < n; ++i) {
        float t   = (float)i / (float)(n - 1);
        float ang = lerpf(196.0f, -16.0f, t);
        bool isBack = (ang > 40.0f && ang < 140.0f);
        if (isBack != behind) continue;

        float len   = m.height * (1.18f + 0.30f * std::sin(t * PI));
        float spread= 13.0f;
        float wob   = std::sin(time * 0.9f + (float)i) * 1.2f;

        Vec2 tip  = knot + Vec2(std::cos(deg2rad(ang + wob)), std::sin(deg2rad(ang + wob))) * len;
        Vec2 sideA= knot + Vec2(std::cos(deg2rad(ang - spread)), std::sin(deg2rad(ang - spread))) * (len * 0.86f);
        Vec2 sideB= knot + Vec2(std::cos(deg2rad(ang + spread)), std::sin(deg2rad(ang + spread))) * (len * 0.86f);

        Color petal = shade(c, behind ? 0.62f : (0.86f + 0.20f * hash11((float)i * 2.3f)));
        std::vector<Vec2> p;
        p.push_back(knot);
        p.push_back(sideA);
        p.push_back(tip);
        p.push_back(sideB);
        fillPoly(p, petal);
        polyline(p, withAlpha(shade(petal, 0.72f), 0.75f), 1.4f, true);
        line(knot, tip, withAlpha(shade(petal, 1.20f), 0.45f), 2.0f);

        /* polka dots on the visible side of the sheet */
        if (!behind) {
            for (int k = 1; k <= 3; ++k) {
                float u = 0.28f * (float)k;
                Vec2 q = knot + (tip - knot) * u;
                fillCircle(q, m.height * 0.022f,
                           withAlpha(rgb(255, 255, 255), 0.30f), 10);
            }
        }
    }
}

static void sheetFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    sheetPetals(d, f, c, false, time);

    /* the gathered twist at the bottom, plus a tie */
    Vec2 knot(m.cx, m.frontY - m.height * 0.16f);
    float kr = m.halfW * 0.24f;
    fillEllipseGrad(knot, kr, kr * 0.72f, mix(c, rgb(255, 255, 255), 0.20f), shade(c, 0.55f), 28);
    for (int i = 0; i < 5; ++i) {
        float a = deg2rad(lerpf(200.0f, -20.0f, (float)i / 4.0f));
        line(knot, knot + Vec2(std::cos(a), std::sin(a)) * (kr * 0.92f),
             withAlpha(shade(c, 0.62f), 0.6f), 1.6f);
    }
    drawBow(Vec2(knot.x, knot.y + kr * 0.30f), kr * 0.78f, shade(c, 1.12f), time, 2.4f);
}

/* ==========================================================================
 *  Style 4 : waist ribbon and gift tag
 * ========================================================================*/
static void ribbonFront(const Design& d, const Frame& f, const Color& c, float time) {
    Metrics m = measure(d, f);
    int   layer = 0;
    float elev  = f.layerHeight * 0.62f;
    float thick = std::max(12.0f, f.layerHeight * 0.30f);

    frontBand(d, f, elev, thick, c, layer);
    frontBand(d, f, elev - thick * 0.30f, thick * 0.14f, shade(c, 0.55f), layer);

    /* if the cake is tiered, tie the upper tier as well */
    if (d.layers > 1)
        frontBand(d, f, f.layerHeight * (float)(d.layers - 1) + f.layerHeight * 0.60f,
                  thick * 0.72f, c, d.layers - 1);

    float bowSize = std::max(18.0f, m.halfW * 0.26f);
    drawBow(Vec2(m.cx, f.centre.y + elev - thick * 0.35f), bowSize, c, time, 0.6f);

    /* a small tag on a string, swinging gently */
    float swing = std::sin(time * 1.4f) * 5.0f;
    Vec2  anchor(m.cx + bowSize * 0.70f, f.centre.y + elev - thick * 0.30f);
    pushTransform(anchor, swing, 1.0f, 1.0f);
    line(Vec2(0.0f, 0.0f), Vec2(bowSize * 0.30f, -bowSize * 0.62f),
         withAlpha(rgb(250, 246, 240), 0.85f), 1.6f);
    pushTransform(Vec2(bowSize * 0.30f, -bowSize * 0.62f), -16.0f, 1.0f, 1.0f);
    fillRoundRect(-bowSize * 0.10f, -bowSize * 0.62f, bowSize * 0.86f, bowSize * 0.62f,
                  bowSize * 0.10f, rgb(252, 248, 238));
    strokeRoundRect(-bowSize * 0.10f, -bowSize * 0.62f, bowSize * 0.86f, bowSize * 0.62f,
                    bowSize * 0.10f, rgb(196, 178, 158), 1.2f);
    fillCircle(Vec2(bowSize * 0.02f, -bowSize * 0.14f), bowSize * 0.055f, rgb(196, 178, 158), 10);
    for (int i = 0; i < 2; ++i)
        fillRect(bowSize * 0.14f, -bowSize * (0.34f + 0.14f * (float)i),
                 bowSize * 0.52f, bowSize * 0.055f, withAlpha(rgb(150, 120, 130), 0.75f));
    popTransform();
    popTransform();
}

/* ==========================================================================
 *  Entry points
 * ========================================================================*/
void drawWrapBehind(const Design& d, const Frame& f, float time) {
    Color c = wrapPaletteColor(d.wrapColor);
    switch (d.wrap) {
        case WRAP_ROPE:  ropeBehind(d, f, c);                 break;
        case WRAP_BOX:   boxBehind(d, f, c);                  break;
        case WRAP_SHEET: sheetPetals(d, f, c, true, time);    break;
        case WRAP_RIBBON:                                     break;
        default: break;
    }
}

void drawWrapFront(const Design& d, const Frame& f, float time) {
    Color c = wrapPaletteColor(d.wrapColor);
    switch (d.wrap) {
        case WRAP_ROPE:   ropeFront(d, f, c, time);   break;
        case WRAP_BOX:    boxFront(d, f, c, time);    break;
        case WRAP_SHEET:  sheetFront(d, f, c, time);  break;
        case WRAP_RIBBON: ribbonFront(d, f, c, time); break;
        default: break;
    }
}

/* ==========================================================================
 *  Small pictograms for the option buttons
 * ========================================================================*/
void drawWrapIcon(int wrapId, Vec2 c, float size, const Color& tint, float time) {
    Color dark = shade(tint, 0.62f);
    switch (wrapId) {
        case WRAP_NONE:
            strokeCircle(c, size * 0.82f, withAlpha(tint, 0.75f), 1.8f, 28);
            line(Vec2(c.x - size * 0.52f, c.y - size * 0.52f),
                 Vec2(c.x + size * 0.52f, c.y + size * 0.52f), withAlpha(tint, 0.75f), 1.8f);
            break;
        case WRAP_ROPE:
            fillRoundRect(c.x - size * 0.78f, c.y - size * 0.66f, size * 1.56f, size * 1.32f,
                          size * 0.16f, shade(tint, 0.86f));
            fillRect(c.x - size * 0.12f, c.y - size * 0.66f, size * 0.24f, size * 1.32f, tint);
            fillRect(c.x - size * 0.78f, c.y - size * 0.12f, size * 1.56f, size * 0.24f, tint);
            fillCircle(c, size * 0.20f, dark, 14);
            break;
        case WRAP_BOX:
            fillRect(c.x - size * 0.80f, c.y - size * 0.72f, size * 1.60f, size * 1.16f, shade(tint, 0.80f));
            fillRect(c.x - size * 0.92f, c.y + size * 0.40f, size * 1.84f, size * 0.32f, tint);
            fillRect(c.x - size * 0.44f, c.y - size * 0.44f, size * 0.88f, size * 0.68f,
                     withAlpha(rgb(255, 255, 255), 0.35f));
            break;
        case WRAP_SHEET: {
            for (int i = 0; i < 5; ++i) {
                float a = deg2rad(lerpf(200.0f, -20.0f, (float)i / 4.0f));
                std::vector<Vec2> p;
                p.push_back(Vec2(c.x, c.y - size * 0.72f));
                p.push_back(Vec2(c.x + std::cos(a - 0.20f) * size * 1.10f,
                                 c.y - size * 0.72f + std::sin(a - 0.20f) * size * 1.10f));
                p.push_back(Vec2(c.x + std::cos(a + 0.20f) * size * 1.10f,
                                 c.y - size * 0.72f + std::sin(a + 0.20f) * size * 1.10f));
                fillPoly(p, shade(tint, 0.70f + 0.12f * (float)(i % 3)));
            }
            fillCircle(Vec2(c.x, c.y - size * 0.72f), size * 0.22f, dark, 14);
            break;
        }
        case WRAP_RIBBON:
            fillRoundRect(c.x - size * 0.86f, c.y - size * 0.30f, size * 1.72f, size * 0.34f,
                          size * 0.10f, shade(tint, 0.80f));
            drawBow(Vec2(c.x, c.y + size * 0.16f), size * 0.62f, tint, time, 0.0f);
            break;
        default: break;
    }
}

} /* namespace cake */

/* ===== screenshot.cpp ================================================ */
/* ============================================================================
 *  CakeLab  -  screenshot.cpp
 * ==========================================================================*/

namespace shot {

static void put16(unsigned char* p, unsigned short v) {
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
}

static void put32(unsigned char* p, unsigned int v) {
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
    p[2] = (unsigned char)((v >> 16) & 0xFF);
    p[3] = (unsigned char)((v >> 24) & 0xFF);
}

bool saveBMP(const std::string& path, int x, int y, int w, int h) {
    if (w <= 0 || h <= 0) return false;

    std::vector<unsigned char> rgbData((size_t)w * (size_t)h * 3, 0);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadBuffer(GL_FRONT);
    glReadPixels(x, y, w, h, GL_RGB, GL_UNSIGNED_BYTE, &rgbData[0]);

    /*  BMP rows are padded to a multiple of four bytes and are stored bottom
     *  up, which is the order glReadPixels already returns.                  */
    int rowRaw = w * 3;
    int rowPad = (4 - (rowRaw % 4)) % 4;
    int rowSize = rowRaw + rowPad;
    unsigned int imageSize = (unsigned int)rowSize * (unsigned int)h;
    unsigned int fileSize = 54u + imageSize;

    unsigned char header[54];
    std::memset(header, 0, sizeof(header));
    header[0] = 'B'; header[1] = 'M';
    put32(header + 2, fileSize);
    put32(header + 10, 54u);           /* pixel data offset */
    put32(header + 14, 40u);           /* DIB header size   */
    put32(header + 18, (unsigned int)w);
    put32(header + 22, (unsigned int)h);
    put16(header + 26, 1);             /* colour planes     */
    put16(header + 28, 24);            /* bits per pixel    */
    put32(header + 34, imageSize);
    put32(header + 38, 2835u);         /* 72 dpi, pixels per metre */
    put32(header + 42, 2835u);

    std::FILE* fp = std::fopen(path.c_str(), "wb");
    if (!fp) return false;
    std::fwrite(header, 1, sizeof(header), fp);

    std::vector<unsigned char> row((size_t)rowSize, 0);
    for (int r = 0; r < h; ++r) {
        const unsigned char* src = &rgbData[(size_t)r * (size_t)w * 3];
        for (int c = 0; c < w; ++c) {                 /* RGB -> BGR */
            row[(size_t)c * 3 + 0] = src[(size_t)c * 3 + 2];
            row[(size_t)c * 3 + 1] = src[(size_t)c * 3 + 1];
            row[(size_t)c * 3 + 2] = src[(size_t)c * 3 + 0];
        }
        for (int p = 0; p < rowPad; ++p) row[(size_t)rowRaw + (size_t)p] = 0;
        std::fwrite(&row[0], 1, (size_t)rowSize, fp);
    }
    std::fclose(fp);
    return true;
}

std::string nextFilename() {
    char buf[64];
    for (int i = 1; i < 1000; ++i) {
        std::sprintf(buf, "cakelab_%03d.bmp", i);
        std::FILE* fp = std::fopen(buf, "rb");
        if (!fp) return std::string(buf);
        std::fclose(fp);
    }
    return std::string("cakelab_overflow.bmp");
}

} /* namespace shot */

/* ===== stage_shape.cpp =============================================== */
/* ============================================================================
 *  CakeLab  -  stage_shape.cpp
 *  Stage 1 of 4  -  Shape selection.
 *  Group member 1.
 *
 *  The user picks the base shape of the cake. Every shape is produced by the
 *  outline generators in gfx.h: the round cake comes from a parametric point
 *  loop, the polygon from the regular polygon generator, and the straight
 *  sided shapes from their corner lists. Nothing calls a built-in circle.
 *
 *  Two extra controls belong to this stage because they change the geometry
 *  rather than the decoration: the number of sides when the polygon shape is
 *  chosen, and the number of stacked tiers.
 * ==========================================================================*/

namespace app {

using namespace gfx;

/* option ids are the shape enum itself; the chips use offset ranges */
static const int ID_SIDES_BASE  = 100;
static const int ID_LAYERS_BASE = 200;

static float s_sidesLabelY  = 0.0f;
static float s_layersLabelY = 0.0f;

/* --------------------------------------------------------------- icons */
static void shapeIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    cake::drawShapeIcon(arg, g_design.polySides, c, size * 0.92f, fl.cream);
}

static void tierIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    int n = arg;
    for (int i = 0; i < n; ++i) {
        float k = std::pow(0.72f, (float)i);
        float w = size * 1.30f * k;
        float h = size * 0.34f;
        fillRoundRect(c.x - w * 0.5f, c.y - size * 0.62f + (float)i * h * 1.06f,
                      w, h * 0.92f, h * 0.22f, fl.sponge);
    }
}

/* --------------------------------------------------------------- build */
static void shapeBuild() {
    g_options.clear();
    g_extras.clear();

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;

    for (int i = 0; i < cake::SHAPE_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::shapeDef(i).name;
        b.sub      = cake::shapeDef(i).note;
        b.icon     = shapeIcon;
        b.iconArg  = i;
        b.selected = (g_design.shape == i);
        g_options.push_back(b);
    }

    float rowH = 56.0f, gap = 9.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float y = panelListTop() - (rowH + gap) * (float)cake::SHAPE_COUNT;

    /* sides of the polygon, only meaningful for the polygon shape */
    s_sidesLabelY = y - 22.0f;
    y = s_sidesLabelY - 12.0f;
    for (int s = 5; s <= 8; ++s) {
        ui::Button b;
        b.id      = ID_SIDES_BASE + s;
        b.style   = ui::BTN_CHIP;
        char buf[8];
        std::sprintf(buf, "%d", s);
        b.label   = buf;
        b.enabled = (g_design.shape == cake::SHAPE_POLYGON);
        b.selected= (g_design.polySides == s) && b.enabled;
        g_extras.push_back(b);
    }
    layoutChips(g_extras, x, y, (w - 3.0f * 10.0f) / 4.0f, 32.0f, 10.0f, 4);

    /* stacked tiers */
    size_t firstTier = g_extras.size();
    s_layersLabelY = (y - 32.0f) - 24.0f;
    float ty = s_layersLabelY - 12.0f;
    const char* tierNames[3] = { "1 tier", "2 tiers", "3 tiers" };
    for (int i = 0; i < 3; ++i) {
        ui::Button b;
        b.id       = ID_LAYERS_BASE + (i + 1);
        b.style    = ui::BTN_CHIP;
        b.label    = tierNames[i];
        b.icon     = tierIcon;
        b.iconArg  = i + 1;
        b.selected = (g_design.layers == i + 1);
        g_extras.push_back(b);
    }
    std::vector<ui::Button> tail(g_extras.begin() + (long)firstTier, g_extras.end());
    layoutChips(tail, x, ty, (w - 2.0f * 10.0f) / 3.0f, 40.0f, 10.0f, 3);
    for (size_t i = 0; i < tail.size(); ++i) g_extras[firstTier + i] = tail[i];
}

/* -------------------------------------------------------------- events */
static void shapeOnOption(int id) {
    g_design.shape = id;
    if (id == cake::SHAPE_POLYGON)
        ui::toast(std::string("Polygon with ") + (char)('0' + g_design.polySides) + " sides");
    else
        ui::toast(std::string(cake::shapeDef(id).name) + " base selected");

    /* toppings are positioned in shape space, so clear any that now fall
       outside the new outline                                              */
    size_t before = g_design.toppings.size();
    std::vector<cake::Placed> keep;
    for (size_t i = 0; i < g_design.toppings.size(); ++i) {
        Vec2 uv(g_design.toppings[i].u, g_design.toppings[i].v);
        if (cake::insideUnitShape(g_design, uv)) keep.push_back(g_design.toppings[i]);
    }
    g_design.toppings = keep;
    if (keep.size() != before)
        ui::toast("Trimmed toppings that fell outside the new shape");

    rebuildStage();
}

static void shapeOnExtra(int id) {
    if (id > ID_LAYERS_BASE) {
        g_design.layers = id - ID_LAYERS_BASE;
        char buf[48];
        std::sprintf(buf, "%d tier cake", g_design.layers);
        ui::toast(buf);
    } else if (id > ID_SIDES_BASE) {
        g_design.polySides = id - ID_SIDES_BASE;
        g_design.shape = cake::SHAPE_POLYGON;
        char buf[48];
        std::sprintf(buf, "Regular polygon, %d sides", g_design.polySides);
        ui::toast(buf);
    }
    rebuildStage();
}

static void shapeDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    bool  poly = (g_design.shape == cake::SHAPE_POLYGON);
    ui::drawSectionLabel(x, s_sidesLabelY,
                         poly ? "NUMBER OF SIDES" : "NUMBER OF SIDES  (polygon only)");
    ui::drawSectionLabel(x, s_layersLabelY, "STACKED TIERS");
}

/*  The preview gains a small annotation showing how the outline was made.   */
static void shapeDrawPreviewOverlay() {
    cake::Frame f = previewFrame();
    std::vector<Vec2> unit;
    cake::shapeOutlineUnit(unit, g_design, 72);

    int corners = 0;
    switch (g_design.shape) {
        case cake::SHAPE_CIRCLE:   corners = 0; break;
        case cake::SHAPE_TRIANGLE: corners = 3; break;
        case cake::SHAPE_SQUARE:   corners = 4; break;
        case cake::SHAPE_RECT:     corners = 4; break;
        case cake::SHAPE_POLYGON:  corners = g_design.polySides; break;
        default: break;
    }

    /* mark the generated vertices so the point loop is visible */
    float sTop = cake::layerScale(g_design, g_design.layers - 1);
    Vec2  c    = cake::topCentre(g_design, f);
    for (size_t i = 0; i < unit.size(); i += (corners > 0 ? 4 : 6)) {
        Vec2 p(f.centre.x + unit[i].x * f.radius * sTop,
               f.centre.y + unit[i].y * f.radius * f.squash * sTop +
               cake::topElevation(g_design, f));
        fillCircle(p, 2.0f, withAlpha(rgb(255, 255, 255), 0.30f), 8);
    }

    char buf[128];
    if (corners == 0)
        std::sprintf(buf, "Round base: 72 points from x = r cos t, y = r sin t");
    else
        std::sprintf(buf, "%d corner base, edges subdivided into %d points",
                     corners, (int)unit.size());
    (void)c;
    textRight(previewCaptionRight(), previewCaptionY(0), buf,
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool shapeCanAdvance() { return true; }

/* --------------------------------------------------------------- table */
const StageDef& stageShape() {
    static StageDef s = {
        "shape",
        "Choose the base shape",
        "Stage 1 of 4",
        "Every outline is generated point by point, not by a built-in shape call.",
        shapeBuild, shapeOnOption, shapeOnExtra, shapeDrawPanelExtra, shapeDrawPreviewOverlay,
        0, 0, shapeCanAdvance
    };
    return s;
}

} /* namespace app */

/* ===== stage_flavor.cpp ============================================== */
/* ============================================================================
 *  CakeLab  -  stage_flavor.cpp
 *  Stage 2 of 4  -  Flavour and colour selection.
 *  Group member 2.
 *
 *  This is the colour model stage. Each flavour is a small palette: a sponge
 *  colour, a filling colour, a frosting colour and a drip colour, all stored
 *  as RGB triples. Choosing a flavour swaps the palette and the whole cake is
 *  redrawn from it, which shows directly how one colour table drives every
 *  primitive on screen.
 *
 *  The panel also prints the exact RGB components of the current frosting so
 *  the numeric side of the model is visible, not just the result.
 * ==========================================================================*/

namespace app {

using namespace gfx;

static float s_readoutY = 0.0f;

/*  The swatch shows the three main colours of the flavour stacked together. */
static void flavorIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    const cake::FlavorDef& fl = cake::flavorDef(arg);
    float s = size * 1.05f;
    fillRoundRect(c.x - s, c.y - s, s * 2.0f, s * 0.72f, s * 0.20f, fl.sponge);
    fillRect(c.x - s, c.y - s * 0.30f, s * 2.0f, s * 0.40f, fl.filling);
    fillRoundRect(c.x - s, c.y + s * 0.12f, s * 2.0f, s * 0.86f, s * 0.20f, fl.cream);
    fillCircle(Vec2(c.x + s * 0.46f, c.y + s * 0.52f), s * 0.24f, fl.accent, 14);
    strokeRoundRect(c.x - s, c.y - s, s * 2.0f, s * 2.0f, s * 0.20f,
                    withAlpha(rgb(0, 0, 0), 0.22f), 1.1f);
}

static void flavourBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::FLV_COUNT; ++i) {
        const cake::FlavorDef& fl = cake::flavorDef(i);
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = fl.name;
        b.sub      = fl.note;
        b.icon     = flavorIcon;
        b.iconArg  = i;
        b.tint     = fl.cream;
        b.selected = (g_design.flavor == i);
        g_options.push_back(b);
    }

    float rowH = 41.0f, gap = 5.0f;
    layoutRows(g_options, rowH, gap, panelListTop());
    s_readoutY = panelListTop() - (rowH + gap) * (float)cake::FLV_COUNT - 22.0f;
}

static void flavourOnOption(int id) {
    g_design.flavor = id;
    ui::toast(std::string(cake::flavorDef(id).name) + " selected");
    rebuildStage();
}

static void flavourOnExtra(int id) { (void)id; }

/*  A small bar chart of the red, green and blue components of the frosting. */
static void drawChannelBar(float x, float y, float w, const char* label,
                           float value, const Color& barColor) {
    float h = 9.0f;
    text(x, y - 2.0f, label, ui::T.textFaint, FONT_XS);
    float bx = x + 16.0f;
    float bw = w - 16.0f - 44.0f;
    fillRoundRect(bx, y - 1.0f, bw, h, h * 0.5f, withAlpha(ui::T.panelEdge, 0.65f));
    fillRoundRect(bx, y - 1.0f, bw * clampf(value, 0.0f, 1.0f), h, h * 0.5f, barColor);
    char buf[16];
    std::sprintf(buf, "%3d", (int)(value * 255.0f + 0.5f));
    text(bx + bw + 8.0f, y - 2.0f, buf, ui::T.textDim, FONT_XS);
}

static void flavourDrawPanelExtra() {
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;

    ui::drawSectionLabel(x, s_readoutY, "FROSTING COLOUR, RGB MODEL");
    float y = s_readoutY - 20.0f;

    drawChannelBar(x, y,          w, "R", fl.cream.r, rgb(236,  86,  86));
    drawChannelBar(x, y - 17.0f,  w, "G", fl.cream.g, rgb( 96, 214, 126));
    drawChannelBar(x, y - 34.0f,  w, "B", fl.cream.b, rgb( 96, 156, 236));

    char hex[32];
    std::sprintf(hex, "#%02X%02X%02X",
                 (int)(fl.cream.r * 255.0f + 0.5f),
                 (int)(fl.cream.g * 255.0f + 0.5f),
                 (int)(fl.cream.b * 255.0f + 0.5f));
    fillRoundRect(x, y - 62.0f, 22.0f, 16.0f, 4.0f, fl.cream);
    strokeRoundRect(x, y - 62.0f, 22.0f, 16.0f, 4.0f, withAlpha(rgb(0, 0, 0), 0.3f), 1.0f);
    text(x + 30.0f, y - 59.0f, hex, ui::T.textDim, FONT_S);
}

/*  Under the cake, the full palette that the flavour supplies.              */
static void flavourDrawPreviewOverlay() {
    cake::Frame f = previewFrame();
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);

    struct Sw { const char* name; Color c; };
    Sw swatches[5] = {
        { "sponge",  fl.sponge  },
        { "filling", fl.filling },
        { "frosting",fl.cream   },
        { "drip",    fl.drip    },
        { "accent",  fl.accent  }
    };

    float chipW = 78.0f, chipH = 34.0f, gap = 10.0f;
    float total = chipW * 5.0f + gap * 4.0f;
    float x0 = f.centre.x - total * 0.5f;
    float y0 = L.previewY + 58.0f;

    for (int i = 0; i < 5; ++i) {
        float x = x0 + (chipW + gap) * (float)i;
        fillRoundRect(x, y0, chipW, chipH, 8.0f, swatches[i].c);
        strokeRoundRect(x, y0, chipW, chipH, 8.0f, withAlpha(rgb(0, 0, 0), 0.28f), 1.1f);
        textCentered(x + chipW * 0.5f, y0 + chipH + 8.0f, swatches[i].name,
                     ui::T.textFaint, FONT_XS);
    }
    textRight(previewCaptionRight(), previewCaptionY(0),
              "One palette drives every primitive on the cake",
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool flavourCanAdvance() { return true; }

const StageDef& stageFlavor() {
    static StageDef s = {
        "flavor",
        "Pick a flavour",
        "Stage 2 of 4",
        "Each flavour is a small RGB palette applied to the whole cake.",
        flavourBuild, flavourOnOption, flavourOnExtra, flavourDrawPanelExtra, flavourDrawPreviewOverlay,
        0, 0, flavourCanAdvance
    };
    return s;
}

} /* namespace app */

/* ===== stage_toppings.cpp ============================================ */
/* ============================================================================
 *  CakeLab  -  stage_toppings.cpp
 *  Stage 3 of 4  -  Ingredient placement.
 *  Group member 3.
 *
 *  This is the transformation stage. Each ingredient is a composite object
 *  built at the origin in its own coordinates; putting one on the cake is a
 *  translation to the clicked point, plus a small rotation and scale so that
 *  no two pieces look identical.
 *
 *  Positions are stored in the unit coordinate space of the base shape rather
 *  than in pixels, so the decoration survives a change of shape, a change of
 *  tier count and a change of window size.
 * ==========================================================================*/

namespace app {

using namespace gfx;

static const int ID_UNDO    = 300;
static const int ID_CLEAR   = 301;
static const int ID_SCATTER = 302;
static const size_t MAX_TOPPINGS = 80;

static int   s_selected  = cake::TOP_CHERRY;
static bool  s_dragging  = false;
static Vec2  s_lastPlace(-99.0f, -99.0f);
static Vec2  s_ghostUV(0.0f, 0.0f);
static bool  s_ghostValid = false;
static int   s_hoverIndex = -1;
static int   s_scatterSeed = 7;

/* --------------------------------------------------------------- icons */
static void toppingIcon(Vec2 c, float size, float time, int arg) {
    cake::drawTopping(arg, Vec2(c.x, c.y - (arg == cake::TOP_CANDLE ? size * 0.20f : 0.0f)),
                      size * (arg == cake::TOP_CANDLE ? 0.72f : 0.95f), 0.0f, 2, time, 1.0f);
}

static void actionIcon(Vec2 c, float size, float time, int arg) {
    (void)time;
    switch (arg) {
        case 0:   /* undo */
            arcStroke(c, size * 0.72f, 40.0f, 300.0f, ui::T.textDim, 2.0f, 20);
            fillTri(Vec2(c.x - size * 0.20f, c.y + size * 0.60f),
                    Vec2(c.x + size * 0.34f, c.y + size * 0.74f),
                    Vec2(c.x + size * 0.10f, c.y + size * 0.20f), ui::T.textDim);
            break;
        case 1:   /* clear */
            line(Vec2(c.x - size * 0.55f, c.y - size * 0.55f),
                 Vec2(c.x + size * 0.55f, c.y + size * 0.55f), ui::T.danger, 2.2f);
            line(Vec2(c.x - size * 0.55f, c.y + size * 0.55f),
                 Vec2(c.x + size * 0.55f, c.y - size * 0.55f), ui::T.danger, 2.2f);
            break;
        case 2:   /* scatter */
            for (int i = 0; i < 5; ++i) {
                float a = 2.0f * PI * (float)i / 5.0f + 0.3f;
                fillCircle(Vec2(c.x + std::cos(a) * size * 0.55f,
                                c.y + std::sin(a) * size * 0.55f),
                           size * 0.16f, ui::T.accent2, 10);
            }
            break;
        default: break;
    }
}

/* --------------------------------------------------------------- build */
static void toppingBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::TOP_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::toppingDef(i).name;
        char sub[64];
        int  n = g_design.countOf(i);
        if (n > 0) std::sprintf(sub, "%s  -  %d placed", cake::toppingDef(i).note, n);
        else       std::sprintf(sub, "%s", cake::toppingDef(i).note);
        b.sub      = sub;
        b.icon     = toppingIcon;
        b.iconArg  = i;
        b.selected = (s_selected == i);
        g_options.push_back(b);
    }

    float rowH = 44.0f, gap = 5.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;
    float y = panelListTop() - (rowH + gap) * (float)cake::TOP_COUNT - 32.0f;

    const char* names[3] = { "Undo", "Clear", "Scatter" };
    for (int i = 0; i < 3; ++i) {
        ui::Button b;
        b.id      = ID_UNDO + i;
        b.style   = ui::BTN_CHIP;
        b.label   = names[i];
        b.icon    = actionIcon;
        b.iconArg = i;
        b.enabled = (i == 2) || !g_design.toppings.empty();
        g_extras.push_back(b);
    }
    layoutChips(g_extras, x, y, (w - 2.0f * 9.0f) / 3.0f, 34.0f, 9.0f, 3);
}

/* ------------------------------------------------------------ placing */
static void placeAt(Vec2 uv) {
    if (g_design.toppings.size() >= MAX_TOPPINGS) {
        ui::toast("That is as much as this cake can hold");
        return;
    }
    cake::Placed p;
    p.type    = s_selected;
    p.u       = uv.x;
    p.v       = uv.y;
    p.variant = (int)(hash21(uv.x * 31.7f, uv.y * 17.3f) * 6.0f) + (int)g_design.toppings.size();
    p.rot     = (hash21(uv.y * 13.0f, uv.x * 7.0f) - 0.5f) * 24.0f;
    p.scale   = 0.86f + 0.30f * hash21(uv.x * 5.5f, uv.y * 9.1f);
    p.born    = g_time;
    if (s_selected == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
    g_design.toppings.push_back(p);
    s_lastPlace = uv;
    rebuildStage();
}

static int nearestTopping(Vec2 screen) {
    cake::Frame f = previewFrame();
    float best = 1e9f;
    int   bestIdx = -1;
    float reach = cake::toppingPixelSize(g_design, f) * 1.25f;
    for (size_t i = 0; i < g_design.toppings.size(); ++i) {
        Vec2 p = cake::uvToScreen(g_design, f, Vec2(g_design.toppings[i].u,
                                                    g_design.toppings[i].v));
        float d = length(p - screen);
        if (d < best && d < reach) { best = d; bestIdx = (int)i; }
    }
    return bestIdx;
}

void toppingsUndo() {
    if (g_design.toppings.empty()) { ui::toast("Nothing to undo"); return; }
    g_design.toppings.pop_back();
    ui::toast("Removed the last ingredient");
    rebuildStage();
}

void toppingsClear() {
    if (g_design.toppings.empty()) { ui::toast("The cake is already plain"); return; }
    g_design.toppings.clear();
    ui::toast("Cleared every ingredient");
    rebuildStage();
}

/*  Scatters eight pieces of the current ingredient by rejection sampling in
 *  the unit square and keeping only the points inside the base shape.       */
void toppingsScatter() {
    int placed = 0;
    for (int attempt = 0; attempt < 400 && placed < 8; ++attempt) {
        ++s_scatterSeed;
        float u = hash21((float)s_scatterSeed * 1.7f, 3.1f) * 2.0f - 1.0f;
        float v = hash21(5.3f, (float)s_scatterSeed * 2.9f) * 2.0f - 1.0f;
        Vec2 uv(u * 1.15f, v * 1.15f);
        if (!cake::insideUnitShape(g_design, uv, 0.82f)) continue;
        if (g_design.toppings.size() >= MAX_TOPPINGS) break;
        placeAt(uv);
        ++placed;
    }
    if (placed == 0) ui::toast("No room left on the surface");
    else {
        char buf[64];
        std::sprintf(buf, "Scattered %d %s", placed, cake::toppingDef(s_selected).name);
        ui::toast(buf);
    }
}

/* -------------------------------------------------------------- events */
static void toppingOnOption(int id) {
    s_selected = id;
    ui::toast(std::string(cake::toppingDef(id).name) + " ready, click the cake to place");
    rebuildStage();
}

static void toppingOnExtra(int id) {
    if      (id == ID_UNDO)    toppingsUndo();
    else if (id == ID_CLEAR)   toppingsClear();
    else if (id == ID_SCATTER) toppingsScatter();
}

static void toppingOnPreviewMouse(float x, float y, int button, int state) {
    cake::Frame f = previewFrame();
    Vec2 uv;
    bool inside = cake::screenToUV(g_design, f, Vec2(x, y), uv);

    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            s_dragging = true;
            if (inside && cake::insideUnitShape(g_design, uv, 0.86f)) placeAt(uv);
            else ui::toast("Click on the frosted top of the cake");
        } else {
            s_dragging = false;
            s_lastPlace = Vec2(-99.0f, -99.0f);
        }
    } else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        int idx = nearestTopping(Vec2(x, y));
        if (idx >= 0) {
            g_design.toppings.erase(g_design.toppings.begin() + idx);
            ui::toast("Ingredient removed");
            rebuildStage();
        } else {
            ui::toast("Right click directly on an ingredient to remove it");
        }
    }
}

static void toppingOnPreviewMotion(float x, float y) {
    cake::Frame f = previewFrame();
    Vec2 uv;
    s_ghostValid = cake::screenToUV(g_design, f, Vec2(x, y), uv) &&
                   cake::insideUnitShape(g_design, uv, 0.86f);
    s_ghostUV    = uv;
    s_hoverIndex = nearestTopping(Vec2(x, y));

    if (s_dragging && s_ghostValid) {
        float gap = 0.20f;
        if (length(uv - s_lastPlace) > gap) placeAt(uv);
    }
}

/* ------------------------------------------------------------ drawing */
static void toppingDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    float y = panelListTop() - (44.0f + 5.0f) * (float)cake::TOP_COUNT - 12.0f;
    ui::drawSectionLabel(x, y, "PLACEMENT");
}

static void toppingDrawPreviewOverlay() {
    cake::Frame f = previewFrame();

    char buf[96];
    std::sprintf(buf, "%d ingredient%s placed", (int)g_design.toppings.size(),
                 g_design.toppings.size() == 1 ? "" : "s");
    textRight(previewCaptionRight(), previewCaptionY(0), buf,
              withAlpha(ui::T.textDim, 0.9f), FONT_XS);
    textRight(previewCaptionRight(), previewCaptionY(1),
              "left click or drag to place, right click to remove",
              withAlpha(ui::T.textFaint, 0.9f), FONT_XS);

    if (s_ghostValid) {
        Vec2 p = cake::uvToScreen(g_design, f, s_ghostUV);
        float r = cake::toppingPixelSize(g_design, f) * 1.5f;
        Color mark = withAlpha(rgb(255, 255, 255), 0.28f);
        line(Vec2(p.x - r, p.y), Vec2(p.x - r * 0.55f, p.y), mark, 1.4f);
        line(Vec2(p.x + r * 0.55f, p.y), Vec2(p.x + r, p.y), mark, 1.4f);
        line(Vec2(p.x, p.y - r), Vec2(p.x, p.y - r * 0.55f), mark, 1.4f);
        line(Vec2(p.x, p.y + r * 0.55f), Vec2(p.x, p.y + r), mark, 1.4f);
    }
}

static bool toppingCanAdvance() { return true; }

/* ------------------------------------------------- state the shell reads */
int  toppingsSelected()    { return s_selected; }
bool toppingsGhostValid()  { return s_ghostValid; }
Vec2 toppingsGhostUV()     { return s_ghostUV; }
int  toppingsHoverIndex()  { return s_hoverIndex; }
void toppingsResetHover()  { s_ghostValid = false; s_hoverIndex = -1; s_dragging = false; }

const StageDef& stageToppings() {
    static StageDef s = {
        "toppings",
        "Decorate the top",
        "Stage 3 of 4",
        "Each ingredient is translated to the point you click, then turned and sized a little.",
        toppingBuild, toppingOnOption, toppingOnExtra, toppingDrawPanelExtra, toppingDrawPreviewOverlay,
        toppingOnPreviewMouse, toppingOnPreviewMotion, toppingCanAdvance
    };
    return s;
}

} /* namespace app */

/* ===== stage_wrap.cpp ================================================ */
/* ============================================================================
 *  CakeLab  -  stage_wrap.cpp
 *  Stage 4 of 4  -  Wrapping and packaging.
 *  Group member 4, who also handles the integration of the four stages.
 *
 *  Nothing new is invented here. A rope tie is two shaded bands plus a bow
 *  made of ellipses and Bezier tails; a gift box is four rectangles with the
 *  window left open; a wrapping sheet is a fan of triangles; the ribbon is the
 *  same silhouette extrusion the cake body uses, only much shorter. The stage
 *  exists to show that the routines written for stages one and two are enough
 *  to build something completely different.
 * ==========================================================================*/

namespace app {

using namespace gfx;

static const int ID_COLOR_BASE = 400;
static float s_colorLabelY = 0.0f;

static void wrapIcon(Vec2 c, float size, float time, int arg) {
    cake::drawWrapIcon(arg, c, size * 0.92f, cake::wrapPaletteColor(g_design.wrapColor), time);
}

static void wrappingBuild() {
    g_options.clear();
    g_extras.clear();

    for (int i = 0; i < cake::WRAP_COUNT; ++i) {
        ui::Button b;
        b.id       = i;
        b.style    = ui::BTN_OPTION;
        b.label    = cake::wrapDef(i).name;
        b.sub      = cake::wrapDef(i).note;
        b.icon     = wrapIcon;
        b.iconArg  = i;
        b.selected = (g_design.wrap == i);
        g_options.push_back(b);
    }

    float rowH = 56.0f, gap = 9.0f;
    layoutRows(g_options, rowH, gap, panelListTop());

    float x = L.panelX + 18.0f;
    float w = L.panelW - 36.0f;
    s_colorLabelY = panelListTop() - (rowH + gap) * (float)cake::WRAP_COUNT - 20.0f;

    int n = cake::wrapPaletteSize();
    for (int i = 0; i < n; ++i) {
        ui::Button b;
        b.id       = ID_COLOR_BASE + i;
        b.style    = ui::BTN_CHIP;
        b.tint     = cake::wrapPaletteColor(i);
        b.selected = (g_design.wrapColor == i);
        b.enabled  = (g_design.wrap != cake::WRAP_NONE);
        g_extras.push_back(b);
    }
    float chipW = (w - 5.0f * 8.0f) / 6.0f;
    layoutChips(g_extras, x, s_colorLabelY - 12.0f, chipW, 34.0f, 8.0f, 6);
}

static void wrappingOnOption(int id) {
    g_design.wrap = id;
    if (id == cake::WRAP_NONE) ui::toast("Serving the cake unwrapped");
    else ui::toast(std::string(cake::wrapDef(id).name) + " in " +
                   cake::wrapPaletteName(g_design.wrapColor));
    rebuildStage();
}

static void wrappingOnExtra(int id) {
    if (id >= ID_COLOR_BASE) {
        g_design.wrapColor = id - ID_COLOR_BASE;
        if (g_design.wrap == cake::WRAP_NONE) g_design.wrap = cake::WRAP_RIBBON;
        ui::toast(std::string(cake::wrapPaletteName(g_design.wrapColor)) + " packaging");
        rebuildStage();
    }
}

static void wrappingDrawPanelExtra() {
    float x = L.panelX + 18.0f;
    ui::drawSectionLabel(x, s_colorLabelY,
                         g_design.wrap == cake::WRAP_NONE ? "PACKAGING COLOUR  (pick a style first)"
                                                          : "PACKAGING COLOUR");
    /* the chosen colour written out, so the swatch is not the only clue */
    if (g_design.wrap != cake::WRAP_NONE) {
        char buf[64];
        std::sprintf(buf, "%s  -  %s", cake::wrapDef(g_design.wrap).name,
                     cake::wrapPaletteName(g_design.wrapColor));
        text(x, s_colorLabelY - 70.0f, buf, ui::T.textDim, FONT_S);
    }
}

static void wrappingDrawPreviewOverlay() {
    const char* msg = (g_design.wrap == cake::WRAP_NONE)
        ? "No packaging: the cake is served straight from the plate"
        : "The packaging reuses the same shape and colour routines as the cake";
    textRight(previewCaptionRight(), previewCaptionY(0), msg,
              withAlpha(ui::T.textDim, 0.85f), FONT_XS);
}

static bool wrappingCanAdvance() { return true; }

const StageDef& stageWrap() {
    static StageDef s = {
        "wrap",
        "Wrap it up",
        "Stage 4 of 4",
        "The packaging is built from the same primitives as the cake itself.",
        wrappingBuild, wrappingOnOption, wrappingOnExtra, wrappingDrawPanelExtra, wrappingDrawPreviewOverlay,
        0, 0, wrappingCanAdvance
    };
    return s;
}

} /* namespace app */

/* ===== app.cpp ======================================================= */
/* ============================================================================
 *  CakeLab  -  app.cpp
 *  The shell that holds the four stages together: layout, the welcome and
 *  finish screens, the header, the footer, the input routing and the timer
 *  driven animation.
 * ==========================================================================*/

namespace app {

using namespace gfx;

/* ==========================================================================
 *  State
 * ========================================================================*/
Layout L;
cake::Design            g_design;
std::vector<ui::Button> g_options;
std::vector<ui::Button> g_extras;
float g_time      = 0.0f;
float g_mouseX    = 0.0f;
float g_mouseY    = 0.0f;
int   g_stage     = 0;
int   g_screen    = SCREEN_WELCOME;
int   g_furthest  = 0;
bool  g_algorithmView = false;

static std::vector<ui::Button> g_nav;
static bool  g_help        = false;
static float g_slide       = 0.0f;   /* stage change transition, 1 -> 0     */
static float g_slideDir    = 1.0f;
static float g_finishAnim  = 0.0f;
static cake::Design g_demo;          /* the cake shown on the welcome page  */
static int   g_randomSeed  = 11;

/* nav button identifiers */
enum {
    NAV_BACK = 1, NAV_NEXT, NAV_RESET, NAV_RANDOM, NAV_ALGO, NAV_SHOT, NAV_HELP,
    NAV_START = 20, NAV_DEMO,
    NAV_EDIT = 30, NAV_NEW, NAV_SAVE
};

static const char* kMembers[4] = {
    "Md. Minhaj Rowfun Rabbi Anik",
    "Adiba Howlader",
    "Md. Tanvir Hasan",
    "Abdur Rahman"
};

/* ==========================================================================
 *  Layout
 * ========================================================================*/
void computeLayout(int w, int h) {
    L.W = (float)std::max(w, 900);
    L.H = (float)std::max(h, 620);

    L.headerH = 74.0f;
    L.headerY = L.H - L.headerH - 10.0f;
    L.footerH = 58.0f;
    L.footerY = 10.0f;

    float gap = 14.0f;
    float contentBottom = L.footerY + L.footerH + gap;
    float contentTop    = L.headerY - gap;

    L.panelW = clampf(L.W * 0.29f, 320.0f, 390.0f);
    L.panelX = 14.0f;
    L.panelY = contentBottom;
    L.panelH = contentTop - contentBottom;

    L.previewX = L.panelX + L.panelW + gap;
    L.previewY = contentBottom;
    L.previewW = L.W - L.previewX - 14.0f;
    L.previewH = L.panelH;
}

float panelListTop()    { return L.panelY + L.panelH - 92.0f; }
float panelListBottom() { return L.panelY + 14.0f; }

void layoutRows(std::vector<ui::Button>& list, float rowH, float gap, float topEdge) {
    float y = topEdge;
    for (size_t i = 0; i < list.size(); ++i) {
        list[i].x = L.panelX + 18.0f;
        list[i].w = L.panelW - 36.0f;
        list[i].h = rowH;
        list[i].y = y - rowH;
        y -= (rowH + gap);
    }
}

void layoutChips(std::vector<ui::Button>& list, float x, float y, float chipW,
                 float chipH, float gap, int perRow) {
    for (size_t i = 0; i < list.size(); ++i) {
        int col = (int)i % perRow;
        int row = (int)i / perRow;
        list[i].x = x + (chipW + gap) * (float)col;
        list[i].y = y - (chipH + gap) * (float)row - chipH;
        list[i].w = chipW;
        list[i].h = chipH;
    }
}

/*  Sizes the cake to the space available and then centres it on its own
 *  bounding box, so a one tier cake and a three tier cake both sit nicely.  */
static cake::Frame fitFrame(const cake::Design& d, float cx, float areaY,
                            float areaH, float maxRadius, float anchor) {
    float r  = std::min(maxRadius, areaH * 0.34f);
    float lh = r * (d.layers >= 3 ? 0.36f : (d.layers == 2 ? 0.44f : 0.52f));
    float sTop = cake::layerScale(d, d.layers - 1);

    float topOff = lh * (float)d.layers + r * 0.40f * sTop + r * 0.26f;
    float botOff = -r * 0.46f;
    float cy = areaY + areaH * anchor - (topOff + botOff) * 0.5f;

    return cake::makeFrame(Vec2(cx, cy), r, d.layers);
}

cake::Frame previewFrame() {
    return fitFrame(g_design, L.previewX + L.previewW * 0.5f,
                    L.previewY, L.previewH, L.previewW * 0.30f, 0.56f);
}

float previewCaptionY(int line) { return L.previewY + 39.0f - 17.0f * (float)line; }
float previewCaptionRight()     { return L.previewX + L.previewW - 30.0f; }

cake::Frame heroFrame(float cx, float cy, float radius) {
    return cake::makeFrame(Vec2(cx, cy), radius, g_design.layers);
}

/* ==========================================================================
 *  Stage table
 * ========================================================================*/
const StageDef& currentStage() {
    switch (g_stage) {
        case 0: return stageShape();
        case 1: return stageFlavor();
        case 2: return stageToppings();
        default: return stageWrap();
    }
}

void markDirty() { glutPostRedisplay(); }

void rebuildStage() {
    if (currentStage().build) currentStage().build();
}

/* ==========================================================================
 *  Navigation buttons
 * ========================================================================*/
static ui::Button navButton(int id, const std::string& label, ui::ButtonStyle st,
                            float x, float y, float w, float h) {
    ui::Button b;
    b.id = id; b.label = label; b.style = st;
    b.x = x; b.y = y; b.w = w; b.h = h;
    return b;
}

static void toolIcon(Vec2 c, float size, float time, int arg) {
    switch (arg) {
        case 0:   /* reset: a circular arrow */
            arcStroke(c, size, 30.0f, 310.0f, ui::T.textDim, 2.0f, 22);
            fillTri(Vec2(c.x + size * 0.62f, c.y + size * 0.78f),
                    Vec2(c.x + size * 1.14f, c.y + size * 0.36f),
                    Vec2(c.x + size * 0.52f, c.y + size * 0.10f), ui::T.textDim);
            break;
        case 1:   /* surprise: dice pips */
            strokeRoundRect(c.x - size, c.y - size, size * 2.0f, size * 2.0f,
                            size * 0.32f, ui::T.textDim, 1.8f);
            fillCircle(Vec2(c.x - size * 0.42f, c.y + size * 0.42f), size * 0.18f, ui::T.accent2, 10);
            fillCircle(c, size * 0.18f, ui::T.accent2, 10);
            fillCircle(Vec2(c.x + size * 0.42f, c.y - size * 0.42f), size * 0.18f, ui::T.accent2, 10);
            break;
        case 2: { /* algorithm view: a staircase of pixels */
            Color on = g_algorithmView ? ui::T.ok : ui::T.textDim;
            for (int i = 0; i < 4; ++i)
                fillRect(c.x - size + (float)i * size * 0.5f,
                         c.y - size + (float)i * size * 0.5f,
                         size * 0.42f, size * 0.42f, on);
            break;
        }
        case 3:   /* camera */
            strokeRoundRect(c.x - size * 1.1f, c.y - size * 0.78f, size * 2.2f, size * 1.56f,
                            size * 0.26f, ui::T.textDim, 1.8f);
            strokeCircle(c, size * 0.52f, ui::T.textDim, 1.8f, 20);
            fillRect(c.x - size * 0.30f, c.y + size * 0.72f, size * 0.60f, size * 0.22f, ui::T.textDim);
            break;
        case 4:   /* question mark */
            arcStroke(Vec2(c.x, c.y + size * 0.34f), size * 0.52f, 200.0f, -30.0f,
                      ui::T.textDim, 2.0f, 20);
            line(Vec2(c.x + size * 0.06f, c.y + size * 0.10f),
                 Vec2(c.x + size * 0.06f, c.y - size * 0.34f), ui::T.textDim, 2.0f);
            fillCircle(Vec2(c.x + size * 0.06f, c.y - size * 0.72f), size * 0.16f, ui::T.textDim, 10);
            break;
        default: break;
    }
    (void)time;
}

static void buildNav() {
    g_nav.clear();
    float cy = L.footerY + L.footerH * 0.5f;

    if (g_screen == SCREEN_WELCOME) {
        float bw = 210.0f, bh = 50.0f;
        g_nav.push_back(navButton(NAV_START, "Start designing", ui::BTN_PRIMARY,
                                  L.W * 0.5f - bw - 10.0f, cy - bh * 0.5f, bw, bh));
        g_nav.push_back(navButton(NAV_DEMO, "Surprise me", ui::BTN_GHOST,
                                  L.W * 0.5f + 10.0f, cy - bh * 0.5f, 170.0f, bh));
        return;
    }

    if (g_screen == SCREEN_FINISH) {
        float bh = 48.0f;
        g_nav.push_back(navButton(NAV_EDIT, "Back to editing", ui::BTN_GHOST,
                                  L.W * 0.5f - 300.0f, cy - bh * 0.5f, 190.0f, bh));
        g_nav.push_back(navButton(NAV_SAVE, "Save picture", ui::BTN_PRIMARY,
                                  L.W * 0.5f - 95.0f, cy - bh * 0.5f, 190.0f, bh));
        g_nav.push_back(navButton(NAV_NEW, "Design another", ui::BTN_GHOST,
                                  L.W * 0.5f + 110.0f, cy - bh * 0.5f, 190.0f, bh));
        return;
    }

    /* stage screen */
    float bh = 42.0f;
    g_nav.push_back(navButton(NAV_BACK, "Back", ui::BTN_GHOST, 20.0f, cy - bh * 0.5f, 104.0f, bh));

    float tx = 136.0f;
    const char* tips[5] = { "Reset", "Surprise", "Algorithm view", "Save picture", "Help" };
    int  ids[5] = { NAV_RESET, NAV_RANDOM, NAV_ALGO, NAV_SHOT, NAV_HELP };
    for (int i = 0; i < 5; ++i) {
        ui::Button b = navButton(ids[i], tips[i], ui::BTN_ICON, tx, cy - 19.0f, 38.0f, 38.0f);
        b.icon = toolIcon;
        b.iconArg = i;
        b.selected = (ids[i] == NAV_ALGO) ? g_algorithmView : false;
        g_nav.push_back(b);
        tx += 44.0f;
    }

    float nw = 218.0f, nh = 46.0f;
    bool last = (g_stage == STAGE_COUNT - 1);
    ui::Button nb = navButton(NAV_NEXT, last ? "Finish the cake" : "Next stage",
                              ui::BTN_PRIMARY, L.W - 20.0f - nw, cy - nh * 0.5f, nw, nh);
    nb.enabled = currentStage().canAdvance ? currentStage().canAdvance() : true;
    g_nav.push_back(nb);
}

/* ==========================================================================
 *  Confetti for the finish screen
 * ========================================================================*/
struct Fleck {
    Vec2  p, v;
    Color c;
    float rot, spin, life, size;
};
static std::vector<Fleck> g_confetti;

static void spawnConfetti() {
    g_confetti.clear();
    const cake::FlavorDef& fl = cake::flavorDef(g_design.flavor);
    Color palette[5] = { ui::T.accent, ui::T.accent2, ui::T.ok, fl.cream, fl.accent };
    for (int i = 0; i < 150; ++i) {
        Fleck f;
        float hx = hash11((float)i * 1.7f);
        float hy = hash11((float)i * 3.1f + 0.5f);
        f.p    = Vec2(hx * L.W, L.H + hy * 320.0f);
        f.v    = Vec2((hash11((float)i * 5.3f) - 0.5f) * 60.0f, -(90.0f + hy * 200.0f));
        f.c    = palette[i % 5];
        f.rot  = hash11((float)i * 7.7f) * 360.0f;
        f.spin = (hash11((float)i * 9.1f) - 0.5f) * 320.0f;
        f.life = 1.0f;
        f.size = 5.0f + hash11((float)i * 11.3f) * 7.0f;
        g_confetti.push_back(f);
    }
}

static void updateConfetti(float dt) {
    for (size_t i = 0; i < g_confetti.size(); ++i) {
        Fleck& f = g_confetti[i];
        f.v.y -= 120.0f * dt;
        f.p    = f.p + f.v * dt;
        f.rot += f.spin * dt;
        if (f.p.y < -30.0f) {
            f.p.y = L.H + 20.0f + hash11(f.p.x * 0.37f) * 120.0f;
            f.v.y = -(90.0f + hash11(f.p.x * 0.11f) * 180.0f);
        }
    }
}

static void drawConfetti() {
    for (size_t i = 0; i < g_confetti.size(); ++i) {
        const Fleck& f = g_confetti[i];
        pushTransform(f.p, f.rot, 1.0f, 1.0f);
        fillRoundRect(-f.size * 0.5f, -f.size * 0.28f, f.size, f.size * 0.56f,
                      f.size * 0.16f, withAlpha(f.c, 0.9f));
        popTransform();
    }
}

/* ==========================================================================
 *  Header and footer
 * ========================================================================*/
static void drawLogo(float x, float y, float scale) {
    /* a miniature cake, drawn with the same primitives as the real one */
    Color body = rgb(255, 196, 212);
    Color top  = rgb(255, 236, 244);
    fillEllipse(Vec2(x + 16.0f * scale, y + 4.0f * scale), 18.0f * scale, 6.0f * scale,
                withAlpha(rgb(0, 0, 0), 0.25f), 24);
    fillRect(x, y + 4.0f * scale, 32.0f * scale, 15.0f * scale, body);
    fillEllipse(Vec2(x + 16.0f * scale, y + 4.0f * scale), 16.0f * scale, 5.0f * scale,
                shade(body, 0.85f), 24);
    fillEllipse(Vec2(x + 16.0f * scale, y + 19.0f * scale), 16.0f * scale, 5.5f * scale, top, 24);
    for (int i = 0; i < 4; ++i)
        fillCircle(Vec2(x + (5.0f + 7.0f * (float)i) * scale, y + 19.0f * scale),
                   3.0f * scale, top, 10);
    float flick = std::sin(g_time * 9.0f) * 3.0f;
    fillRect(x + 14.0f * scale, y + 20.0f * scale, 4.0f * scale, 11.0f * scale, rgb(255, 250, 240));
    pushTransform(Vec2(x + 16.0f * scale, y + 31.0f * scale), flick, 1.0f, 1.0f);
    fillEllipse(Vec2(0.0f, 3.0f * scale), 3.0f * scale, 5.0f * scale, rgb(255, 178, 60), 16);
    fillEllipse(Vec2(0.0f, 2.4f * scale), 1.5f * scale, 3.0f * scale, rgb(255, 240, 170), 14);
    popTransform();
}

static void drawHeader() {
    ui::drawPanel(L.panelX, L.headerY, L.W - L.panelX * 2.0f, L.headerH, 18.0f);

    drawLogo(L.panelX + 22.0f, L.headerY + 18.0f, 1.0f);
    strokeText(L.panelX + 68.0f, L.headerY + 38.0f, "CakeLab", ui::T.text, 27.0f, 2.2f);
    text(L.panelX + 70.0f, L.headerY + 18.0f,
         "CSC 3224 Computer Graphics  -  Group E", ui::T.textFaint, FONT_XS);

    if (g_screen == SCREEN_STAGE) {
        std::vector<std::string> names;
        names.push_back("Shape");
        names.push_back("Flavour");
        names.push_back("Toppings");
        names.push_back("Wrap");
        float sw = std::min(520.0f, L.W * 0.44f);
        ui::drawStepper(L.W - L.panelX - 24.0f - sw, L.headerY + 14.0f, sw, 46.0f,
                        names, g_stage, g_furthest, g_time);
    } else {
        const char* note = (g_screen == SCREEN_WELCOME)
            ? "An interactive 2D cake customisation game"
            : "Your cake is ready";
        textRight(L.W - L.panelX - 24.0f, L.headerY + 30.0f, note, ui::T.textDim, FONT_S);
    }
}

static void drawFooterHints() {
    if (g_screen != SCREEN_STAGE) return;
    float y = L.footerY + L.footerH * 0.5f - 6.0f;
    float x = 372.0f;
    if (x + 300.0f > L.W - 260.0f) return;      /* not enough room, skip */
    text(x, y, currentStage().hint, ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Preview panel
 * ========================================================================*/
static void drawPreviewBackdrop() {
    ui::drawPanelTinted(L.previewX, L.previewY, L.previewW, L.previewH, 18.0f,
                        ui::T.stageOuter, ui::T.panelEdge);
    pushScissor(L.previewX + 2.0f, L.previewY + 2.0f, L.previewW - 4.0f, L.previewH - 4.0f);
    fillEllipseGrad(Vec2(L.previewX + L.previewW * 0.5f, L.previewY + L.previewH * 0.46f),
                    L.previewW * 0.62f, L.previewH * 0.62f,
                    withAlpha(ui::T.stageInner, 0.85f), withAlpha(ui::T.stageInner, 0.0f), 56);
    /* a faint table line so the cake is standing on something */
    float ty = L.previewY + L.previewH * 0.30f;
    fillRectGradV(L.previewX, ty - 90.0f, L.previewW, 90.0f,
                  withAlpha(rgb(0, 0, 0), 0.18f), withAlpha(rgb(0, 0, 0), 0.0f));
    popScissor();
}

/*  A bar along the bottom of the preview: the design on the left, whatever
 *  the current stage wants to say on the right.                            */
static void drawInfoBar() {
    float x = L.previewX + 14.0f;
    float w = L.previewW - 28.0f;
    float h = 46.0f;
    float y = L.previewY + 12.0f;

    fillRoundRect(x, y, w, h, 12.0f, withAlpha(rgb(20, 12, 22), 0.50f));
    strokeRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelEdge, 0.7f), 1.2f);
    text(x + 18.0f, y + h - 19.0f, "CURRENT DESIGN", ui::T.textFaint, FONT_XS);
    text(x + 18.0f, y + 11.0f, cake::describe(g_design), ui::T.text, FONT_S);
}

static void drawStageScreen() {
    /* ---------------------------------------------------------- panel */
    float slideX = g_slide * 26.0f * g_slideDir;
    ui::drawPanel(L.panelX, L.panelY, L.panelW, L.panelH, 18.0f);

    glPushMatrix();
    glTranslatef(-slideX, 0.0f, 0.0f);

    const StageDef& st = currentStage();
    text(L.panelX + 20.0f, L.panelY + L.panelH - 34.0f, st.subtitle, ui::T.accent, FONT_XS);
    text(L.panelX + 20.0f, L.panelY + L.panelH - 62.0f, st.title, ui::T.text, FONT_L);
    ui::drawDivider(L.panelX + 20.0f, L.panelY + L.panelH - 78.0f, L.panelW - 40.0f);

    ui::drawButtons(g_options, g_time);
    if (st.drawPanelExtra) st.drawPanelExtra();
    ui::drawButtons(g_extras, g_time);

    glPopMatrix();

    /* -------------------------------------------------------- preview */
    drawPreviewBackdrop();
    pushScissor(L.previewX + 2.0f, L.previewY + 2.0f, L.previewW - 4.0f, L.previewH - 4.0f);

    cake::Frame f = previewFrame();
    cake::RenderOpts o;
    o.time             = g_time;
    o.highlightSurface = (g_stage == 2);
    o.algorithmView    = g_algorithmView;
    if (g_stage == 2) {
        o.ghostTopping    = toppingsGhostValid() ? toppingsSelected() : -1;
        o.ghostUV         = toppingsGhostUV();
        o.ghostValid      = toppingsGhostValid();
        o.selectedTopping = toppingsHoverIndex();
    }
    cake::drawCake(g_design, f, o);

    drawInfoBar();
    if (st.drawPreviewOverlay) st.drawPreviewOverlay();
    popScissor();
}

/* ==========================================================================
 *  Welcome screen
 * ========================================================================*/
/*  Four small cards summarising which parts of the course the project uses. */
static void drawTechCard(float x, float y, float w, float h,
                         const char* title, const char* body, int glyph) {
    fillRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelHi, 0.45f));
    strokeRoundRect(x, y, w, h, 12.0f, withAlpha(ui::T.panelEdge, 0.85f), 1.1f);

    Vec2 g(x + 28.0f, y + h * 0.5f);
    switch (glyph) {
        case 0:                                  /* rasterised staircase */
            for (int i = 0; i < 4; ++i)
                fillRect(g.x - 13.0f + (float)i * 6.5f, g.y - 13.0f + (float)i * 6.5f,
                         5.5f, 5.5f, ui::T.accent2);
            break;
        case 1:                                  /* three colour channels */
            fillCircle(Vec2(g.x - 7.0f, g.y + 5.0f), 7.0f, withAlpha(rgb(236,  86,  86), 0.9f), 14);
            fillCircle(Vec2(g.x + 4.0f, g.y + 6.0f), 7.0f, withAlpha(rgb( 96, 214, 126), 0.9f), 14);
            fillCircle(Vec2(g.x - 1.0f, g.y - 6.0f), 7.0f, withAlpha(rgb( 96, 156, 236), 0.9f), 14);
            break;
        case 2:                                  /* a square and its copy  */
            strokeRect(g.x - 13.0f, g.y - 13.0f, 15.0f, 15.0f,
                       withAlpha(ui::T.accent, 0.55f), 1.4f);
            pushTransform(Vec2(g.x + 4.0f, g.y + 3.0f), 26.0f, 1.0f, 1.0f);
            strokeRect(-8.0f, -8.0f, 16.0f, 16.0f, ui::T.accent, 1.7f);
            popTransform();
            break;
        default:                                 /* pointer and a key cap  */
            fillTri(Vec2(g.x - 9.0f, g.y + 11.0f), Vec2(g.x - 9.0f, g.y - 8.0f),
                    Vec2(g.x + 3.0f, g.y + 1.0f), ui::T.ok);
            fillRoundRect(g.x + 2.0f, g.y - 12.0f, 13.0f, 10.0f, 2.5f,
                          withAlpha(ui::T.ok, 0.65f));
            break;
    }
    text(x + 54.0f, y + h * 0.5f + 2.0f, title, ui::T.text, FONT_S);
    text(x + 54.0f, y + h * 0.5f - 14.0f, body, ui::T.textFaint, FONT_XS);
}

static void drawWelcome() {
    ui::drawPanel(L.panelX, L.panelY, L.W - L.panelX * 2.0f, L.panelH, 18.0f);

    float leftX = L.panelX + 54.0f;
    float colW  = (L.W - L.panelX * 2.0f) * 0.48f;
    float top   = L.panelY + L.panelH - 62.0f;

    strokeTextCentered(leftX + strokeTextWidth("CakeLab", 62.0f) * 0.5f, top - 44.0f,
                       "CakeLab", ui::T.text, 62.0f, 3.0f);
    text(leftX, top - 74.0f, "An interactive 2D cake customisation game",
         ui::T.accent, FONT_M);

    float y = top - 118.0f;
    y -= ui::drawWrapped(leftX, y, colW - 40.0f,
        "Design a cake in four stages: choose the base shape, pick a flavour and "
        "its colour scheme, decorate the top with ingredients, then wrap it for "
        "delivery. Everything on screen is built from points, lines and polygons "
        "using OpenGL and GLUT.",
        ui::T.textDim, FONT_S);

    y -= 16.0f;
    ui::drawSectionLabel(leftX, y, "GROUP E");
    y -= 22.0f;
    for (int i = 0; i < 4; ++i) {
        fillCircle(Vec2(leftX + 5.0f, y + 5.0f), 3.0f, ui::T.accent, 10);
        text(leftX + 18.0f, y, kMembers[i], ui::T.text, FONT_S);
        y -= 21.0f;
    }
    y -= 10.0f;
    ui::drawSectionLabel(leftX, y, "SUPERVISOR");
    text(leftX, y - 22.0f, "Dr. Mohammad Nazmul Alam", ui::T.text, FONT_S);
    text(leftX, y - 46.0f,
         "Department of Computer Science, Faculty of Science and Technology, AIUB",
         ui::T.textFaint, FONT_XS);

    /* what the project demonstrates, filling the space under the credits */
    float cardH = 48.0f, cardGap = 10.0f;
    float cardW = (colW - 40.0f - cardGap) * 0.5f;
    float row2Y = L.panelY + 24.0f;
    float row1Y = row2Y + cardH + cardGap;
    ui::drawSectionLabel(leftX, row1Y + cardH + 14.0f, "TECHNIQUES DEMONSTRATED");

    struct Tech { const char* t; const char* b; };
    Tech techs[4] = {
        { "Scan conversion", "DDA, Bresenham, midpoint circle" },
        { "Colour models",   "RGB palettes and HSV mixing"     },
        { "Transformations", "translate, rotate, scale"        },
        { "Interaction",     "mouse, keyboard and timer"       }
    };
    for (int i = 0; i < 4; ++i) {
        float x = leftX + (float)(i % 2) * (cardW + cardGap);
        float y = (i < 2) ? row1Y : row2Y;
        drawTechCard(x, y, cardW, cardH, techs[i].t, techs[i].b, i);
    }

    /* the showcase cake on the right, bobbing gently on its plate */
    float cx = L.panelX + (L.W - L.panelX * 2.0f) * 0.74f;
    float r  = std::min(L.panelH * 0.30f, (L.W - L.panelX * 2.0f) * 0.18f);

    cake::Frame f = fitFrame(g_demo, cx, L.panelY, L.panelH, r, 0.52f);
    f.centre.y += std::sin(g_time * 0.9f) * 5.0f;
    cake::RenderOpts o;
    o.time = g_time;
    cake::drawCake(g_demo, f, o);

    for (int i = 0; i < 5; ++i) {
        float a  = g_time * 0.6f + (float)i * 1.257f;
        float rr = f.radius * (1.35f + 0.12f * std::sin(g_time * 1.4f + (float)i));
        Vec2  p(cx + std::cos(a) * rr,
                f.centre.y + f.radius * 0.9f + std::sin(a * 1.3f) * rr * 0.34f);
        ui::drawSparkle(p, 5.0f + 2.5f * std::sin(g_time * 2.0f + (float)i),
                        withAlpha(i % 2 ? ui::T.accent2 : ui::T.accent, 0.75f));
    }
}

/* ==========================================================================
 *  Finish screen
 * ========================================================================*/
static void drawFinish() {
    drawConfetti();

    float panelW = L.W - L.panelX * 2.0f;
    ui::drawPanel(L.panelX, L.panelY, panelW, L.panelH, 18.0f);

    float ease = smoothstep(0.0f, 1.0f, clampf(g_finishAnim, 0.0f, 1.0f));
    cake::Frame f = fitFrame(g_design, L.panelX + panelW * 0.31f,
                             L.panelY, L.panelH, panelW * 0.24f * (0.84f + 0.16f * ease),
                             0.54f);
    f.centre.y += std::sin(g_time * 1.1f) * 4.0f;
    cake::RenderOpts o;
    o.time = g_time;
    o.algorithmView = g_algorithmView;
    cake::drawCake(g_design, f, o);

    /* ------------------------------------------------------- summary */
    float bx = L.panelX + panelW * 0.62f;
    float by = L.panelY + 20.0f;
    float bw = panelW * 0.34f;
    float bh = L.panelH - 40.0f;
    ui::drawPanelTinted(bx, by, bw, bh, 16.0f, ui::T.panelHi, ui::T.panelEdge);

    float y = by + bh - 44.0f;
    text(bx + 24.0f, y, "YOUR CAKE IS READY", ui::T.accent, FONT_XS);
    y -= 34.0f;
    text(bx + 24.0f, y, "Design summary", ui::T.text, FONT_L);
    y -= 20.0f;
    ui::drawDivider(bx + 24.0f, y, bw - 48.0f);
    y -= 30.0f;

    struct Row { const char* k; std::string v; };
    char toppingBuf[64];
    std::sprintf(toppingBuf, "%d piece%s", (int)g_design.toppings.size(),
                 g_design.toppings.size() == 1 ? "" : "s");
    char shapeBuf[64];
    if (g_design.shape == cake::SHAPE_POLYGON)
        std::sprintf(shapeBuf, "%s, %d sides", cake::shapeDef(g_design.shape).name,
                     g_design.polySides);
    else
        std::sprintf(shapeBuf, "%s", cake::shapeDef(g_design.shape).name);
    char tierBuf[32];
    std::sprintf(tierBuf, "%d", g_design.layers);
    std::string wrapStr = cake::wrapDef(g_design.wrap).name;
    if (g_design.wrap != cake::WRAP_NONE)
        wrapStr += std::string(", ") + cake::wrapPaletteName(g_design.wrapColor);

    Row rows[5] = {
        { "Base shape", shapeBuf },
        { "Tiers",      tierBuf },
        { "Flavour",    cake::flavorDef(g_design.flavor).name },
        { "Toppings",   toppingBuf },
        { "Packaging",  wrapStr }
    };
    for (int i = 0; i < 5; ++i) {
        text(bx + 24.0f, y, rows[i].k, ui::T.textFaint, FONT_XS);
        text(bx + 150.0f, y, rows[i].v, ui::T.text, FONT_S);
        y -= 30.0f;
    }

    y -= 6.0f;
    ui::drawDivider(bx + 24.0f, y, bw - 48.0f);
    y -= 26.0f;
    ui::drawSectionLabel(bx + 24.0f, y, "INGREDIENT BREAKDOWN");
    y -= 24.0f;
    int shown = 0;
    for (int i = 0; i < cake::TOP_COUNT; ++i) {
        int n = g_design.countOf(i);
        if (n == 0) continue;
        cake::drawTopping(i, Vec2(bx + 36.0f, y + 5.0f), 11.0f, 0.0f, 2, g_time, 1.0f);
        char line[64];
        std::sprintf(line, "%-10s x %d", cake::toppingDef(i).name, n);
        text(bx + 58.0f, y, line, ui::T.textDim, FONT_XS);
        y -= 22.0f;
        ++shown;
    }
    if (shown == 0)
        text(bx + 36.0f, y, "no ingredients, a plain cake", ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Help overlay
 * ========================================================================*/
static void drawHelp() {
    fillRect(0.0f, 0.0f, L.W, L.H, withAlpha(rgb(12, 6, 14), 0.72f));

    float w = 560.0f, h = 430.0f;
    float x = L.W * 0.5f - w * 0.5f;
    float y = L.H * 0.5f - h * 0.5f;
    ui::drawPanelTinted(x, y, w, h, 18.0f, ui::T.panel, ui::T.accent);

    text(x + 28.0f, y + h - 44.0f, "Controls", ui::T.text, FONT_L);
    text(x + 28.0f, y + h - 66.0f, "everything is also reachable with the mouse",
         ui::T.textFaint, FONT_XS);

    struct KeyRow { const char* key; const char* what; };
    KeyRow rows[13] = {
        { "Enter / N",   "go to the next stage"                   },
        { "Backspace / B","go back one stage"                     },
        { "1 - 8",       "choose an option in the current stage"  },
        { "Left click",  "place the selected ingredient"          },
        { "Drag",        "place a trail of ingredients"           },
        { "Right click", "remove the ingredient under the cursor" },
        { "U",           "undo the last ingredient"               },
        { "C",           "clear all ingredients"                  },
        { "X",           "scatter eight of the selected piece"    },
        { "A",           "toggle the scan conversion view"        },
        { "P",           "save the window as a BMP picture"       },
        { "R",           "reset the whole design"                 },
        { "Z",           "surprise me with a random cake"         }
    };
    float ry = y + h - 100.0f;
    for (int i = 0; i < 13; ++i) {
        ui::drawKeyCap(x + 28.0f, ry - 4.0f, rows[i].key, ui::T.text);
        text(x + 170.0f, ry, rows[i].what, ui::T.textDim, FONT_S);
        ry -= 25.0f;
    }
    textCentered(x + w * 0.5f, y + 18.0f, "press H or Escape to close",
                 ui::T.textFaint, FONT_XS);
}

/* ==========================================================================
 *  Lifecycle
 * ========================================================================*/
void init() {
    ui::initTheme();
    g_design.reset();

    /* the cake used on the welcome page */
    g_demo.reset();
    g_demo.shape  = cake::SHAPE_CIRCLE;
    g_demo.layers = 2;
    g_demo.flavor = cake::FLV_STRAWBERRY;
    g_demo.wrap   = cake::WRAP_RIBBON;
    g_demo.wrapColor = 0;
    const float pts[7][2] = {
        { 0.00f,  0.10f }, { -0.46f,  0.30f }, { 0.44f,  0.26f },
        { -0.30f, -0.36f }, { 0.34f, -0.34f }, { -0.62f, -0.06f }, { 0.62f, -0.02f }
    };
    const int types[7] = { cake::TOP_CANDLE, cake::TOP_CHERRY, cake::TOP_BERRY,
                           cake::TOP_GEM, cake::TOP_FRUIT, cake::TOP_CHOCOLATE,
                           cake::TOP_BISCUIT };
    for (int i = 0; i < 7; ++i) {
        cake::Placed p;
        p.type = types[i];
        p.u = pts[i][0];
        p.v = pts[i][1];
        p.variant = i;
        p.rot = (hash11((float)i) - 0.5f) * 20.0f;
        p.scale = (types[i] == cake::TOP_CANDLE) ? 1.45f : 0.95f;
        p.born = -10.0f;
        g_demo.toppings.push_back(p);
    }

    rebuildStage();
    buildNav();
}

void update(float dt) {
    g_time += dt;
    ui::toastUpdate(dt);

    ui::animateButtons(g_options, g_mouseX, g_mouseY, dt);
    ui::animateButtons(g_extras,  g_mouseX, g_mouseY, dt);
    ui::animateButtons(g_nav,     g_mouseX, g_mouseY, dt);

    if (g_slide > 0.0f) g_slide = std::max(0.0f, g_slide - dt * 4.2f);
    if (g_screen == SCREEN_FINISH) {
        g_finishAnim = std::min(1.0f, g_finishAnim + dt * 1.6f);
        updateConfetti(dt);
    }

    /* keep the Next button in step with the stage */
    for (size_t i = 0; i < g_nav.size(); ++i)
        if (g_nav[i].id == NAV_NEXT && currentStage().canAdvance)
            g_nav[i].enabled = currentStage().canAdvance();
}

void draw() {
    ui::drawBackdrop(L.W, L.H, g_time);
    drawHeader();

    switch (g_screen) {
        case SCREEN_WELCOME: drawWelcome();     break;
        case SCREEN_STAGE:   drawStageScreen(); break;
        default:             drawFinish();      break;
    }

    ui::drawButtons(g_nav, g_time);
    drawFooterHints();
    ui::toastDraw(L.W, L.footerY + L.footerH + 16.0f);

    if (g_help) drawHelp();
}

/* ==========================================================================
 *  Navigation
 * ========================================================================*/
void goToStage(int s) {
    if (s < 0) s = 0;
    if (s > STAGE_COUNT - 1) s = STAGE_COUNT - 1;
    g_slideDir = (s >= g_stage) ? 1.0f : -1.0f;
    g_stage    = s;
    g_furthest = std::max(g_furthest, g_stage);
    g_slide    = 1.0f;
    g_screen   = SCREEN_STAGE;
    toppingsResetHover();
    rebuildStage();
    buildNav();
}

void nextStage() {
    if (g_screen == SCREEN_WELCOME) { goToStage(0); return; }
    if (g_screen == SCREEN_FINISH)  return;
    if (g_stage >= STAGE_COUNT - 1) { finish(); return; }
    goToStage(g_stage + 1);
    ui::toast(currentStage().title);
}

void prevStage() {
    if (g_screen == SCREEN_FINISH) { g_screen = SCREEN_STAGE; buildNav(); return; }
    if (g_screen != SCREEN_STAGE)  return;
    if (g_stage == 0) { g_screen = SCREEN_WELCOME; buildNav(); return; }
    goToStage(g_stage - 1);
}

void finish() {
    g_screen     = SCREEN_FINISH;
    g_finishAnim = 0.0f;
    spawnConfetti();
    buildNav();
    ui::toast("Design complete");
}

void resetDesign() {
    g_design.reset();
    g_furthest = 0;
    toppingsResetHover();
    rebuildStage();
    buildNav();
    ui::toast("Design reset");
}

void randomizeDesign() {
    ++g_randomSeed;
    float s = (float)g_randomSeed;
    g_design.reset();
    g_design.shape     = (int)(hash11(s * 1.1f) * (float)cake::SHAPE_COUNT) % cake::SHAPE_COUNT;
    g_design.polySides = 5 + (int)(hash11(s * 2.3f) * 4.0f) % 4;
    g_design.layers    = 1 + (int)(hash11(s * 3.7f) * 3.0f) % 3;
    g_design.flavor    = (int)(hash11(s * 4.9f) * (float)cake::FLV_COUNT) % cake::FLV_COUNT;
    g_design.wrap      = (int)(hash11(s * 6.1f) * (float)cake::WRAP_COUNT) % cake::WRAP_COUNT;
    g_design.wrapColor = (int)(hash11(s * 7.3f) * (float)cake::wrapPaletteSize()) % cake::wrapPaletteSize();

    int want = 6 + (int)(hash11(s * 8.5f) * 10.0f) % 10;
    int guard = 0;
    while ((int)g_design.toppings.size() < want && guard < 600) {
        ++guard;
        float u = hash21(s * 1.3f + (float)guard, 2.7f) * 2.2f - 1.1f;
        float v = hash21(3.9f, s * 2.1f + (float)guard) * 2.2f - 1.1f;
        Vec2 uv(u, v);
        if (!cake::insideUnitShape(g_design, uv, 0.82f)) continue;
        cake::Placed p;
        p.type    = (int)(hash11((float)guard * 5.7f + s) * (float)cake::TOP_COUNT) % cake::TOP_COUNT;
        p.u       = uv.x;
        p.v       = uv.y;
        p.variant = guard;
        p.rot     = (hash11((float)guard * 3.3f) - 0.5f) * 24.0f;
        p.scale   = 0.86f + 0.3f * hash11((float)guard * 4.1f);
        p.born    = g_time;
        if (p.type == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
        g_design.toppings.push_back(p);
    }
    g_furthest = STAGE_COUNT - 1;
    rebuildStage();
    buildNav();
    ui::toast("Random cake generated");
}

void saveScreenshot() {
    std::string name = shot::nextFilename();
    if (shot::saveBMP(name, 0, 0, (int)L.W, (int)L.H))
        ui::toast("Saved " + name);
    else
        ui::toast("Could not write the picture file");
}

/* ==========================================================================
 *  Input
 * ========================================================================*/
void activateOption(int index) {
    if (index < 0 || index >= (int)g_options.size()) return;
    g_options[(size_t)index].pressAnim = 1.0f;
    if (currentStage().onOption) currentStage().onOption(g_options[(size_t)index].id);
    buildNav();
}

static void handleNav(int id) {
    switch (id) {
        case NAV_BACK:   prevStage();       break;
        case NAV_NEXT:   nextStage();       break;
        case NAV_RESET:  resetDesign();     break;
        case NAV_RANDOM: randomizeDesign(); break;
        case NAV_SHOT:   saveScreenshot();  break;
        case NAV_HELP:   g_help = !g_help;  break;
        case NAV_ALGO:
            g_algorithmView = !g_algorithmView;
            ui::toast(g_algorithmView ? "Scan conversion view on"
                                      : "Scan conversion view off");
            buildNav();
            break;
        case NAV_START:  goToStage(0);      break;
        case NAV_DEMO:   randomizeDesign(); goToStage(0); break;
        case NAV_EDIT:   g_screen = SCREEN_STAGE; buildNav(); break;
        case NAV_NEW:    resetDesign(); goToStage(0); break;
        case NAV_SAVE:   saveScreenshot();  break;
        default: break;
    }
}

void onMouse(int button, int state, int mx, int my) {
    g_mouseX = (float)mx;
    g_mouseY = L.H - (float)my;

    if (g_help) {
        if (state == GLUT_DOWN) g_help = false;
        return;
    }

    if (state == GLUT_DOWN && button == GLUT_LEFT_BUTTON) {
        int n = ui::hitIndex(g_nav, g_mouseX, g_mouseY);
        if (n >= 0) {
            g_nav[(size_t)n].pressAnim = 1.0f;
            handleNav(g_nav[(size_t)n].id);
            return;
        }
    }

    if (g_screen != SCREEN_STAGE) return;

    if (state == GLUT_DOWN && button == GLUT_LEFT_BUTTON) {
        int o = ui::hitIndex(g_options, g_mouseX, g_mouseY);
        if (o >= 0) { activateOption(o); return; }

        int e = ui::hitIndex(g_extras, g_mouseX, g_mouseY);
        if (e >= 0) {
            g_extras[(size_t)e].pressAnim = 1.0f;
            if (currentStage().onExtra) currentStage().onExtra(g_extras[(size_t)e].id);
            buildNav();
            return;
        }
    }

    bool inPreview = g_mouseX >= L.previewX && g_mouseX <= L.previewX + L.previewW &&
                     g_mouseY >= L.previewY && g_mouseY <= L.previewY + L.previewH;
    if (inPreview && currentStage().onPreviewMouse)
        currentStage().onPreviewMouse(g_mouseX, g_mouseY, button, state);
}

void onMotion(int mx, int my) {
    g_mouseX = (float)mx;
    g_mouseY = L.H - (float)my;
    if (g_screen == SCREEN_STAGE && currentStage().onPreviewMotion)
        currentStage().onPreviewMotion(g_mouseX, g_mouseY);
}

void onKey(unsigned char key, int mx, int my) {
    (void)mx; (void)my;
    if (key >= 'A' && key <= 'Z') key = (unsigned char)(key - 'A' + 'a');

    if (g_help) {
        if (key == 'h' || key == 27 || key == '?') g_help = false;
        return;
    }

    switch (key) {
        case 13:  nextStage(); return;              /* Enter     */
        case 'n': nextStage(); return;
        case 8:   prevStage(); return;              /* Backspace */
        case 'b': prevStage(); return;
        case 27:  glutLeaveMainLoop(); return;      /* Escape    */
        case 'h': case '?': g_help = true; return;
        case 'r': resetDesign(); return;
        case 'z': randomizeDesign(); return;
        case 'p': saveScreenshot(); return;
        case 'a':
            g_algorithmView = !g_algorithmView;
            ui::toast(g_algorithmView ? "Scan conversion view on"
                                      : "Scan conversion view off");
            buildNav();
            return;
        case 'u': if (g_screen == SCREEN_STAGE) toppingsUndo();    return;
        case 'c': if (g_screen == SCREEN_STAGE) toppingsClear();   return;
        case 'x': if (g_screen == SCREEN_STAGE) toppingsScatter(); return;
        default: break;
    }

    if (key >= '1' && key <= '9' && g_screen == SCREEN_STAGE)
        activateOption((int)(key - '1'));
}

void onSpecial(int key, int mx, int my) {
    (void)mx; (void)my;
    if (g_help) { g_help = false; return; }
    switch (key) {
        case GLUT_KEY_RIGHT: nextStage(); break;
        case GLUT_KEY_LEFT:  prevStage(); break;
        case GLUT_KEY_F1:    g_help = !g_help; break;
        case GLUT_KEY_F2:    saveScreenshot(); break;
        case GLUT_KEY_HOME:  goToStage(0); break;
        case GLUT_KEY_END:   finish(); break;
        default: break;
    }
}

} /* namespace app */

/* ===== main.cpp ====================================================== */
/* ============================================================================
 *  CakeLab  -  main.cpp
 *  An interactive 2D cake customisation game built with computer graphics
 *  primitives.
 *
 *  Course     : CSC 3224, Computer Graphics
 *  Group      : E
 *  Members    : Md. Minhaj Rowfun Rabbi Anik, Adiba Howlader,
 *               Md. Tanvir Hasan, Abdur Rahman
 *  Supervisor : Dr. Mohammad Nazmul Alam
 *  Department of Computer Science, Faculty of Science and Technology,
 *  American International University Bangladesh.
 *
 *  This file contains only the GLUT plumbing. Every callback forwards to the
 *  application shell in app.cpp:
 *
 *    glutDisplayFunc        -> app::draw
 *    glutReshapeFunc        -> app::computeLayout
 *    glutMouseFunc          -> app::onMouse
 *    glutMotionFunc         -> app::onMotion   (a button is held down)
 *    glutPassiveMotionFunc  -> app::onMotion   (no button held)
 *    glutKeyboardFunc       -> app::onKey
 *    glutSpecialFunc        -> app::onSpecial
 *    glutTimerFunc          -> the animation clock
 * ==========================================================================*/

/*  The GL headers shipped with MinGW stop at OpenGL 1.1, so the multisample
 *  token is spelled out here. The driver itself is far newer and honours it. */
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE 0x809D
#endif

static const int kInitialWidth  = 1280;
static const int kInitialHeight = 760;
static const int kFrameMs       = 16;      /* about 60 updates per second */

static int g_lastMs = 0;

/* ---------------------------------------------------------------------------
 *  Capture mode.  Running "CakeLab.exe --capture" steps through every screen,
 *  writes a BMP of each one and exits. It is only a convenience for putting
 *  figures into the report; the interactive program does not use it.
 * ------------------------------------------------------------------------ */
static bool g_capture     = false;
static int  g_captureStep = 0;
static int  g_captureHold = 0;

static void display();
static void reshape(int w, int h);

static void captureDesign(int shape, int sides, int layers, int flavor,
                          int wrap, int wrapColor, int toppingCount) {
    app::g_design.reset();
    app::g_design.shape     = shape;
    app::g_design.polySides = sides;
    app::g_design.layers    = layers;
    app::g_design.flavor    = flavor;
    app::g_design.wrap      = wrap;
    app::g_design.wrapColor = wrapColor;

    int guard = 0;
    while ((int)app::g_design.toppings.size() < toppingCount && guard < 800) {
        ++guard;
        float u = gfx::hash21((float)guard * 1.7f, 4.3f) * 2.2f - 1.1f;
        float v = gfx::hash21(2.9f, (float)guard * 3.1f) * 2.2f - 1.1f;
        gfx::Vec2 uv(u, v);
        if (!cake::insideUnitShape(app::g_design, uv, 0.82f)) continue;
        cake::Placed p;
        p.type    = guard % cake::TOP_COUNT;
        p.u       = uv.x;
        p.v       = uv.y;
        p.variant = guard;
        p.rot     = (gfx::hash11((float)guard * 2.3f) - 0.5f) * 22.0f;
        p.scale   = 0.88f + 0.28f * gfx::hash11((float)guard * 5.9f);
        p.born    = -10.0f;
        if (p.type == cake::TOP_CANDLE) { p.rot = 0.0f; p.scale = 1.30f; }
        app::g_design.toppings.push_back(p);
    }
}

static const int kCaptureCount = 10;

static const char* applyCaptureStep(int step) {
    app::g_algorithmView = false;
    switch (step) {
        case 0:
            app::g_screen = app::SCREEN_WELCOME;
            return "shot_1_welcome.bmp";
        case 1:
            captureDesign(cake::SHAPE_CIRCLE, 6, 1, cake::FLV_STRAWBERRY,
                          cake::WRAP_NONE, 0, 0);
            app::goToStage(0);
            return "shot_2_shape.bmp";
        case 2:
            captureDesign(cake::SHAPE_POLYGON, 6, 2, cake::FLV_REDVELVET,
                          cake::WRAP_NONE, 0, 0);
            app::goToStage(1);
            return "shot_3_flavour.bmp";
        case 3:
            captureDesign(cake::SHAPE_SQUARE, 6, 1, cake::FLV_CHOCOLATE,
                          cake::WRAP_NONE, 0, 14);
            app::goToStage(2);
            return "shot_4_toppings.bmp";
        case 4:
            captureDesign(cake::SHAPE_CIRCLE, 6, 2, cake::FLV_MANGO,
                          cake::WRAP_BOX, 1, 10);
            app::goToStage(3);
            return "shot_5_wrap.bmp";
        case 5:
            captureDesign(cake::SHAPE_CIRCLE, 6, 3, cake::FLV_BLACKFOREST,
                          cake::WRAP_RIBBON, 0, 16);
            app::goToStage(3);
            app::finish();
            return "shot_6_finish.bmp";
        case 6:
            captureDesign(cake::SHAPE_TRIANGLE, 6, 1, cake::FLV_GREEN,
                          cake::WRAP_NONE, 0, 6);
            app::goToStage(0);
            app::g_algorithmView = true;
            return "shot_7_algorithm.bmp";
        case 7:
            captureDesign(cake::SHAPE_RECT, 6, 1, cake::FLV_VANILLA,
                          cake::WRAP_ROPE, 3, 8);
            app::goToStage(3);
            return "shot_8_rope.bmp";
        case 8:
            captureDesign(cake::SHAPE_CIRCLE, 6, 1, cake::FLV_STRAWBERRY,
                          cake::WRAP_SHEET, 4, 8);
            app::goToStage(3);
            return "shot_9_sheet.bmp";
        default:
            captureDesign(cake::SHAPE_POLYGON, 8, 2, cake::FLV_BUTTERSCOTCH,
                          cake::WRAP_RIBBON, 2, 12);
            app::goToStage(3);
            return "shot_10_ribbon.bmp";
    }
}

static void captureTick() {
    static const char* pending = 0;
    if (g_captureHold == 0) pending = applyCaptureStep(g_captureStep);

    app::g_mouseX = -500.0f;
    app::g_mouseY = -500.0f;
    app::update(1.0f / 60.0f);
    display();

    if (++g_captureHold >= 10) {
        if (shot::saveBMP(pending, 0, 0, (int)app::L.W, (int)app::L.H))
            std::printf("wrote %s\n", pending);
        else
            std::printf("could not write %s\n", pending);
        std::fflush(stdout);
        g_captureHold = 0;
        if (++g_captureStep >= kCaptureCount) glutLeaveMainLoop();
    }
}

/* ---------------------------------------------------------------------------
 *  Self test.  "CakeLab.exe --selftest" drives the whole program with
 *  synthetic input: every option of every stage, placing and removing
 *  ingredients, the keyboard shortcuts, two window sizes and the finish
 *  screen. It reports a pass or fail count and exits. It is a development
 *  aid, run before handing the project in.
 * ------------------------------------------------------------------------ */
static bool g_selftest = false;
static int  g_checks   = 0;
static int  g_failures = 0;

static void check(bool ok, const char* what) {
    ++g_checks;
    if (!ok) {
        ++g_failures;
        std::printf("  FAIL  %s\n", what);
    }
}

/*  Feeds a click at a point given in the bottom-left origin used by the rest
 *  of the program, converting to the top-left origin GLUT reports.          */
static void clickAt(float x, float yFromBottom, int button) {
    int my = (int)(app::L.H - yFromBottom);
    app::onMotion((int)x, my);
    app::onMouse(button, GLUT_DOWN, (int)x, my);
    app::onMouse(button, GLUT_UP,   (int)x, my);
}

static void selfTestRun() {
    std::printf("CakeLab self test\n");

    /* every option of every stage */
    for (int stage = 0; stage < app::STAGE_COUNT; ++stage) {
        app::goToStage(stage);
        check(app::g_stage == stage, "goToStage set the stage");
        size_t options = app::g_options.size();
        check(options > 0, "stage built at least one option");
        for (size_t i = 0; i < options; ++i) {
            app::activateOption((int)i);
            display();
        }
        for (size_t i = 0; i < app::g_extras.size(); ++i) {
            if (!app::g_extras[i].enabled) continue;
            clickAt(app::g_extras[i].x + app::g_extras[i].w * 0.5f,
                    app::g_extras[i].y + app::g_extras[i].h * 0.5f, GLUT_LEFT_BUTTON);
            display();
        }
    }

    /* placing and removing ingredients */
    app::goToStage(2);
    app::toppingsClear();
    cake::Frame f = app::previewFrame();
    gfx::Vec2 top = cake::topCentre(app::g_design, f);
    size_t before = app::g_design.toppings.size();
    clickAt(top.x, top.y, GLUT_LEFT_BUTTON);
    check(app::g_design.toppings.size() == before + 1, "left click placed an ingredient");

    clickAt(top.x, top.y, GLUT_RIGHT_BUTTON);
    check(app::g_design.toppings.size() == before, "right click removed it again");

    clickAt(f.centre.x, f.centre.y - f.radius * 2.0f, GLUT_LEFT_BUTTON);
    check(app::g_design.toppings.size() == before, "a click off the cake places nothing");

    app::toppingsScatter();
    check(app::g_design.toppings.size() > before, "scatter added ingredients");
    size_t scattered = app::g_design.toppings.size();
    app::toppingsUndo();
    check(app::g_design.toppings.size() == scattered - 1, "undo removed exactly one");
    app::toppingsClear();
    check(app::g_design.toppings.empty(), "clear emptied the cake");

    /*  Every base shape must accept a click at the centre of its top face,
     *  and must survive being asked for its outline.                        */
    for (int shape = 0; shape < cake::SHAPE_COUNT; ++shape) {
        app::g_design.shape = shape;
        app::rebuildStage();
        f = app::previewFrame();
        top = cake::topCentre(app::g_design, f);
        app::toppingsClear();
        clickAt(top.x, top.y, GLUT_LEFT_BUTTON);
        check(app::g_design.toppings.size() == 1, cake::shapeDef(shape).name);
        display();
    }
    app::toppingsClear();

    /* keyboard shortcuts, excluding the ones that quit or write files */
    const char* keys = "nbrzaxuc123456789hH";
    for (const char* k = keys; *k; ++k) {
        app::onKey((unsigned char)*k, 0, 0);
        display();
    }
    app::onSpecial(GLUT_KEY_RIGHT, 0, 0);
    app::onSpecial(GLUT_KEY_LEFT, 0, 0);
    app::onSpecial(GLUT_KEY_F1, 0, 0);
    app::onKey('h', 0, 0);
    display();
    check(true, "keyboard handling did not crash");

    /* every wrapping style over every shape */
    for (int wrap = 0; wrap < cake::WRAP_COUNT; ++wrap) {
        for (int shape = 0; shape < cake::SHAPE_COUNT; ++shape) {
            app::g_design.wrap = wrap;
            app::g_design.shape = shape;
            for (int layers = 1; layers <= 3; ++layers) {
                app::g_design.layers = layers;
                display();
            }
        }
    }
    check(true, "every wrapping, shape and tier count rendered");

    /* the window at three sizes */
    int sizes[3][2] = { { 1024, 640 }, { 1600, 900 }, { 1280, 760 } };
    for (int i = 0; i < 3; ++i) {
        reshape(sizes[i][0], sizes[i][1]);
        display();
    }
    check(app::L.W > 0.0f && app::L.H > 0.0f, "layout survived resizing");

    app::finish();
    display();
    check(app::g_screen == app::SCREEN_FINISH, "finish screen reached");
    app::resetDesign();
    check(app::g_design.toppings.empty(), "reset cleared the design");

    std::printf("%d checks, %d failures\n", g_checks, g_failures);
    std::printf(g_failures == 0 ? "SELFTEST PASS\n" : "SELFTEST FAIL\n");
    std::fflush(stdout);
}

static void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    gfx::begin2D((int)app::L.W, (int)app::L.H);
    app::draw();
    glutSwapBuffers();
}

static void reshape(int w, int h) {
    if (w < 1) w = 1;
    if (h < 1) h = 1;
    app::computeLayout(w, h);
    app::rebuildStage();
    gfx::begin2D(w, h);
    glutPostRedisplay();
}

static void timer(int value) {
    int now = glutGet(GLUT_ELAPSED_TIME);
    float dt = (float)(now - g_lastMs) / 1000.0f;
    g_lastMs = now;
    if (dt > 0.10f) dt = 0.10f;          /* never take a huge step */
    if (dt < 0.0f)  dt = 0.0f;

    if (g_selftest) {
        selfTestRun();
        glutLeaveMainLoop();
        return;
    }
    if (g_capture) {
        captureTick();
        glutTimerFunc(1, timer, value);
        return;
    }

    app::update(dt);
    glutPostRedisplay();
    glutTimerFunc(kFrameMs, timer, value);
}

static void mouse(int button, int state, int x, int y) {
    app::onMouse(button, state, x, y);
    glutPostRedisplay();
}

static void motion(int x, int y) {
    app::onMotion(x, y);
}

static void keyboard(unsigned char key, int x, int y) {
    app::onKey(key, x, y);
    glutPostRedisplay();
}

static void special(int key, int x, int y) {
    app::onSpecial(key, x, y);
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    for (int i = 1; i < argc; ++i)
    {
        if (std::strcmp(argv[i], "--capture")  == 0) g_capture  = true;
        if (std::strcmp(argv[i], "--selftest") == 0) g_selftest = true;
    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_MULTISAMPLE);
    glutInitWindowSize(kInitialWidth, kInitialHeight);
    glutInitWindowPosition(60, 30);
    glutCreateWindow("CakeLab  -  Interactive 2D Cake Customisation  -  CSC 3224");

    /*  Closing the window returns from glutMainLoop instead of killing the
     *  process, so the program can shut down tidily.                        */
    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

    glEnable(GL_MULTISAMPLE);
    gfx::enableBlend();
    glClearColor(0.086f, 0.055f, 0.102f, 1.0f);

    app::computeLayout(kInitialWidth, kInitialHeight);
    app::init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutPassiveMotionFunc(motion);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);

    g_lastMs = glutGet(GLUT_ELAPSED_TIME);
    glutTimerFunc(kFrameMs, timer, 0);

    std::printf("CakeLab started. Press H inside the window for the control list.\n");
    glutMainLoop();
    return g_failures == 0 ? 0 : 1;
}
